"""Animacje cz. 2: luk, rewolwer, noz, sztandar, oraz zycie osady (kowal, noszenie, kopanie, gotowanie, klotnia, ognisko)."""
import math
from anim import P, merge, Clip, ease, walk, stance, wide, arms_down, breathe, crouch

def s(f, n, ph=0.0): return math.sin(2 * math.pi * (f / n + ph))

# ------------------------------------------------------------------ rewolwer (jedna reka)
def clip_pistol():
    S = merge(stance(), P(rot={"chest": (0, 0, 14), "upperarm.L": (8, 0, 0), "forearm.L": (0, -14, 0)}))
    low = merge(S, P(rot={"upperarm.R": (-4, -20, 0), "forearm.R": (0, -30, 0)}))
    aim = merge(S, P(rot={"upperarm.R": (-2, -86, -10), "forearm.R": (0, -4, 0), "head": (0, 4, -10), "neck": (0, 2, 0)}))
    kick = merge(aim, P(rot={"upperarm.R": (0, -14, 0), "forearm.R": (0, -16, 0), "chest": (0, -4, 0), "head": (0, -3, 0)}, vis={"pflash": 1}))
    off = P(vis={"pflash": 0})
    keys = [(0, low, "io"), (4, aim, "hold")]
    for fr in (6, 11, 16):
        keys += [(fr, aim, "snap"), (fr + 1, kick, "out"), (fr + 2, merge(kick, off), "io"), (fr + 4, aim, "hold")]
    keys += [(20, aim, "io"), (23, low, "hold")]
    return Clip(24, sorted(keys, key=lambda k: k[0]))

# ------------------------------------------------------------------ noz (pchniecie z wypadem)
def clip_knife():
    guard = merge(wide(), P(rot={"upperarm.R": (-6, -30, 0), "forearm.R": (0, -70, 0), "upperarm.L": (10, -40, 0), "forearm.L": (0, -80, 0),
                                 "spine": (0, 10, 0), "chest": (0, 6, 0)}, loc={"hips": (0, 0, -0.06)}))
    wind = merge(guard, P(rot={"upperarm.R": (0, 40, 0), "forearm.R": (0, -40, 0), "chest": (0, -4, -22), "spine": (0, 0, -6)}, loc={"hips": (-0.05, 0, -0.02)}))
    stab = merge(wide(), P(rot={"upperarm.R": (-4, -82, 6), "forearm.R": (0, -6, 0), "upperarm.L": (14, 20, 0), "forearm.L": (0, -40, 0),
                                "chest": (0, 14, 24), "spine": (0, 12, 8), "head": (0, 4, -10), "thigh.L": (0, -36, 0), "shin.L": (0, 36, 0), "thigh.R": (0, 24, 0)},
                           loc={"hips": (0.12, 0, -0.12)}, root=(0.25, 0, 0, 0)))
    twist = merge(stab, P(rot={"forearm.R": (24, -10, 0)}))
    return Clip(24, [(0, guard, "io"), (5, wind, "hold"), (7, wind, "snap"), (9, stab, "hold"), (10, twist, "io"), (12, twist, "io"),
                     (17, guard, "io"), (23, guard, "hold")])

# ------------------------------------------------------------------ luk (poza "bow": lewa reka na luku przez IK, prawa przez IK do cieciwy)
def clip_bow():
    S = merge(wide(), P(rot={"chest": (0, 0, 18), "head": (0, 0, -18)}))
    lower = merge(S, P(rot={"weapon": (0, 30, 0)}, loc={"weapon": (0, 0, -0.12)}, tgt={"ikR": (0.36, 0.06, -0.18)}))
    nock = merge(S, P(rot={"weapon": (0, 6, 0)}, tgt={"ikR": (0.30, 0.07, -0.06)}, vis={"arrow_d": 1}))
    draw = merge(S, P(rot={"weapon": (0, 0, 0), "chest": (0, -2, 4), "head": (0, 4, 0)}, tgt={"ikR": (0.0, 0.0, 0.0)}, vis={"arrow_d": 1}))
    hold = merge(draw, P(tgt={"ikR": (-0.02, 0.0, 0.0)}))
    rel = merge(S, P(rot={"weapon": (0, -5, 0), "chest": (0, -4, 6)}, tgt={"ikR": (-0.16, -0.08, 0.03)}, vis={"arrow_d": 0}))
    quiver = merge(S, P(rot={"weapon": (0, 18, 0), "chest": (0, 4, -6)}, loc={"weapon": (0, 0, -0.06)}, tgt={"ikR": (-0.26, -0.10, 0.12)}, vis={"arrow_d": 0}))
    return Clip(24, [(0, lower, "io"), (3, quiver, "io"), (6, nock, "io"), (8, nock, "io"), (12, draw, "out"), (14, hold, "hold"), (16, hold, "snap"),
                     (17, rel, "out"), (20, rel, "io"), (23, lower, "hold")])

# ------------------------------------------------------------------ sztandar w marszu
def banner_walk(f, n=14):
    w = walk(f, n, stride=22, arms=False)
    w["rot"]["weapon"] = (3 * s(f, n, 0.15), 4 * s(f, n / 2, 0.1), 0)
    w["rot"]["upperarm.L"] = (6, 14 * math.cos(2 * math.pi * f / n), 0); w["rot"]["forearm.L"] = (0, -16, 0)
    w["rot"]["chest"] = (0, -3, 4)
    return w

# ------------------------------------------------------------------ kowal przy kowadle (jednoreczny mlotek, lewa reka trzyma kleszcze)
def clip_smith():
    base = merge(wide(), P(rot={"spine": (0, 14, 0), "chest": (0, 8, 0), "head": (0, 16, 0),
                                "upperarm.L": (10, -34, 0), "forearm.L": (0, -50, 0)}, loc={"hips": (0, 0, -0.04)}))
    up = merge(base, P(rot={"upperarm.R": (-14, -130, 0), "forearm.R": (0, -70, 0), "chest": (0, -4, -8), "spine": (0, -4, 0)}, loc={"hips": (0, 0, 0.02)}))
    hit = merge(base, P(rot={"upperarm.R": (-6, -38, 0), "forearm.R": (0, -52, 0), "chest": (0, 6, 6)}, loc={"hips": (0, 0, -0.06)}, vis={"spark": 1}))
    bounce = merge(base, P(rot={"upperarm.R": (-8, -60, 0), "forearm.R": (0, -55, 0)}, vis={"spark": 0}))
    keys = []
    for c0 in (0, 12):
        keys += [(c0, bounce, "io"), (c0 + 5, up, "hold"), (c0 + 6, up, "in"), (c0 + 8, hit, "hold"), (c0 + 9, merge(hit, P(vis={"spark": 0})), "out")]
    return Clip(24, keys)

# ------------------------------------------------------------------ noszenie skrzyni (ciezar: odchylenie do tylu, krotki krok)
def carry(f, n=14):
    w = walk(f, n, stride=18, arms=False)
    for side, sg in (("L", 1), ("R", -1)):
        w["rot"]["upperarm." + side] = (sg * 8, -34, 0); w["rot"]["forearm." + side] = (0, -72, 0)
    w["rot"]["spine"] = (0, -7, 0); w["rot"]["chest"] = (0, -3, 0); w["rot"]["head"] = (0, -6, 0)
    w["loc"]["hips"] = (0, 0, w["loc"]["hips"][2] - 0.02)
    return w

# ------------------------------------------------------------------ kopanie lopata
def clip_dig():
    base = merge(wide(), P(rot={"spine": (0, 22, 0), "chest": (0, 10, 6), "head": (0, 12, 0)}, loc={"hips": (0, 0, -0.06)}))
    stab = merge(base, P(rot={"upperarm.R": (-8, -22, 0), "forearm.R": (0, -30, 0), "upperarm.L": (12, -55, 0), "forearm.L": (0, -40, 0)}))
    push = merge(stab, P(rot={"thigh.L": (0, -40, 0), "shin.L": (0, 50, 0), "foot.L": (0, 10, 0), "spine": (0, 30, 0)}, loc={"hips": (0.03, 0, -0.10)}))
    lift = merge(base, P(rot={"upperarm.R": (-8, -50, 0), "forearm.R": (0, -60, 0), "upperarm.L": (12, -80, 0), "forearm.L": (0, -40, 0),
                              "spine": (0, 6, 0), "chest": (0, 0, -16)}, loc={"hips": (-0.02, 0, -0.02)}))
    toss = merge(base, P(rot={"upperarm.R": (-20, -70, 0), "forearm.R": (0, -40, 0), "upperarm.L": (20, -95, 0), "forearm.L": (0, -20, 0),
                              "chest": (0, 4, 30), "spine": (0, 4, 10), "head": (0, 0, 20)}, vis={"dirt": 1}))
    return Clip(24, [(0, stab, "io"), (4, push, "out"), (8, push, "io"), (12, lift, "io"), (16, toss, "snap"), (18, merge(toss, P(vis={"dirt": 0})), "io"), (23, stab, "hold")])

# ------------------------------------------------------------------ mieszanie w kotle
def stir(f, n=16):
    c, sn = math.cos(2 * math.pi * f / n), math.sin(2 * math.pi * f / n)
    return merge(stance(), P(rot={"upperarm.R": (-10 + 10 * sn, -46 + 10 * c, 0), "forearm.R": (0, -36 - 8 * c, 0), "upperarm.L": (14, -10, 0), "forearm.L": (0, -60, 0),
                                  "spine": (0, 14, 0), "chest": (0, 4, 4 * sn), "head": (0, 16, 0)}, loc={"hips": (0, 0, -0.03)}))

# ------------------------------------------------------------------ klotnia (dwie postacie)
def argue_a(f):
    k = f % 24
    calm = merge(stance(), P(rot={"upperarm.L": (6, 0, 0), "upperarm.R": (-6, 0, 0), "forearm.L": (0, -14, 0), "forearm.R": (0, -14, 0)}))
    point = merge(stance(), P(rot={"upperarm.R": (-4, -80, -8), "forearm.R": (0, -10, 0), "upperarm.L": (30, -20, 0), "forearm.L": (0, -70, 0),
                                   "chest": (0, 10, 12), "spine": (0, 6, 0), "neck": (0, 14, 0), "head": (0, -6, 0)}, loc={"hips": (0.05, 0, 0)}))
    shrug = merge(stance(), P(rot={"upperarm.R": (-40, -30, 0), "forearm.R": (0, -80, 0), "upperarm.L": (40, -30, 0), "forearm.L": (0, -80, 0),
                                   "chest": (0, -6, 0), "head": (0, -12, 6)}))
    jab = merge(point, P(rot={"upperarm.R": (0, -10, 0), "forearm.R": (0, -10, 0)}))
    c = Clip(24, [(0, calm, "io"), (3, point, "out"), (5, jab, "io"), (6, point, "io"), (8, jab, "io"), (10, point, "io"),
                  (14, shrug, "io"), (18, shrug, "io"), (21, calm, "hold")])
    return c.sample(k)

def argue_b(f):
    k = f % 24
    arms = merge(stance(), P(rot={"upperarm.L": (12, -24, 0), "upperarm.R": (-12, -24, 0), "forearm.L": (0, -100, 0), "forearm.R": (0, -100, 0), "chest": (0, -4, 0)}))
    lean_back = merge(arms, P(rot={"spine": (0, -8, 0), "head": (0, -10, 0)}, loc={"hips": (-0.04, 0, 0)}))
    shake = lambda d: merge(lean_back, P(rot={"head": (0, 0, d)}))
    push = merge(stance(), P(rot={"upperarm.L": (6, -70, 0), "upperarm.R": (-6, -70, 0), "forearm.L": (0, -20, 0), "forearm.R": (0, -20, 0),
                                  "chest": (0, 12, 0), "spine": (0, 8, 0), "thigh.L": (0, -24, 0), "shin.L": (0, 20, 0)}, loc={"hips": (0.08, 0, -0.03)}))
    c = Clip(24, [(0, arms, "io"), (4, lean_back, "io"), (6, shake(16), "io"), (8, shake(-16), "io"), (10, shake(14), "io"), (12, lean_back, "io"),
                  (15, push, "out"), (17, push, "io"), (21, arms, "hold")])
    return c.sample(k)

# ------------------------------------------------------------------ przy ognisku (siedzi na pniu)
def sit_fire(f, n=24):
    r = s(f, n)
    return P(rot={"thigh.L": (0, -88, 4), "thigh.R": (0, -86, -4), "shin.L": (0, 92, 0), "shin.R": (0, 88, 0), "foot.L": (0, -4, 0), "foot.R": (0, -2, 0),
                  "spine": (0, 18 + 2 * r, 0), "chest": (0, 6, 0), "head": (0, 8 - 4 * r, 0),
                  "upperarm.L": (8, -36, 0), "upperarm.R": (-8, -36, 0), "forearm.L": (0, -40 + 6 * r, 0), "forearm.R": (0, -40 + 6 * r, 0)},
             loc={"hips": (-0.05, 0, -0.50)})

def idle_look(f, n=48):
    """Wartownik: rozglada sie, przestepuje z nogi na noge, oddech."""
    k = f % n
    look = 30 * math.sin(2 * math.pi * k / n) if 8 < k < 40 else 0
    return merge(stance(), breathe(f, 24), P(rot={"head": (0, 2, look), "neck": (0, 0, look * 0.3), "chest": (0, 0, look * 0.15)}))
