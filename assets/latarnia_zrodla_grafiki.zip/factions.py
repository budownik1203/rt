"""Frakcje ludzkie: dodatki do postaci (kaptury, szaty, maski, plecaki, czapki) i gotowe jednostki."""
import math
from mathutils import Vector as V
from lat3d import mat, box, cyl, loft, ellipsoid
from chars import human, M, cloth, METAL, METAL_D, STRAP, SKIN_PALE, FLESH, GLOW_RED, GLOW_YEL, WOOD, RUST, REDC, BOOT
import weapons as WP

HC = V((0.012, 0, 1.635))
C = lambda n, c: M("fx_" + n, c)
def F(n, c, e, s): return M("fx_" + n, c, emit=e, strength=s)

def hood(r, n, col):
    A = r.attach
    A(ellipsoid(n + "_hood", HC + V((-0.02, 0, 0.03)), (0.16, 0.135, 0.165), col, clip_z=-0.12), "head")
    A(loft(n + "_hoodc", [((0, 0, 1.42), 0.12, 0.17), ((0, 0, 1.52), 0.10, 0.14)], col), "chest")
def robe(r, n, col, length=0.25):
    r.attach(loft(n + "_robe", [((0, 0, 1.00), 0.14, 0.18), ((0, 0, 0.70), 0.19, 0.22), ((0, 0, length), 0.25, 0.27)], col, seg=14), "hips")
def cape(r, n, col, fur=None):
    r.attach(loft(n + "_cape", [((-0.10, 0, 1.45), 0.03, 0.20), ((-0.16, 0, 1.0), 0.03, 0.24), ((-0.20, 0, 0.55), 0.03, 0.26)], col, seg=8), "chest")
    if fur: r.attach(loft(n + "_fur", [((-0.02, 0, 1.47), 0.13, 0.20), ((-0.02, 0, 1.40), 0.15, 0.24)], fur, seg=12), "chest")
def hat_wide(r, n, col):
    r.attach(loft(n + "_brimw", [(HC + V((0, 0, 0.045)), 0.25, 0.25), (HC + V((0, 0, 0.06)), 0.24, 0.24)], col, seg=16), "head")
    r.attach(loft(n + "_crown", [(HC + V((0, 0, 0.0)), 0.135, 0.125), (HC + V((0, 0, 0.08)), 0.13, 0.12), (HC + V((0, 0, 0.17)), 0.11, 0.10)], col, seg=12), "head")
def cap(r, n, col):
    r.attach(ellipsoid(n + "_cap", HC + V((-0.01, 0, 0.07)), (0.13, 0.12, 0.07), col, clip_z=-0.02), "head")
    r.attach(box(n + "_peak", HC + V((0.13, 0, 0.07)), (0.08, 0.16, 0.012), col, rot=(0, math.radians(10), 0)), "head")
def goggles(r, n):
    for s in (1, -1): r.attach(cyl(n + "_gg%d" % s, HC + V((0.1, s * 0.045, 0.07)), HC + V((0.13, s * 0.045, 0.075)), 0.024, C("gglass", (150, 170, 160))), "head")
    r.attach(loft(n + "_ggb", [(HC + V((0, 0, 0.07)), 0.13, 0.115), (HC + V((0, 0, 0.055)), 0.13, 0.115)], STRAP()), "head")
def scarf_mask(r, n, col):
    r.attach(ellipsoid(n + "_scarf", HC + V((0.05, 0, -0.06)), (0.09, 0.11, 0.065), col), "head")
def skull_mask(r, n):
    B = C("bone", (210, 200, 176))
    r.attach(ellipsoid(n + "_skull", HC + V((0.06, 0, 0.0)), (0.075, 0.105, 0.13), B), "head")
    for s in (1, -1): r.attach(ellipsoid(n + "_sock%d" % s, HC + V((0.128, s * 0.042, 0.02)), (0.012, 0.022, 0.02), C("black", (20, 18, 22))), "head")
    for k in range(4): r.attach(box(n + "_tth%d" % k, HC + V((0.13, -0.03 + 0.02 * k, -0.07)), (0.01, 0.012, 0.02), B), "head")
def iron_mask(r, n):
    r.attach(ellipsoid(n + "_imask", HC + V((0.07, 0, 0.0)), (0.07, 0.11, 0.14), METAL()), "head")
    r.attach(box(n + "_slit", HC + V((0.135, 0, 0.03)), (0.01, 0.12, 0.012), C("black", (20, 18, 22))), "head")
    r.attach(box(n + "_cross", HC + V((0.137, 0, -0.03)), (0.008, 0.02, 0.09), C("gold", (190, 150, 70))), "head")
def horns(r, n, col):
    for s in (1, -1):
        r.attach(loft(n + "_horn%d" % s, [(HC + V((-0.02, s * 0.07, 0.1)), 0.03, 0.03), (HC + V((-0.06, s * 0.16, 0.22)), 0.018, 0.018), (HC + V((-0.02, s * 0.2, 0.36)), 0.002, 0.002)], col, seg=6), "head")
    r.attach(loft(n + "_circlet", [(HC + V((0, 0, 0.06)), 0.135, 0.12), (HC + V((0, 0, 0.08)), 0.135, 0.12)], col, seg=12), "head")
def backpack(r, n, col):
    r.attach(box(n + "_pack", (-0.19, 0, 1.24), (0.16, 0.28, 0.34), col), "chest")
    r.attach(cyl(n + "_roll", (-0.2, -0.17, 1.44), (-0.2, 0.17, 1.44), 0.06, C("bedroll", (90, 80, 60))), "chest")
def lantern_pole(r, n):
    r.attach(box(n + "_pack", (-0.18, 0, 1.22), (0.14, 0.26, 0.30), METAL_D()), "chest")
    r.attach(cyl(n + "_lpole", (-0.22, 0.06, 1.1), (-0.26, 0.06, 2.05), 0.014, METAL_D(), seg=5), "chest")
    r.attach(cyl(n + "_larm", (-0.26, 0.06, 2.05), (-0.08, 0.06, 2.12), 0.012, METAL_D(), seg=4), "chest")
    r.attach(ellipsoid(n + "_lamp", (-0.08, 0.06, 2.04), (0.05, 0.05, 0.07), F("lantern_g", (255, 220, 140), (255, 200, 110), 6)), "chest")
def tanks(r, n):
    for s in (1, -1): r.attach(cyl(n + "_tank%d" % s, (-0.2, s * 0.09, 0.98), (-0.2, s * 0.09, 1.48), 0.08, RUST(), seg=10), "chest")
    r.attach(loft(n + "_hose", [((-0.2, 0, 1.0), 0.015, 0.015), ((-0.05, -0.2, 0.95), 0.015, 0.015), ((0.2, -0.12, 1.15), 0.015, 0.015)], C("hose", (40, 38, 40)), seg=6), "chest")
def chains(r, n):
    for k in range(6):
        r.attach(loft(n + "_chain%d" % k, [((0.11, -0.12 + 0.05 * k, 1.35 - 0.05 * k), 0.01, 0.01), ((0.12, -0.10 + 0.05 * k, 1.10 - 0.04 * k), 0.01, 0.01)], METAL_D(), seg=4), "chest")
def bandolier(r, n):
    r.attach(box(n + "_band", (0.11, -0.01, 1.25), (0.02, 0.045, 0.48), STRAP(), rot=(math.radians(-34), 0, 0)), "chest")
    for k in range(6): r.attach(box(n + "_shell%d" % k, (0.125, -0.13 + 0.05 * k, 1.07 + 0.075 * k), (0.012, 0.012, 0.035), C("brass", (190, 150, 70))), "chest")
def net_bundle(r, n):
    r.attach(ellipsoid(n + "_net", (-0.06, 0.18, 1.44), (0.14, 0.12, 0.12), C("net", (130, 120, 90))), "chest")
    for k in range(4): r.attach(cyl(n + "_nw%d" % k, (-0.06, 0.06 + 0.06 * k, 1.56), (-0.06, 0.06 + 0.06 * k, 1.32), 0.008, C("rope", (160, 140, 100)), seg=3), "chest")
def shoulder_spikes(r, n):
    for s, b in ((1, "shoulder.L"), (-1, "shoulder.R")):
        r.attach(ellipsoid(n + "_spad%d" % s, (-0.01, s * 0.18, 1.43), (0.09, 0.08, 0.06), METAL_D(), clip_z=-0.2), b)
        for k in range(3): r.attach(loft(n + "_spk%d%d" % (s, k), [((-0.04 + 0.04 * k, s * 0.2, 1.47), 0.015, 0.015), ((-0.05 + 0.04 * k, s * 0.24, 1.58), 0.002, 0.002)], METAL(), seg=4), b)
def armband(r, n, col):
    r.attach(loft(n + "_armb", [((-0.02, 0.2, 1.30), 0.056, 0.056), ((-0.022, 0.2, 1.26), 0.056, 0.056)], col), "upperarm.L")
def skulls_belt(r, n):
    for k, y in enumerate((-0.1, 0.0, 0.1)):
        r.attach(ellipsoid(n + "_bsk%d" % k, (0.13, y, 0.9), (0.035, 0.03, 0.04), C("bone", (210, 200, 176))), "spine")
def pale_chest(r, n):
    """Pokutnik: obnazony tors z bliznami zamiast kurtki."""
    for k in ("_jkt_lo", "_jkt_up", "_collar", "_strap"):
        import bpy
        if n + k in bpy.data.objects: bpy.data.objects[n + k].hide_render = True
    sk = C("skin_p", (188, 150, 128))
    r.attach(loft(n + "_torso", [((0, 0, 0.9), 0.1, 0.145), ((0, 0, 1.25), 0.1, 0.15), ((0, 0, 1.42), 0.105, 0.165), ((0, 0, 1.50), 0.05, 0.06)], sk), "chest")
    for k in range(4): r.attach(box(n + "_scar%d" % k, (0.105, -0.08 + 0.05 * k, 1.25 + 0.03 * k), (0.008, 0.012, 0.12), FLESH(), rot=(0.4, 0, 0)), "chest")

def swap_rifle(r, n, objs):
    import bpy
    for k in ("_stock", "_rbody", "_fore", "_barrel", "_sight", "_mag"):
        if n + k in bpy.data.objects: bpy.data.objects[n + k].hide_render = True
    WP.place(objs, (0.24, -0.09, 1.25))
    for o in objs: r.attach(o, "weapon")
def hand_prop(r, objs, rot=(0, math.pi / 2, 0), bone="hand.R"):
    b = r.ob.data.bones[bone]
    WP.place(objs, V(b.tail_local) + V((0.02, 0, 0.03)), rot)
    for o in objs: r.attach(o, bone)
def recolor(name, m):
    import bpy
    ob = bpy.data.objects.get(name)
    if ob: ob.data.materials.clear(); ob.data.materials.append(m)
def staff(r, n, orb_col):
    import bpy
    for k in ("_spear", "_spearhead", "_shield", "_boss", "_shrim"):
        if n + k in bpy.data.objects: bpy.data.objects[n + k].hide_render = True
    r.attach(cyl(n + "_staff", (0.29, -0.25, 0.05), (0.31, -0.25, 2.0), 0.02, WOOD(), seg=6), "weapon")
    r.attach(ellipsoid(n + "_orb", (0.31, -0.25, 2.07), (0.07, 0.07, 0.07), orb_col), "weapon")
    for k in range(3):
        a = k * 2.1
        r.attach(loft(n + "_claw%d" % k, [((0.31, -0.25, 1.97), 0.012, 0.012), ((0.31 + 0.08 * math.cos(a), -0.25 + 0.08 * math.sin(a), 2.08), 0.008, 0.008), ((0.31 + 0.03 * math.cos(a), -0.25 + 0.03 * math.sin(a), 2.17), 0.002, 0.002)], WOOD(), seg=4), "weapon")

# ------------------------------------------------------------------ jednostki: (frakcja, nazwa, budowniczy) ; budowniczy zwraca (rig, poza)
def u_nozownik(n):
    r = human(n, dict(jacket="brown", pants="darkgrey", hair="hair", strap=False), "idle"); scarf_mask(r, n, C("rag_r", (120, 50, 44))); hand_prop(r, WP.noz()); skulls_belt(r, n); return r, "knife"
def u_obrzyn(n):
    r = human(n, dict(jacket="leather", pants="brown", beard=True), "idle"); hat_wide(r, n, C("hat_b", (70, 56, 46))); bandolier(r, n); hand_prop(r, WP.obrzyn()); return r, "pistol"
def u_herszt(n):
    r = human(n, dict(jacket="leather", pants="darkgrey", armor="plate", beard=True), "rifle"); cape(r, n, C("cape_b", (70, 50, 40)), fur=C("fur", (120, 100, 80))); shoulder_spikes(r, n); skulls_belt(r, n); return r, "rifle"
def u_plomieniarz(n):
    r = human(n, dict(jacket="grey", pants="grey", mask="gas", armor="vest"), "rifle"); tanks(r, n); armband(r, n, C("white_a", (220, 216, 200)))
    swap_rifle(r, n, WP.miotacz()[6:]); return r, "rifle"
def u_inkwizytor(n):
    r = human(n, dict(jacket="grey", pants="darkgrey", helmet=None), "banner"); robe(r, n, C("robe_w", (196, 190, 176))); iron_mask(r, n); cape(r, n, C("cape_w", (180, 172, 160)))
    recolor(n + "_flag", C("flag_w", (220, 216, 200))); recolor(n + "_emblem", F("emb_r", (200, 40, 40), (200, 30, 30), 2)); return r, "banner"
def u_pokutnik(n):
    r = human(n, dict(jacket="grey", pants="darkgrey", strap=False, pouches=False), "hammer"); pale_chest(r, n); hood(r, n, C("hood_g", (110, 104, 96))); chains(r, n); return r, "hammer"
def u_kaplan(n):
    r = human(n, dict(jacket="teal", pants="darkgrey"), "spear"); robe(r, n, C("robe_t", (60, 80, 78))); hood(r, n, C("hood_t", (54, 72, 70))); staff(r, n, F("orb_g", (150, 230, 160), (120, 230, 140), 5)); return r, "staff"
def u_wierny(n):
    r = human(n, dict(skin="pale", jacket="teal", pants="brown", third_arm=True, glow_eyes=True, strap=False), "idle"); hand_prop(r, WP.noz()); return r, "idle"
def u_pasterz_choru(n):
    r = human(n, dict(skin="pale", jacket="darkgrey", pants="darkgrey", glow_eyes=True), "spear"); robe(r, n, C("robe_d", (50, 54, 62)), 0.1); horns(r, n, C("horn", (190, 180, 150)))
    staff(r, n, F("orb_r", (255, 90, 70), (255, 60, 40), 5)); cape(r, n, C("cape_d", (44, 46, 54))); return r, "staff"
def u_konwojent(n):
    r = human(n, dict(jacket="olive", pants="brown"), "rifle"); cap(r, n, C("cap_o", (70, 80, 56))); goggles(r, n); backpack(r, n, C("pack", (90, 80, 56))); bandolier(r, n); return r, "rifle"
def u_maszynista(n):
    r = human(n, dict(jacket="blue", pants="blue", strap=False, beard=True), "idle"); cap(r, n, C("cap_k", (40, 40, 48))); goggles(r, n)
    hand_prop(r, [box(n + "_wrench", (0, 0, -0.25), (0.04, 0.02, 0.5), METAL_D()), box(n + "_wjaw", (0, 0, -0.52), (0.09, 0.03, 0.06), METAL_D())], rot=(0, 0, 0)); return r, "idle"
def u_ciezki(n):
    r = human(n, dict(jacket="olive", pants="olive", helmet="mil", armor="vest"), "rifle"); backpack(r, n, C("pack", (90, 80, 56))); swap_rifle(r, n, WP.km()); return r, "rifle"
def u_sieciarz(n):
    r = human(n, dict(jacket="leather", pants="brown", strap=False), "spear"); net_bundle(r, n); scarf_mask(r, n, C("rag_d", (70, 64, 60)))
    import bpy
    for k in ("_shield", "_boss", "_shrim"): bpy.data.objects[n + k].hide_render = True
    return r, "spear"
def u_lowca(n):
    r = human(n, dict(jacket="leather", pants="darkgrey", hair="hair_l"), "bow"); skull_mask(r, n); cape(r, n, C("cape_l", (90, 70, 50)), fur=C("fur_d", (90, 76, 62))); return r, "bow"
def u_poganiacz(n):
    r = human(n, dict(jacket="brown", pants="darkgrey", armor="plate"), "idle"); skull_mask(r, n); chains(r, n)
    hand_prop(r, [loft(n + "_whip", [((0, 0, 0), 0.02, 0.02), ((0, 0, -0.35), 0.015, 0.015), ((0.15, 0, -0.75), 0.006, 0.006), ((0.35, 0.1, -0.85), 0.004, 0.004)], C("whip", (70, 50, 36)), seg=4)], rot=(0, 0, 0)); return r, "idle"
def u_latarnik(n):
    r = human(n, dict(jacket="blue", pants="darkgrey", helmet="mil", mask="gas", armor="plate"), "rifle"); lantern_pole(r, n); armband(r, n, C("yel_a", (210, 180, 70))); return r, "rifle"
def u_latarnik_oficer(n):
    r = human(n, dict(jacket="blue", pants="darkgrey", helmet="mil", armor="plate"), "banner"); cape(r, n, C("cape_bl", (44, 56, 90)))
    recolor(n + "_flag", C("flag_bl", (50, 64, 110))); armband(r, n, C("yel_a", (210, 180, 70))); return r, "banner"
def u_latarnik_ciezki(n):
    r = human(n, dict(jacket="blue", pants="darkgrey", helmet="mil", mask="gas", armor="plate"), "rifle"); lantern_pole(r, n); swap_rifle(r, n, WP.km()); return r, "rifle"
def u_dezerter(n):
    r = human(n, dict(jacket="olive", pants="brown", beard=True), "rifle"); scarf_mask(r, n, C("rag_o", (80, 86, 60))); backpack(r, n, C("pack_r", (80, 70, 54))); return r, "rifle"

FACTIONS = [
    ("Szabrownicy", [("Nożownik", u_nozownik), ("Obrzyn", u_obrzyn), ("Herszt", u_herszt)]),
    ("Synowie Czystości", [("Płomieniarz", u_plomieniarz), ("Inkwizytor", u_inkwizytor), ("Pokutnik", u_pokutnik)]),
    ("Chór Mgły", [("Kapłan", u_kaplan), ("Odmieniony Wierny", u_wierny), ("Pasterz Chóru", u_pasterz_choru)]),
    ("Ludzie Toru", [("Konwojent", u_konwojent), ("Maszynista", u_maszynista), ("Ciężki karabin", u_ciezki)]),
    ("Łowcy Głów", [("Sieciarz", u_sieciarz), ("Łowca", u_lowca), ("Poganiacz", u_poganiacz)]),
    ("Zakon Latarników", [("Żołnierz Wzoru", u_latarnik), ("Oficer", u_latarnik_oficer), ("Ciężki Wzoru", u_latarnik_ciezki)]),
]
