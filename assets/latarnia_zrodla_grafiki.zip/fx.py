"""Efekty: luski, dym z lufy, wypadajacy magazynek, iskry i drzazgi, wybuch. Prosta fizyka klatka po klatce (12 kl/s)."""
import math, random
from mathutils import Vector as V
from lat3d import *
DT = 1 / 12
_mats = {}
def _m(key, rgb, **kw):
    if key not in _mats: _mats[key] = mat("fx_" + key, rgb, pass_index=3, **kw)
    return _mats[key]

class FX:
    def __init__(self):
        self.parts = []; self.n = 0; self.rnd = random.Random(7)
    def _obj(self, kind):
        self.n += 1; nm = "fx%d" % self.n
        if kind == "shell": o = cyl(nm, (0, 0, -0.012), (0, 0, 0.012), 0.006, _m("brass", (200, 160, 70)), seg=5)
        elif kind == "puff": o = ellipsoid(nm, (0, 0, 0), (0.06, 0.06, 0.05), _m("smoke", (128, 124, 134)), u=8, v=6)
        elif kind == "dark": o = ellipsoid(nm, (0, 0, 0), (0.06, 0.06, 0.05), _m("smoke_d", (70, 66, 74)), u=8, v=6)
        elif kind == "spark": o = ellipsoid(nm, (0, 0, 0), (0.018, 0.018, 0.018), _m("spark", (255, 220, 140), emit=(255, 200, 110), strength=10), u=5, v=4)
        elif kind == "chip": o = box(nm, (0, 0, 0), (0.05, 0.02, 0.012), _m("chip", (140, 104, 64)))
        elif kind == "dirt": o = box(nm, (0, 0, 0), (0.05, 0.05, 0.04), _m("dirt", (70, 60, 52)))
        elif kind == "mag": o = box(nm, (0, 0, 0), (0.05, 0.03, 0.09), _m("magfx", (70, 70, 80)))
        elif kind == "fire": o = ellipsoid(nm, (0, 0, 0), (0.1, 0.1, 0.08), _m("fire", (255, 190, 100), emit=(255, 160, 70), strength=12), u=8, v=6)
        char_collection().objects.link(o)
        o.pass_index = 3
        return o
    def spawn(self, kind, pos, vel=(0, 0, 0), life=12, grow=0.0, s0=1.0, spin=0.0, drag=0.0, grav=True):
        o = self._obj(kind)
        self.parts.append(dict(o=o, p=V(pos), v=V(vel), age=0, life=life, grow=grow, s=s0, spin=spin, drag=drag, grav=grav, rest=False))
    def step(self):
        for q in self.parts:
            o = q["o"]
            if q["age"] > q["life"]: o.hide_render = True; continue
            o.hide_render = False
            o.location = q["p"]; o.scale = (q["s"],) * 3
            o.rotation_euler = (q["spin"] * q["age"], q["spin"] * 0.7 * q["age"], 0)
            if not q["rest"]:
                if q["grav"]: q["v"].z -= 9.8 * DT
                q["v"] *= (1 - q["drag"])
                q["p"] = q["p"] + q["v"] * DT
                if q["p"].z < 0.015 and q["grav"]:
                    q["p"].z = 0.015
                    if abs(q["v"].z) > 1.2: q["v"].z = -q["v"].z * 0.35; q["v"].x *= 0.5; q["v"].y *= 0.5
                    else: q["rest"] = True; q["spin"] = 0
            q["s"] = max(0.0, q["s"] + q["grow"])
            q["age"] += 1
    # ---- gotowe zestawy
    def shot(self, rig):
        mz = rig.objs["muzzle"].matrix_world; ej = rig.objs["eject"].matrix_world
        fwd = (mz.to_3x3() @ V((1, 0, 0))).normalized(); right = (ej.to_3x3() @ V((0, -1, 0))).normalized()
        r = self.rnd
        if getattr(rig, "pose", "") in ("lance", "crossbow", "musket"): pass
        else: self.spawn("shell", ej.translation, right * 1.6 + V((0, 0, 2.2)) - fwd * 0.3, life=30, spin=1.3)
        pz = getattr(rig, "pose", "")
        if pz == "lance": return
        for k in range(5 if pz == "musket" else 2):
            self.spawn("puff", mz.translation + fwd * (0.06 + 0.08 * k), fwd * (0.5 - 0.2 * k) + V((0, 0, 0.25)), life=7 + 2 * k + (6 if pz == 'musket' else 0), grow=0.18 + (0.1 if pz == 'musket' else 0), s0=0.5, drag=0.25, grav=False)
    def mag_drop(self, rig):
        m = rig.objs["maghand"].matrix_world.translation
        self.spawn("mag", m, V((0, 0, -0.5)), life=60, spin=0.6)
    def impact(self, pos, n=6, wood=True):
        r = self.rnd
        for k in range(n):
            d = V((r.uniform(-1, 1), r.uniform(-1, 1), r.uniform(0.3, 1.4)))
            self.spawn("spark", pos, d * 2.6, life=3 + r.randint(0, 2), grav=False, drag=0.2)
            if wood: self.spawn("chip", pos, d * 1.6, life=24, spin=1.5)
    def explosion(self, pos):
        r = self.rnd; P0 = V(pos)
        self.spawn("fire", P0 + V((0, 0, 0.2)), (0, 0, 0.5), life=3, grow=0.9, s0=1.4, grav=False)
        for k in range(10):
            a = 2 * math.pi * k / 10
            d = V((math.cos(a), math.sin(a), r.uniform(0.6, 2.0)))
            self.spawn("dirt", P0 + V((0, 0, 0.1)), d * r.uniform(2.0, 3.5), life=26, spin=1.2)
        for k in range(8):
            a = 2 * math.pi * k / 8 + 0.3
            self.spawn("dark" if k % 2 else "puff", P0 + V((0.25 * math.cos(a), 0.25 * math.sin(a), 0.15)),
                       V((math.cos(a), math.sin(a), 0.6)) * 0.9, life=16, grow=0.22, s0=1.2, drag=0.15, grav=False)

def watch_events(fx, rig, state):
    """Wykrywa wystrzal (blysk widoczny) i wyrzut magazynka (magazynek opuscil dlon, a w broni go nie ma)."""
    o = getattr(rig, "objs", {})
    if "flash" in o:
        fl = not o["flash"].hide_render
        if fl and not state.get("fl"): fx.shot(rig)
        state["fl"] = fl
    if "maghand" in o:
        mh = not o["maghand"].hide_render; mg = not o["mag"].hide_render
        if state.get("mh") and not mh and not mg: fx.mag_drop(rig)
        state["mh"] = mh

def _extra(self, kind):
    nm = "fxx%d" % self.n; self.n += 1
    if kind == "gore": o = ellipsoid(nm, (0, 0, 0), (0.05, 0.04, 0.04), _m("gore", (120, 36, 36)), u=6, v=4)
    elif kind == "bloat": o = ellipsoid(nm, (0, 0, 0), (0.06, 0.05, 0.04), _m("bloatfx", (92, 104, 60)), u=6, v=4)
    elif kind == "gas": o = ellipsoid(nm, (0, 0, 0), (0.1, 0.1, 0.08), _m("gas", (150, 170, 70), emit=(120, 150, 40), strength=0.6), u=10, v=8)
    elif kind == "ring":
        bpy.ops.mesh.primitive_torus_add(major_radius=1.0, minor_radius=0.018, major_segments=40, minor_segments=4)
        o = bpy.context.active_object; o.name = nm; o.data.materials.append(_m("ring", (190, 180, 240), emit=(150, 130, 230), strength=1.4))
        for c in o.users_collection: c.objects.unlink(o)
        bpy.context.scene.collection.objects.link(o)
    else: return None
    return o
_orig = FX._obj
def _obj2(self, kind):
    o = _extra(self, kind)
    if o is None: return _orig(self, kind)
    char_collection().objects.link(o); o.pass_index = 3
    return o
FX._obj = _obj2

def burst(fx, pos):
    r = fx.rnd; P0 = V(pos)
    fx.spawn("fire", P0, (0, 0, 0.2), life=2, grow=0.8, s0=1.6, grav=False)
    for k in range(14):
        a = 2 * math.pi * k / 14 + r.uniform(-0.2, 0.2)
        d = V((math.cos(a), math.sin(a), r.uniform(0.5, 1.8)))
        fx.spawn("gore" if k % 2 else "bloat", P0, d * r.uniform(2.0, 3.8), life=40, spin=1.0)
    for k in range(9):
        a = 2 * math.pi * k / 9
        fx.spawn("gas", P0 + V((0.3 * math.cos(a), 0.3 * math.sin(a), -0.3 + 0.1 * (k % 3))), V((math.cos(a), math.sin(a), 0.15)) * 0.7,
                 life=40, grow=0.12, s0=1.5, drag=0.12, grav=False)

def ring(fx, pos, life=6):
    fx.spawn("ring", V(pos), (0, 0, 0), life=life, grow=0.3, s0=0.2, grav=False)
