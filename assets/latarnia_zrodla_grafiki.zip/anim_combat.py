"""Animacje walki do symulatora bitew (Godot): pelne zestawy klipow dla kazdej broni epoki Zlomu,
ranny na ziemi, opatrywanie, wyciaganie rannego, kulenie sie, blok tarcza, luk i kusza z cieciwa,
oraz mutanty (Ogar, Krzykacz, Nosiciel, szczur).

Konwencje jak w anim.py: postac patrzy w +X, lewo = +Y, 12 kl/s.
Dodatkowe klucze pozy: "bscl" = skala kosci (0/1) do wlaczania czesci (cieciwa naciagnieta, strzala, belt).
"""
import math
from anim import (P, merge, lerp_pose, Clip, ease, stance, arms_down, breathe, walk, run, wide, guard1, kneel,
                  crouch, flinch, clip_spear, clip_hammer, clip_slash, clip_death, low_ready, aim, recoil)

# ================================================================== pomocnicze
def bscl(**kw):
    p = P(); p["bscl"] = dict(kw); return p

def M(*ps):
    out = merge(*ps)
    sc = {}
    for p in ps: sc.update(p.get("bscl", {}))
    if sc: out["bscl"] = sc
    return out

def L(a, b, t):
    out = lerp_pose(a, b, t)
    sa, sb = a.get("bscl", {}), b.get("bscl", {})
    if sa or sb:
        out["bscl"] = dict(sa); out["bscl"].update(sb if t >= 0.5 else {})
    return out

class C(Clip):
    """Clip, ktory przenosi skale kosci (bscl) z klatki kluczowej."""
    def sample(self, f):
        f2 = f % self.length if self.loop else min(f, self.length)
        ks = self.keys
        for i in range(len(ks)):
            f0, p0, e0 = ks[i]
            f1, p1 = (ks[i + 1][0], ks[i + 1][1]) if i + 1 < len(ks) else (self.length, ks[0][1] if self.loop else p0)
            if f0 <= f2 < f1 or i == len(ks) - 1:
                t = 0 if f1 == f0 else min(max((f2 - f0) / (f1 - f0), 0), 1)
                return L(p0, p1, ease(t, e0))
        return ks[0][1]

FREE = {"forearm.L": 0.0, "forearm.R": 0.0}

# bron na plecach: dla kazdej broni punkt obrotu kosci "weapon" (spoczynkowy), os broni i docelowe polozenie na plecach
from mathutils import Vector as _V, Matrix as _Mx, Quaternion as _Q

def _orient(head0, axis0, head1, axis1, extra=None):
    q = _V(axis0).normalized().rotation_difference(_V(axis1).normalized())
    if extra is not None: q = q @ extra
    e = q.to_matrix().to_euler("XYZ")
    d = _V(head1) - _V(head0)
    return (math.degrees(e.x), math.degrees(e.y), math.degrees(e.z)), (d.x, d.y, d.z)

_SLING = {   # kind: (punkt obrotu, os broni w spoczynku, nowy punkt, nowa os)
    "spear": ((0.29, -0.25, 1.18), (0, 0, 1), (-0.24, -0.02, 1.22), (0, 0.32, 1)),
    "hammer": ((0.20, -0.125, 1.10), (-0.56, -0.04, 0.76), (-0.20, 0.16, 0.98), (0.0, -0.42, 1)),
    "club": ((0.16, -0.26, 0.86), (0.14, 0, 0.16), (-0.19, 0.14, 1.02), (0.0, -0.45, 1)),
    "machete": ((0.16, -0.26, 0.86), (0.14, 0, 0.16), (-0.19, 0.14, 1.02), (0.0, -0.45, 1)),
    "knife": ((0.16, -0.26, 0.86), (0.14, 0, 0.16), (0.05, -0.17, 0.98), (0.1, 0.0, -1)),
    "crossbow": ((0.26, -0.105, 1.26), (math.cos(0.143), 0, -math.sin(0.143)), (-0.21, -0.16, 1.50), (0.0, 0.40, -1)),
}

def slung(kind):
    ik = dict(FREE)
    if kind == "bow":
        q = _Q((1, 0, 0), math.radians(-28)) @ _Q((0, 0, 1), math.radians(90))
        e = q.to_matrix().to_euler("XYZ"); d = _V((-0.22, 0.0, 1.26)) - _V((0.49, 0.03, 1.40))
        return P(rot={"weapon": (math.degrees(e.x), math.degrees(e.y), math.degrees(e.z))}, loc={"weapon": tuple(d)}, ik=ik)
    if kind not in _SLING: return P(ik=ik)
    rot, loc = _orient(*_SLING[kind])
    p = P(rot={"weapon": rot}, loc={"weapon": loc}, ik=ik)
    if kind == "spear":   # tarcza na plecy: obrot 180 wokol pionu, pod wlocznia
        p["rot"]["shield"] = (0, 0, 180); p["loc"]["shield"] = (-0.47, -0.10, 0.06)
    return p

def dropped(kind):
    """Bron lezy na ziemi obok lezacego (pozy lezace: cialo obrocone o -88 st. wokol Y, wiec +X ciala patrzy w niebo)."""
    d = {"spear": P(rot={"weapon": (0, 0, 0), "shield": (0, 0, 0)}, loc={"weapon": (-0.16, -0.42, -0.25), "shield": (-0.20, 0.36, -0.30)}),
         "bow": P(rot={"weapon": (0, 0, 90)}, loc={"weapon": (-0.62, -0.45, -0.35)}),
         "crossbow": P(rot={"weapon": (0, 90, 0)}, loc={"weapon": (-0.18, -0.40, -0.30)}),
         "hammer": P(rot={"weapon": (0, 36, 0)}, loc={"weapon": (-0.20, -0.42, -0.20)}),
         }.get(kind, P(rot={"weapon": (0, -41, 0)}, loc={"weapon": (-0.14, -0.30, -0.10)}))
    d["ik"] = dict(FREE)
    return d

def wready(kind):
    """Tylko bron z postawy gotowosci (do klatek, w ktorych cialo reaguje, a rece wciaz trzymaja bron)."""
    r = ready(kind)
    keys = ("weapon", "shield")
    return P(rot={k: v for k, v in r["rot"].items() if k in keys}, loc={k: v for k, v in r["loc"].items() if k in keys}, tgt=r["tgt"], ik=r["ik"])

def fall_bodies():
    base = merge(stance(), arms_down())
    hit = merge(base, P(rot={"spine": (0, -16, 6), "chest": (0, -12, 8), "head": (0, -22, 10), "thigh.R": (0, 24, 0), "shin.R": (0, 12, 0)}, loc={"hips": (-0.06, 0, 0)}))
    buckle = merge(base, P(rot={"spine": (0, 8, 0), "chest": (0, 6, -4), "head": (0, 14, 0), "thigh.L": (0, -30, 0), "shin.L": (0, 60, 0),
                                "thigh.R": (0, -10, 0), "shin.R": (0, 70, 0)}, loc={"hips": (-0.04, 0, -0.22)}))
    fall = merge(base, P(rot={"spine": (0, -10, 0), "head": (0, -20, 0), "upperarm.L": (40, -20, 0), "upperarm.R": (-40, -25, 0),
                              "thigh.L": (0, -40, 0), "shin.L": (0, 50, 0), "thigh.R": (0, -20, 0), "shin.R": (0, 30, 0)},
                     loc={"hips": (0, 0, -0.10)}, root=(-0.15, 0, 0.0, -84)))
    lie = merge(base, P(rot={"spine": (0, -4, 0), "head": (0, -10, 12), "upperarm.L": (60, -30, 0), "upperarm.R": (-55, -40, 0),
                             "forearm.L": (0, -30, 0), "thigh.L": (0, -30, 0), "shin.L": (0, 40, 0), "thigh.R": (0, -10, 0), "shin.R": (0, 10, 0)},
                    loc={"hips": (0, 0, -0.10)}, root=(-0.15, 0, 0.0, -89)))
    return hit, buckle, fall, lie

# ================================================================== postawy bazowe dla broni
def ready(kind):
    if kind == "spear":
        return merge(stance(), P(rot={"weapon": (0, 82, 0), "chest": (0, 2, -6)}, loc={"weapon": (0.0, 0.0, 0.22), "shield": (0.02, 0, 0.08)}))
    if kind == "hammer":
        return merge(stance(), P(rot={"spine": (0, 2, 0), "head": (0, 3, 0)}))   # mlot na ramieniu (poza spoczynkowa broni)
    if kind in ("club", "knife", "machete"):
        return merge(wide(), guard1())
    if kind == "bow":
        return merge(stance(), bow_low())
    if kind == "crossbow":
        return merge(wide(), low_ready(), bscl(c_str_cock=1, c_str_rel=0, c_bolt=1))
    return merge(stance(), arms_down())

def bow_low():
    """Luk nisko w lewej rece, prawa reka przy cieciwie (strzala jeszcze w kolczanie)."""
    return P(rot={"weapon": (0, 0, 0), "chest": (0, 0, 8), "head": (0, 2, -4)},
             loc={"weapon": (-0.16, 0.06, -0.34)}, tgt={"ikR": (0.22, 0.10, -0.40)}, ik={"forearm.R": 1.0, "forearm.L": 1.0},
             ) | {"bscl": {"b_str_rest": 1, "b_str_draw": 0, "b_arrow": 0}}

def idle_clip(kind):
    r = ready(kind)
    return C(24, [(0, M(r, breathe(0, 24)), "io"), (12, M(r, breathe(6, 24)), "io")], loop=True)

def walk_fn(kind):
    r = ready(kind)
    def fn(f):
        w = walk(f, 12, stride=24, arms=False)
        base = M(w, P(rot={k: v for k, v in r["rot"].items() if not k.startswith(("thigh", "shin", "foot"))}, loc={k: v for k, v in r["loc"].items() if k != "hips"},
                       tgt=r["tgt"], ik=r["ik"]))
        if "bscl" in r: base["bscl"] = dict(r["bscl"])
        if kind in ("club", "knife", "machete", "bow") and False: pass
        return base
    return fn

def run_fn(kind):
    r = ready(kind)
    def fn(f):
        w = run(f, 8, stride=38, arms=False)
        keep = {k: v for k, v in r["rot"].items() if not k.startswith(("thigh", "shin", "foot", "spine", "chest", "head"))}
        base = M(w, P(rot=keep, loc={k: v for k, v in r["loc"].items() if k != "hips"}, tgt=r["tgt"], ik=r["ik"]))
        if kind in ("club", "knife", "machete"):    # wolna reka pracuje w biegu
            p = (f % 8) / 8
            base["rot"]["upperarm.L"] = (10, 30 * math.cos(2 * math.pi * p), 0); base["rot"]["forearm.L"] = (0, -80, 0)
        if "bscl" in r: base["bscl"] = dict(r["bscl"])
        return base
    return fn

# ================================================================== ataki
def clip_thrust():
    """Pchniecie wlocznia zza tarczy: krotsze niz pokazowe (12 kl), antycypacja, wypad, powrot."""
    guard = ready("spear")
    wind = merge(guard, P(rot={"weapon": (0, 7, 0), "chest": (0, -4, 14), "spine": (0, -3, 4), "thigh.R": (0, 6, 0), "shin.R": (0, 10, 0)},
                         loc={"weapon": (-0.28, 0.02, 0.02), "hips": (-0.05, 0, -0.03)}))
    thrust = merge(stance(), P(rot={"weapon": (0, 64, 0), "chest": (0, 10, -18), "spine": (0, 6, -6),
                                    "thigh.L": (0, -32, 0), "shin.L": (0, 30, 0), "foot.L": (0, 6, 0), "thigh.R": (0, 26, 0), "shin.R": (0, 6, 0)},
                               loc={"weapon": (0.50, 0.0, 0.18), "shield": (0.06, 0, 0.05), "hips": (0.12, 0, -0.08)}))
    return C(12, [(0, guard, "io"), (3, wind, "hold"), (4, wind, "snap"), (5, thrust, "hold"), (7, thrust, "io"), (11, guard, "hold")])

def clip_block():
    """Tarcza w gore na uderzenie: szarpniecie, przyjecie ciosu, powrot."""
    guard = ready("spear")
    up = merge(guard, P(rot={"shield": (0, -8, -10), "chest": (0, -6, 10), "head": (0, 10, -6), "thigh.R": (0, 10, 0), "shin.R": (0, 14, 0)},
                        loc={"shield": (0.10, 0.0, 0.14), "hips": (-0.04, 0, -0.06)}))
    hit = merge(up, P(rot={"spine": (0, -6, 0), "chest": (0, -4, 0)}, loc={"shield": (-0.06, 0, 0), "hips": (-0.06, 0, -0.07)}))
    return C(8, [(0, guard, "snap"), (2, up, "hold"), (3, hit, "out"), (5, up, "io"), (7, guard, "hold")], loop=False)

def clip_smash():
    """Mlot dwureczny: dluga antycypacja (ciezar), szybkie uderzenie, wyrwanie i powrot (20 kl)."""
    r = ready("hammer")
    wind = merge(stance(), P(rot={"weapon": (0, -55, 0), "spine": (0, -12, 0), "chest": (0, -6, 10), "head": (0, -6, 0), "foot.R": (0, 10, 0)},
                             loc={"weapon": (-0.06, 0, 0.12), "hips": (-0.04, 0, 0.02)}))
    strike = merge(stance(), P(rot={"weapon": (0, 118, 0), "spine": (0, 22, 0), "chest": (0, 14, -14), "head": (0, 10, 0),
                                    "thigh.L": (0, -34, 0), "shin.L": (0, 40, 0), "thigh.R": (0, 22, 0), "shin.R": (0, 20, 0)},
                               loc={"weapon": (0.20, 0, -0.10), "hips": (0.10, 0, -0.10)}))
    yank = merge(strike, P(rot={"weapon": (0, -16, 0), "spine": (0, -8, 0)}, loc={"hips": (-0.03, 0, 0.04)}))
    return C(20, [(0, r, "io"), (6, wind, "hold"), (8, wind, "in"), (10, strike, "hold"), (12, strike, "io"), (14, yank, "io"), (19, r, "hold")])

def clip_stab():
    """Noz: krotkie pchniecie z wypadem (8 kl)."""
    g = ready("knife")
    pull = merge(wide(), guard1(), P(rot={"chest": (0, -2, 14), "weapon": (0, 10, 0)}, loc={"weapon": (-0.12, 0.02, -0.02), "hips": (-0.03, 0, 0)}))
    stab = merge(wide(), P(rot={"weapon": (0, -70, 0), "chest": (0, 10, -18), "spine": (0, 6, -6), "upperarm.L": (14, -10, 0), "forearm.L": (0, -90, 0),
                                "thigh.L": (0, -28, 0), "shin.L": (0, 26, 0)},
                           loc={"weapon": (0.42, 0.10, 0.38), "hips": (0.10, 0, -0.07)}))
    return C(8, [(0, g, "io"), (2, pull, "hold"), (3, pull, "snap"), (4, stab, "hold"), (5, stab, "io"), (7, g, "hold")])

def clip_swing():
    """Rura/maczeta: ciecie po skosie (10 kl), to samo co pokazowe, ale szybsze."""
    base = clip_slash()
    return C(10, [(0, base.sample(0), "io"), (3, base.sample(4), "hold"), (4, base.sample(5), "snap"), (5, base.sample(7), "hold"), (6, base.sample(9), "io"), (9, base.sample(14), "hold")])

def clip_bash(kind):
    """Strzelec w zwarciu: uderzenie lukiem/kolba kuszy (8 kl)."""
    r = ready(kind)
    push = merge(r, P(rot={"chest": (0, 12, -16), "spine": (0, 8, 0), "thigh.L": (0, -26, 0), "shin.L": (0, 24, 0)},
                      loc={"weapon": (0.30, 0.0, 0.28), "hips": (0.10, 0, -0.06)}))
    return C(8, [(0, r, "io"), (2, merge(r, P(rot={"chest": (0, -4, 14)}, loc={"hips": (-0.03, 0, 0)})), "snap"), (4, push, "hold"), (5, push, "io"), (7, r, "hold")])

# ================================================================== luk
DRAWN = {"b_str_rest": 0, "b_str_draw": 1, "b_arrow": 1}
LOOSE = {"b_str_rest": 1, "b_str_draw": 0, "b_arrow": 0}

def bow_aim_pose(draw=1.0):
    """Luk w gorze, lewe ramie wyprostowane do celu, prawa dlon cofa sie do policzka (draw 0..1)."""
    return P(rot={"chest": (0, -2, 16), "spine": (0, -2, 4), "head": (0, 4, -16), "neck": (0, 2, -6), "weapon": (0, 0, 0)},
             loc={"weapon": (0.0, 0.0, 0.0)}, tgt={"ikR": (0.36 * (1 - draw), 0.06 * (1 - draw), -0.06 * (1 - draw))},
             ik={"forearm.R": 1.0, "forearm.L": 1.0})

def clip_bow_shoot():
    """Strzal z luku (24 kl): siegniecie do kolczanu, nalozenie, uniesienie, naciag, celowanie, puszczenie z odrzutem, powrot."""
    st = wide()
    low = M(st, bow_low())
    reach = M(st, bow_low(), P(rot={"chest": (0, 0, -18), "head": (0, 0, 10)}, tgt={"ikR": (-0.20, 0.18, 0.10)}, ik={"forearm.R": 0.0},
                               ) | {"rot": {**bow_low()["rot"], "upperarm.R": (-20, 60, 30), "forearm.R": (0, -120, 0), "chest": (0, 0, -18), "head": (0, 0, 10)}})
    nock = M(st, bow_low(), bscl(b_arrow=1), P(tgt={"ikR": (0.10, 0.02, -0.18)}))
    up = M(st, bow_aim_pose(0.0), bscl(b_arrow=1))
    half = M(st, bow_aim_pose(0.6), bscl(**DRAWN))
    full = M(st, bow_aim_pose(1.0), bscl(**DRAWN), P(rot={"chest": (0, -2, 2)}))
    loose = M(st, bow_aim_pose(1.0), bscl(**LOOSE), P(rot={"chest": (0, -6, 4), "head": (0, -2, 0)}, tgt={"ikR": (-0.12, -0.06, 0.02)}, loc={"weapon": (-0.04, 0, 0.03)}))
    return C(24, [(0, low, "io"), (3, reach, "io"), (6, nock, "io"), (8, up, "io"), (11, half, "in"), (13, full, "hold"), (15, full, "snap"),
                  (16, loose, "out"), (19, M(st, bow_aim_pose(0.3), bscl(**LOOSE)), "io"), (23, low, "hold")], loop=False)

# ================================================================== kusza
def clip_xbow_shoot():
    """Strzal z kuszy (8 kl): przylozenie, strzal z odrzutem, cieciwa zwolniona, belt znika."""
    S = wide()
    cocked = bscl(c_str_cock=1, c_str_rel=0, c_bolt=1); fired = bscl(c_str_cock=0, c_str_rel=1, c_bolt=0)
    return C(8, [(0, M(S, low_ready(), cocked), "io"), (3, M(S, aim(), cocked), "hold"), (4, M(S, aim(), cocked), "snap"),
                 (5, M(S, recoil(), fired, P(vis={})), "out"), (7, M(S, aim(), fired), "hold")], loop=False)

def clip_xbow_reload():
    """Napinanie kuszy (36 kl = 3 s): kusza dziobem w dol przed stopami, lewa stopa w strzemie, obie rece ciagna cieciwe
    do orzecha, prostowanie, belt z kolczanu, uniesienie do gotowosci."""
    fired = bscl(c_str_cock=0, c_str_rel=1, c_bolt=0); cocked0 = bscl(c_str_cock=1, c_str_rel=0, c_bolt=0); ready_ = bscl(c_str_cock=1, c_str_rel=0, c_bolt=1)
    stand = M(wide(), low_ready(), fired)
    nose = P(rot={"weapon": (0, 82, 0)}, loc={"weapon": (0.22, 0.06, -0.24)})
    down = M(stance(), nose, fired, P(rot={"spine": (0, 22, 0), "chest": (0, 6, 0), "head": (0, 16, 0)}, tgt={"ikR": (0.10, 0, 0), "ikL": (-0.10, 0.04, 0)}))
    foot = M(down, P(rot={"thigh.L": (0, -46, 0), "shin.L": (0, 58, 0), "foot.L": (0, -8, 0), "thigh.R": (0, 6, 0), "shin.R": (0, 14, 0)}, loc={"hips": (-0.03, 0, -0.06)}))
    grab = M(foot, P(rot={"spine": (0, 30, 0), "chest": (0, 12, 0), "thigh.R": (0, -16, 0), "shin.R": (0, 34, 0)}, tgt={"ikR": (0.34, 0.0, 0.0), "ikL": (0.08, 0.04, 0.0)}, loc={"hips": (-0.03, 0, -0.12)}))
    pull = M(foot, cocked0, P(rot={"spine": (0, 4, 0), "chest": (0, -4, 0), "head": (0, 6, 0)}, tgt={"ikR": (0.11, 0.0, 0.0), "ikL": (-0.15, 0.04, 0.0)}, loc={"hips": (0, 0, 0.01)}))
    reach = M(down, cocked0, P(rot={"head": (0, 10, 0)}, tgt={"ikR": (-0.20, 0.10, 0.10), "ikL": (-0.10, 0.04, 0)}))
    bolt = M(down, ready_, P(rot={"head": (0, 22, 0)}, tgt={"ikR": (0.12, 0.04, 0.02), "ikL": (-0.10, 0.04, 0)}))
    up = M(wide(), low_ready(), ready_)
    return C(36, [(0, stand, "io"), (4, down, "io"), (7, foot, "io"), (10, grab, "io"), (13, grab, "in"), (18, pull, "out"), (21, reach, "io"),
                  (25, bolt, "io"), (28, bolt, "io"), (33, up, "hold")], loop=False)

# ================================================================== reakcje, upadek, ranny
def clip_hit(kind):
    r = ready(kind)
    hit = merge(r, P(rot={"spine": (0, -12, 8), "chest": (0, -10, 10), "head": (0, -16, 8), "thigh.R": (0, 20, 0), "shin.R": (0, 14, 0)}, loc={"hips": (-0.05, 0, -0.03)}))
    if "bscl" in r: hit["bscl"] = dict(r["bscl"])
    return C(8, [(0, r, "snap"), (2, hit, "io"), (4, merge(hit, P(rot={"spine": (0, 6, 0)})), "io"), (7, r, "hold")], loop=False)

def down_pose(kind, k=0.0):
    """Ranny na plecach: jedna reka trzyma rane na brzuchu, glowa uniesiona, kolano zgiete; k = faza oddechu/wicia sie."""
    s = math.sin(2 * math.pi * k)
    base = merge(stance(), P(rot={"spine": (0, 4 + 3 * s, 0), "chest": (0, 6 + 2 * s, 0), "neck": (0, 16, 0), "head": (0, 10 + 4 * s, 16),
                                  "upperarm.L": (8, -64, 0), "forearm.L": (0, -96, 0), "upperarm.R": (-50, -20, 0), "forearm.R": (0, -30 - 8 * s, 0),
                                  "thigh.L": (0, -50 - 6 * s, 0), "shin.L": (0, 82 + 8 * s, 0), "foot.L": (0, -20, 0), "thigh.R": (0, -8, 6), "shin.R": (0, 12, 0)},
                             loc={"hips": (0, 0, -0.10)}, root=(-0.15, 0, 0.0, -88)))
    return merge(base, dropped(kind))

def clip_fall(kind):
    """Upadek po ciezkiej ranie (12 kl): szarpniecie, ugiete kolana, upadek na plecy z upuszczeniem broni, odbicie."""
    r = ready(kind); hit, buckle, fall, _ = fall_bodies(); w = wready(kind)
    lie = down_pose(kind, 0.0)
    return C(12, [(0, r, "snap"), (1, merge(hit, w), "io"), (4, merge(buckle, w), "in"), (7, merge(fall, dropped(kind)), "out"),
                  (8, merge(lie, P(root=(0, 0, 0, 5))), "io"), (10, lie, "hold")], loop=False)

def clip_down(kind):
    return C(24, [(0, down_pose(kind, 0.0), "io"), (12, down_pose(kind, 0.5), "io")], loop=True)

def clip_death2(kind):
    """Smierc (24 kl): trafienie, ugiecie, upadek, odbicie, bezwladnosc."""
    r = ready(kind); hit, buckle, fall, lie = fall_bodies(); w = wready(kind); d = dropped(kind)
    return C(24, [(0, r, "snap"), (2, merge(hit, w), "io"), (5, merge(hit, w, P(rot={"spine": (0, -4, 0)})), "io"), (8, merge(buckle, w), "in"),
                  (12, merge(fall, d), "out"), (13, merge(lie, d, P(root=(0, 0, 0, 6))), "io"), (15, merge(lie, d), "hold"), (23, merge(lie, d), "hold")], loop=False)

def dead_pose(kind):
    return clip_death2(kind).sample(23)

def treat_pose(kind, k):
    """Opatrywanie: kleczy przy rannym (ok. 0,6 m przed soba), dlonie uciskaja i bandazuja na przemian; bron na plecach."""
    s = math.sin(2 * math.pi * k); c = math.cos(2 * math.pi * k)
    return merge(kneel(), slung(kind), P(rot={"spine": (0, 34, 0), "chest": (0, 14, 0), "neck": (0, 10, 0), "head": (0, 18, 0),
                                              "upperarm.L": (10, -52 - 8 * s, 0), "forearm.L": (0, -34 + 10 * s, 0),
                                              "upperarm.R": (-10, -50 + 8 * s, 0), "forearm.R": (0, -36 - 10 * s, 0),
                                              "hand.L": (0, 10, 0), "hand.R": (0, 10, 0)}, loc={"hips": (0, 0, -0.02 + 0.01 * c)}))

def clip_treat(kind):
    return C(24, [(0, treat_pose(kind, 0.0), "io"), (6, treat_pose(kind, 0.25), "io"), (12, treat_pose(kind, 0.5), "io"), (18, treat_pose(kind, 0.75), "io")], loop=True)

def drag_fn(kind):
    """Wyciaganie rannego: tylem, pochylony, obie rece trzymaja rannego za szelki przed soba (ranny lezy z przodu)."""
    def fn(f):
        n = 16
        w = walk(-f, n, stride=18, arms=False)
        p = (f % n) / n
        out = merge(w, slung(kind), P(rot={"spine": (0, 40, 0), "chest": (0, 16, 0), "neck": (0, -10, 0), "head": (0, -16, 0),
                                           "upperarm.L": (8, -58, 0), "forearm.L": (0, -12, 0), "upperarm.R": (-8, -58, 0), "forearm.R": (0, -12, 0)},
                                      loc={"hips": (-0.10, 0, -0.14 + 0.01 * math.sin(4 * math.pi * p))}))
        for side in ("L", "R"):
            th = out["rot"]["thigh." + side]; out["rot"]["thigh." + side] = (th[0], th[1] - 26, th[2])
            sh = out["rot"]["shin." + side]; out["rot"]["shin." + side] = (sh[0], sh[1] + 24, sh[2])
        return out
    return fn

def dragged_pose(kind, k=0.0):
    """Ciagniety ranny: na plecach, rece nad glowa (w dloniach ciagnacego), glowa odchylona."""
    s = math.sin(2 * math.pi * k)
    base = merge(stance(), P(rot={"spine": (0, -2, 0), "neck": (0, -10, 0), "head": (0, -16, 8 * s),
                                  "upperarm.L": (20, 160, 0), "forearm.L": (0, -20, 0), "upperarm.R": (-20, 160, 0), "forearm.R": (0, -20, 0),
                                  "thigh.L": (0, -12, 0), "shin.L": (0, 20 + 6 * s, 0), "thigh.R": (0, -4, 0), "shin.R": (0, 8, 0)},
                             loc={"hips": (0, 0, -0.10)}, root=(-0.15, 0, 0.0, -89)))
    return merge(base, slung(kind))

def cower_pose(kind, k=0.0):
    """Panika: kuca, glowa w ramionach, bron przycisnieta do siebie, drzy."""
    s = math.sin(2 * math.pi * k * 3)
    base = merge(crouch(0.85), P(rot={"spine": (0, 26, 0), "chest": (0, 14, s), "neck": (0, 24, 0), "head": (0, 20, 0)}))
    if kind in ("club", "knife", "machete"):
        base = merge(base, P(rot={"upperarm.L": (20, -70, 0), "forearm.L": (0, -120, 0), "weapon": (0, -20, 0)}, loc={"weapon": (0.02, 0.08, 0.10)}))
    return base

def clip_cower(kind):
    return C(24, [(0, cower_pose(kind, 0.0), "lin"), (6, cower_pose(kind, 0.25), "lin"), (12, cower_pose(kind, 0.5), "lin"), (18, cower_pose(kind, 0.75), "lin")], loop=True)

def clip_shout():
    """Okrzyk dowodcy (rozkaz): wyrzut wolnej reki w kierunku, glowa w bok."""
    r = merge(stance(), arms_down())
    pt = merge(stance(), P(rot={"upperarm.L": (40, -80, 0), "forearm.L": (0, -10, 0), "chest": (0, -4, 14), "head": (0, -8, 18), "neck": (0, -6, 0)}))
    return C(12, [(0, r, "io"), (3, pt, "hold"), (8, pt, "io"), (11, r, "hold")], loop=False)

# ================================================================== zestawy
def human_set(kind):
    S = {
        "idle": (24, idle_clip(kind).sample),
        "walk": (12, walk_fn(kind)),
        "run": (8, run_fn(kind)),
        "hit": (8, clip_hit(kind).sample),
        "fall": (12, clip_fall(kind).sample),
        "down": (24, clip_down(kind).sample),
        "death": (24, clip_death2(kind).sample),
        "dead": (1, lambda f: dead_pose(kind)),
        "treat": (24, clip_treat(kind).sample),
        "drag": (16, drag_fn(kind)),
        "dragged": (24, lambda f: dragged_pose(kind, f / 24)),
        "cower": (24, clip_cower(kind).sample),
    }
    if kind == "spear": S.update(attack=(12, clip_thrust().sample), block=(8, clip_block().sample))
    elif kind == "hammer": S.update(attack=(20, clip_smash().sample))
    elif kind == "knife": S.update(attack=(8, clip_stab().sample))
    elif kind in ("club", "machete"): S.update(attack=(10, clip_swing().sample))
    elif kind == "bow": S.update(shoot=(24, clip_bow_shoot().sample), attack=(8, clip_bash("bow").sample))
    elif kind == "crossbow": S.update(shoot=(8, clip_xbow_shoot().sample), reload=(36, clip_xbow_reload().sample), attack=(8, clip_bash("crossbow").sample))
    return S
