import sys, math; sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
from factions2 import UNITS, TITLES
from emblems import PAL
fb = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 15)
ft = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 26)
SP = 1.55; S = 2
for key, us in UNITS.items():
    N = len(us)
    im = stylize('out/frakcja_%s.exr' % key); W, H = im.size
    im = im.resize((W * S, H * S), Image.NEAREST)
    out = Image.new('RGB', (W * S, H * S + 120), (20, 17, 28)); out.paste(im, (0, 104))
    d = ImageDraw.Draw(out)
    emb = Image.open('/home/claude/latarnia3d/tex/emblem_%s.png' % key).resize((88, 88), Image.NEAREST)
    out.paste(emb, (16, 8)); d.text((120, 18), TITLES[key], font=ft, fill=(236, 214, 170))
    for j, col in enumerate(PAL[key]): d.rectangle((122 + j * 40, 60, 156 + j * 40, 76), fill=col)
    ppm = W / (N * SP + 0.6)
    for i, (label, *_ ) in enumerate(us):
        x = (W / 2 + (i - (N - 1) / 2) * SP * ppm) * S
        w = d.textlength(label, font=fb)
        d.rectangle((x - w / 2 - 5, H * S + 104 - 50, x + w / 2 + 5, H * S + 104 - 30), fill=(20, 17, 28))
        d.text((x - w / 2, H * S + 104 - 50), label, font=fb, fill=(226, 200, 150))
    out.save('out/latarnia_frakcja_%s.png' % key)
print("ok")
