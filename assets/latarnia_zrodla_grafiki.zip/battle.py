"""Bitwa pod brama w docelowym ujeciu: wszystkie nowe animacje razem. python3 battle.py -- F0 F1"""
import sys, math, random
sys.path.insert(0, "/home/claude/latarnia3d")
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else ["0", "36"]
F0, F1 = int(args[0]), int(args[1])
src = open("/home/claude/latarnia3d/scene_full.py").read().split("# ------------------------------------------------ postacie")[0]
sys.argv = ["x", "--", "1"]
exec(src)
import anim as A, mutanim as MA
setup_render(samples=16)

cells = []          # (rig, fn(f) -> (pose, loc, yaw))
def add(rig, fn): cells.append((rig, fn))
def still(loc, yaw, clipfn): return lambda f: (clipfn(f), loc, yaw)

# ---- oddzial za palisada (brama w x=3.2, y w [-1.35, 1.35])
t1 = human("tarcz1", dict(jacket="grey", pants="darkgrey", armor="plate", helmet="pot"), "spear")
sp = A.clip_spear()
add(t1, lambda f: (sp.sample(min(max(f - 12, 0), 23)), (2.55, 0.45, 0), 0))
t2 = human("tarcz2", dict(jacket="grey", pants="darkgrey", armor="plate", helmet="pot"), "spear")
add(t2, still((2.55, -0.65, 0), 4, lambda f: A.merge(sp.sample(0), A.breathe(f, 24))))
st = human("strzel", dict(jacket="olive", pants="olive", helmet="mil"), "rifle")
ks = A.clip_shoot(A.kneel())
add(st, still((1.55, 1.05, 0), -6, lambda f: ks.sample(f % 24)))
zw = human("zwiad", dict(jacket="teal", pants="darkgrey", mask="gas"), "rifle")
zs = A.clip_shoot()
add(zw, still((1.45, -0.25, 0), -10, lambda f: zs.sample((f - 18) % 24)))
lm = human("lamacz", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True), "hammer")
add(lm, still((1.75, -1.55, 0), -8, lambda f: A.merge(A.wide(), A.breathe(f, 20), A.P(rot={"head": (0, 0, 10 * math.sin(f / 5))}))))
ch = human("choraz", dict(jacket="blue", pants="blue", helmet="mil"), "banner")
add(ch, still((0.15, 0.45, 0), -14, lambda f: A.merge(A.stance(), A.P(rot={"weapon": (3 * math.sin(f / 3), 4 * math.sin(f / 2.3), 0)}), A.breathe(f, 24))))
rl = human("przelad", dict(jacket="olive", pants="brown", helmet="pot"), "rifle")
rc = A.clip_reload()
add(rl, still((0.55, -0.75, 0), -12, lambda f: rc.sample((f + 4) % 24)))

# ---- mutanty z Mgly (x > 3.2)
o1 = ogar("og1"); gal = MA.ogar_gallop; od = MA.clip_ogar_death()
def og1_fn(f):
    if f < 15: return gal(f, 6), (9.0 - 0.33 * f, 0.35, 0), 182
    p = od.sample(min(f - 15, 23)); return p, (9.0 - 0.33 * 15 - 0.12 * min(f - 15, 4), 0.35, 0), 182
add(o1, og1_fn)
o2 = ogar("og2"); op = MA.clip_ogar_pounce(); od2 = MA.clip_ogar_death()
def og2_fn(f):
    if f < 9: return gal(f + 2, 6), (8.6 - 0.33 * f, -0.75, 0), 178
    if f < 22: return op.sample(f - 9), (8.6 - 0.33 * 9, -0.75, 0), 178
    p = od2.sample(min(f - 22, 23)); r = op.sample(13)["root"]
    return p, (8.6 - 0.33 * 9 - r[0] * 0.999, -0.75, 0), 178
add(o2, og2_fn)
kz = krzykacz("krz"); kz.objs = {k: MA.recenter(bpy.data.objects["krz_" + k]) for k in ("mouth", "throat")}
ksc = MA.clip_krz_scream()
add(kz, still((10.2, 4.2, 0), 196, lambda f: ksc.sample((f + 2) % 24)))
nsr = nosiciel("nos"); nsr.objs = {"belly": MA.recenter(bpy.data.objects["nos_belly"])}
nb = MA.clip_nos_burst()
def nos_fn(f):
    if f < 27: return MA.nos_walk(f), (8.4 - 0.05 * f, -3.0, 0), 160
    return nb.sample(min(13 + (f - 27), 23)), (8.4 - 0.05 * 27, -3.0, 0), 160
add(nsr, nos_fn)
rozrost("roz", (11.4, 1.0, 0.5))
rats = []
for k in range(16):
    parts = rat("rt%d" % k, (0, 0, 0), 0.0)
    e = bpy.data.objects.new("ratE%d" % k, None); link(e)
    for p_ in parts: p_.parent = e
    rats.append((e, 6.2 + rnd.uniform(0, 2.6), -2.4 - rnd.uniform(0, 1.6)))

# ---- efekty: smugi, luski, iskry, wybuch
TR = mat("tracerm", (255, 220, 150), pass_index=3, emit=(255, 200, 120), strength=18)
tracers = [cyl("trc%d" % k, (0, 0, 0), (0, 0, 1), 0.014, TR, seg=4) for k in range(3)]
for t_ in tracers: t_.hide_render = True
def seg_to(o, a, b):
    d = b - a; o.location = a; o.rotation_euler = d.to_track_quat("Z", "Y").to_euler(); o.scale = (1, 1, d.length)
REST_MUZ = V((1.02, -0.08, 1.19))
SHOTS = {9: (st, None), 15: (st, o1), 33: (st, kz), 3: (zw, None), 27: (zw, nsr)}
GAS = mat("gas_b", (120, 138, 62), pass_index=3); gas = [ellipsoid("gb%d" % k, (0, 0, 0), (1, 1, 1), GAS, u=10, v=8) for k in range(8)]
for g in gas: g.hide_render = True
RING = mat("ringm", (230, 220, 255), pass_index=3, emit=(200, 190, 255), strength=4)
rings = [loft("rg%d" % k, [((0, 0, 0), 1.0, 1.0), ((0, 0, 0.02), 1.0, 1.0)], RING, seg=20, cap=False) for k in range(2)]
SPK = mat("spk", (255, 120, 90), pass_index=3, emit=(255, 80, 60), strength=6)
gore = [box("gore%d" % k, (0, 0, 0), (0.04, 0.04, 0.04), SPK) for k in range(8)]
for o in gore: o.hide_render = True
grnd = random.Random(5); gdir = [V((grnd.uniform(-1, 1), grnd.uniform(-1, 1), grnd.uniform(0.3, 1.0))) for _ in gore]

camera((4.6, 0.6, 1.0), 52, 14, (640, 360), yaw_deg=-32)
fill = sun("charfill", (math.radians(62), 0, math.radians(-32 + 180 + 20)), (1.0, 0.9, 0.78), 0.9)
fill.light_linking.receiver_collection = char_collection()
rim = sun("rim", (math.radians(-60), 0, math.radians(-32)), (0.62, 0.80, 1.0), 2.5)
rim.light_linking.receiver_collection = char_collection()
torch = spot_light("torch", (1.8, -0.4, 1.3), (0, math.radians(-85), 0), (0.85, 0.92, 1.0), 2400, 24, 0.3)
mflash = point_light("mflash", (2, 0, 1.3), (1.0, 0.85, 0.6), 0, 0.05)
hitpt = {}
for f in range(F0, F1):
    for rig, fn in cells:
        pose, loc, yaw = fn(f); A.apply(rig, pose, loc, yaw)
    bpy.context.view_layer.update()
    # smugi pociskow i blysk
    for t_ in tracers: t_.hide_render = True
    mflash.data.energy = 0
    if f in SHOTS:
        shooter, tgt = SHOTS[f]
        m = shooter.objs["flash"].matrix_world @ REST_MUZ
        end = (V(tgt.ob.matrix_world.translation) + V((0, 0, 0.6))) if tgt else m + V((7, 0.8 * math.sin(f), 0.3))
        d = (end - m); seg_to(tracers[0], m + d * 0.25, m + d * 0.75); tracers[0].hide_render = False
        mflash.location = m; mflash.data.energy = 600
        if tgt is not None: hitpt[f] = end
    # rozprysk przy trafieniu
    for o in gore: o.hide_render = True
    for hf, hp in hitpt.items():
        t = f - hf
        if 0 <= t <= 4:
            for k, o in enumerate(gore):
                p = hp + gdir[k] * 0.18 * t; p.z -= 0.034 * t * t; p.z = max(p.z, 0.03)
                o.location = p; o.hide_render = False
    # torch sledzi zwiadowce
    torch.location = zw.ob.matrix_world @ zw.ob.pose.bones["weapon"].tail + V((0.1, 0, 0))
    # szczury
    for k, (e, rx, ry) in enumerate(rats):
        x = rx - 0.12 * f - 0.03 * (k % 3) * f; y = ry + 0.12 * math.sin(f * 0.7 + k)
        e.location = (x, y, 0.012 * abs(math.sin(f * 2.1 + k))); e.rotation_euler = (0, 0, math.pi + 0.3 * math.sin(f * 0.7 + k))
    # krzyk
    hc = V((10.2, 4.2, 1.55)) + V((math.cos(math.radians(196)), math.sin(math.radians(196)), 0)) * 0.25
    for k, rg in enumerate(rings):
        t = ((f + 2) % 24) - 9 - 3 * k
        rg.hide_render = not (0 <= t <= 6)
        if 0 <= t <= 6:
            r = 0.25 + 0.3 * t; rg.location = hc; rg.scale = (r, r, 1); rg.rotation_euler = (0, math.radians(90), math.radians(196))
    # wybuch nosiciela
    bc = V((8.4 - 0.05 * 27, -3.0, 0.9)); t = f - 27
    for k, g in enumerate(gas):
        tt = t - (k % 3)
        g.hide_render = not (0 <= tt <= 9)
        if 0 <= tt <= 9:
            r = (0.14 + 0.06 * tt); a = 2 * math.pi * k / 8
            g.location = bc + V((math.cos(a) * 0.1 * tt, math.sin(a) * 0.1 * tt, -0.3 + 0.05 * tt)); g.scale = (r, r, r * 0.7)
    fl = 1 + 0.18 * math.sin(f * 2.1) + 0.1 * math.sin(f * 5.3)
    firelight.data.energy = 260 * fl
    for k, fo in enumerate(flames): fo.scale = (1, 1, 0.85 + 0.25 * abs(math.sin(f * 1.7 + k)))
    render("/home/claude/latarnia3d/out/battle_%02d.exr" % f)
