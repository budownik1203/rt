import sys, math, json
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import anim as A, bestiary as BX
from chars import ogar, krzykacz, nosiciel, krzykacz_pose
reset(); setup_render(samples=24)
world((44, 40, 60), 0.5)
box("ground", (0, 0, -0.05), (40, 40, 0.1), mat("ground", (62, 58, 62), pass_index=1), pass_index=1)
CAMYAW = -20; cy = math.radians(CAMYAW); YAW = CAMYAW - 55
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
lab = []
for i, (nm, fn) in enumerate(BX.BESTIARY):
    c, rr = i % 4, i // 4
    r, pose = fn("bx%d" % i)
    x, y = (c - 1.5) * 2.3, (1 - rr) * 2.9
    p = RIGHT * x + FWD * y
    A.apply(r, pose, tuple(p), YAW)
    lab.append((nm, x, y))
sun("key", (math.radians(45), 0, math.radians(CAMYAW + 30)), (1.0, 0.86, 0.68), 3.0)
f = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.65, 0.72, 1.0), 1.3)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (f, rim): L.light_linking.receiver_collection = char_collection()
camera((0, 0, 0.9), 50, 10.4, (960, 640), yaw_deg=CAMYAW)
json.dump(lab, open("/home/claude/latarnia3d/out/bestiary.json", "w"))
render("/home/claude/latarnia3d/out/bestiary.exr")
