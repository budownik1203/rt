"""Eksport calej czesci artystycznej do glTF dla Godota: postacie frakcji, mutanty z klipami, budynki, bron."""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import lat3d
OUT = "/home/claude/latarnia3d/export"
TR = str.maketrans("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ", "acelnoszzACELNOSZZ")
def slugify(t): return "".join(ch for ch in t.translate(TR).lower().replace(" ", "_") if ch.isalnum() or ch == "_")
def fresh():
    reset(); lat3d.MATS.clear(); lat3d.CHAR_COL = None
    bpy.context.scene.render.fps = 12
def bake(r, clips):
    import anim as A
    ob = r.ob; ob.animation_data_create(); bones = list(ob.pose.bones)
    for name, (n, fn) in clips.items():
        act = bpy.data.actions.new(name); ob.animation_data.action = act
        for f in range(n + 1):
            A.apply(r, fn(f), (0, 0, 0), 0); bpy.context.view_layer.update()
            mats = {pb.name: pb.matrix.copy() for pb in bones}
            for pb in bones:
                for c in pb.constraints: c.mute = True
            for pb in bones:
                pb.matrix = mats[pb.name]; bpy.context.view_layer.update()
                pb.keyframe_insert("rotation_quaternion", frame=f); pb.keyframe_insert("location", frame=f)
            for pb in bones:
                for c in pb.constraints: c.mute = False
            ob.keyframe_insert("location", frame=f); ob.keyframe_insert("rotation_euler", frame=f)
        act.use_fake_user = True
        tr = ob.animation_data.nla_tracks.new(); tr.name = name; tr.strips.new(name, 0, act)
        ob.animation_data.action = None
    for pb in bones:
        for c in list(pb.constraints): pb.constraints.remove(c)
def save(path, anims=True):
    for o in bpy.data.objects:
        if o.type == "LIGHT" or o.type == "CAMERA": bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_animations=anims, export_animation_mode="NLA_TRACKS",
                              export_force_sampling=True, export_apply=False)
os.makedirs(OUT + "/postacie", exist_ok=True); os.makedirs(OUT + "/mutanty", exist_ok=True)
os.makedirs(OUT + "/budynki", exist_ok=True); os.makedirs(OUT + "/bron", exist_ok=True)
# frakcje (bez klipow: animacje czlowieka sa wspolne, w zolnierz.glb, po nazwach kosci)
import factions as FX
for fname, units in FX.FACTIONS:
    for uname, fn in units:
        fresh(); r, _ = fn("u"); slug = slugify(fname + "_" + uname)
        for o in list(bpy.data.objects):
            if o.hide_render and o.type == "MESH" and not o.name.endswith(("flash", "maghand", "mag")): bpy.data.objects.remove(o, do_unlink=True)
        save(OUT + "/postacie/%s.glb" % slug, anims=False)
# mutanty z klipami
import mutanim as MA
from chars import ogar, krzykacz, nosiciel
fresh(); r = ogar("ogar"); bake(r, {"gallop": (6, MA.ogar_gallop), "pounce": (24, MA.clip_ogar_pounce().sample), "death": (24, MA.clip_ogar_death().sample)}); save(OUT + "/mutanty/ogar.glb")
fresh(); r = krzykacz("krzykacz"); bake(r, {"walk": (14, MA.krz_walk), "scream": (24, MA.clip_krz_scream().sample), "slash": (24, MA.clip_krz_slash().sample), "death": (24, MA.clip_krz_death().sample)}); save(OUT + "/mutanty/krzykacz.glb")
fresh(); r = nosiciel("nosiciel"); bake(r, {"walk": (16, MA.nos_walk), "burst": (24, MA.clip_nos_burst().sample)}); save(OUT + "/mutanty/nosiciel.glb")
import bestiary as BX
for nm, fn in BX.BESTIARY:
    fresh(); r, pose = fn("m")
    import anim as A
    bake(r, {"idle": (1, lambda f, p=pose: p)})
    slug = slugify(nm)
    save(OUT + "/mutanty/%s.glb" % slug)
# budynki
import buildings as BD
for nm, fn in BD.CATALOG:
    fresh(); fn(0, 0, 0)
    slug = slugify(nm)
    save(OUT + "/budynki/%s.glb" % slug, anims=False)
# bron
import weapons as WP
for nm, era, fn in WP.ARSENAL:
    fresh(); fn()
    slug = slugify(nm)
    save(OUT + "/bron/%s.glb" % slug, anims=False)
print("ALL EXPORTED")
