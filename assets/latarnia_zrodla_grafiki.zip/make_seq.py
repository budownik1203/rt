import sys, math
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
def build(prefix, n, W, H, ORT, TZ, labels, out, dur=83, S=2, legend=None, CX=0.0):
    t = math.radians(50)
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 13)
    frames = []
    for f in range(n):
        im0 = stylize('out/%s_%02d.exr' % (prefix, f)).resize((W * S, H * S), Image.NEAREST)
        extra = 22 * len(legend) + 16 if legend else 0
        im = Image.new('RGB', (W * S, H * S + extra), (20, 17, 28)); im.paste(im0, (0, 0))
        d = ImageDraw.Draw(im)
        if legend:
            for k, line in enumerate(legend): d.text((16, H * S + 8 + 22 * k), line, font=font, fill=(226, 200, 150))
        for txt, c, r, dy in labels:
            x = (W / 2 + (c - CX) * W / ORT) * S; y = (H / 2 - (r * math.cos(t) - TZ * math.sin(t)) * W / ORT) * S + dy
            w = d.textlength(txt, font=font)
            d.rectangle((x - 4, y - 2, x + w + 4, y + 15), fill=(20, 17, 28)); d.text((x, y - 1), txt, font=font, fill=(226, 200, 150))
        frames.append(im)
    frames[0].save(out, save_all=True, append_images=frames[1:], duration=dur, loop=0)
    return frames
if __name__ == "__main__":
    titles = ["Chód → bieg → stop i seria", "Pod ostrzałem: skulenie, pad, czołganie, strzał z ziemi", "Strzał, przyklęk, ogień z kolana, powstanie",
              "Trafiony: zachwianie i powrót do walki", "Skok do osłony i wychylenie"]
    labs = [(str(i + 1), (-6.6 if i in (0, 1, 4) else -4.0) - 0.9, (2 - i) * 2.15 + 0.5, -10) for i in range(5)]
    fr = build("seq", 48, 640, 480, 11.5, 0.6, labs, "out/latarnia3d_przejscia.gif", legend=["%d — %s" % (i + 1, t) for i, t in enumerate(titles)], CX=-2.4)
    fr[22].save("out/latarnia3d_przejscia_kl22.png")
