"""Arkusz frakcji: python3 lineup.py -- S (0: frakcje 1-3, 1: frakcje 4-6)"""
import sys, math, json
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import anim as A, factions as FX
S = int(sys.argv[sys.argv.index("--") + 1])
reset(); setup_render(samples=24)
world((44, 40, 60), 0.5)
box("ground", (0, 0, -0.05), (40, 40, 0.1), mat("ground", (62, 58, 62), pass_index=1), pass_index=1)
CAMYAW = -20; cy = math.radians(CAMYAW); YAW = CAMYAW - 62
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
POSE = {"rifle": A.merge(A.stance(), A.low_ready()), "pistol": A.merge(A.stance(), A.arms_down()), "knife": A.merge(A.stance(), A.arms_down()),
        "idle": A.merge(A.stance(), A.arms_down()), "banner": A.stance(), "hammer": A.stance(), "staff": A.stance(), "bow": A.stance(), "spear": A.stance()}
lab = []
for ri, (fname, units) in enumerate(FX.FACTIONS[S * 3:(S + 1) * 3]):
    for ci, (uname, fn) in enumerate(units):
        n = "u%d%d" % (ri, ci)
        r, pose = fn(n)
        p = RIGHT * ((ci - 1) * 1.9 + 0.55) + FWD * ((1 - ri) * 2.7)
        A.apply(r, POSE[pose], tuple(p), YAW)
        lab.append((fname, uname, (ci - 1) * 1.9 + 0.55, (1 - ri) * 2.7))
sun("key", (math.radians(45), 0, math.radians(CAMYAW + 30)), (1.0, 0.86, 0.68), 3.0)
f = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.65, 0.72, 1.0), 1.3)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (f, rim): L.light_linking.receiver_collection = char_collection()
camera((0, 0, 0.9), 50, 8.6, (960, 640), yaw_deg=CAMYAW)
json.dump(lab, open("/home/claude/latarnia3d/out/lineup_%d.json" % S, "w"))
render("/home/claude/latarnia3d/out/lineup_%d.exr" % S)
