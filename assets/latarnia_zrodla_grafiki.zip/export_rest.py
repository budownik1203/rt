"""Eksport calej czesci artystycznej do glTF dla Godota: postacie frakcji, mutanty z klipami, budynki, bron."""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import lat3d
OUT = "/home/claude/latarnia3d/export"
TR = str.maketrans("ąćęłńóśźżĄĆĘŁŃÓŚŹŻ", "acelnoszzACELNOSZZ")
def slugify(t): return "".join(ch for ch in t.translate(TR).lower().replace(" ", "_") if ch.isalnum() or ch == "_")
def fresh():
    reset(); lat3d.MATS.clear(); lat3d.CHAR_COL = None
    bpy.context.scene.render.fps = 12
def bake(r, clips):
    import anim as A
    ob = r.ob; ob.animation_data_create(); bones = list(ob.pose.bones)
    for name, (n, fn) in clips.items():
        act = bpy.data.actions.new(name); ob.animation_data.action = act
        for f in range(n + 1):
            A.apply(r, fn(f), (0, 0, 0), 0); bpy.context.view_layer.update()
            mats = {pb.name: pb.matrix.copy() for pb in bones}
            for pb in bones:
                for c in pb.constraints: c.mute = True
            for pb in bones:
                pb.matrix = mats[pb.name]; bpy.context.view_layer.update()
                pb.keyframe_insert("rotation_quaternion", frame=f); pb.keyframe_insert("location", frame=f)
            for pb in bones:
                for c in pb.constraints: c.mute = False
            ob.keyframe_insert("location", frame=f); ob.keyframe_insert("rotation_euler", frame=f)
        act.use_fake_user = True
        tr = ob.animation_data.nla_tracks.new(); tr.name = name; tr.strips.new(name, 0, act)
        ob.animation_data.action = None
    for pb in bones:
        for c in list(pb.constraints): pb.constraints.remove(c)
def save(path, anims=True):
    for o in bpy.data.objects:
        if o.type == "LIGHT" or o.type == "CAMERA": bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_animations=anims, export_animation_mode="NLA_TRACKS",
                              export_force_sampling=True, export_apply=False)
os.makedirs(OUT + "/budynki", exist_ok=True); os.makedirs(OUT + "/bron", exist_ok=True)
import bestiary as BX, anim as A
done = set(os.listdir(OUT + "/mutanty"))
for nm, fn in BX.BESTIARY:
    slug = slugify(nm)
    if slug + ".glb" in done: continue
    fresh(); r, pose = fn("m"); bake(r, {"idle": (1, lambda f, p=pose: p)}); save(OUT + "/mutanty/%s.glb" % slug)
import buildings as BD
for nm, fn in BD.CATALOG:
    fresh(); fn(0, 0, 0); save(OUT + "/budynki/%s.glb" % slugify(nm), anims=False)
import weapons as WP
for nm, era, fn in WP.ARSENAL:
    fresh(); fn(); save(OUT + "/bron/%s.glb" % slugify(nm), anims=False)
print("REST EXPORTED")
