"""Pelna scena bramy w 3D: latarnia z prawdziwym swiatlem, palisada, ruiny, sklad w szyku, mutanty. Render T klatek."""
import sys, math, random
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *

T = int(sys.argv[sys.argv.index("--") + 1]) if "--" in sys.argv else 12
OUT = "/home/claude/latarnia3d/out/scene_%02d.exr"
rnd = random.Random(3)
reset(); setup_render(samples=20)
world((30, 26, 48), 0.22)
sun("moon", (math.radians(40), 0, math.radians(160)), (0.55, 0.62, 0.95), 0.12)

# ------------------------------------------------ teren
ground = mat("ground", (60, 56, 66), pass_index=1, noise=dict(scale=2.4, detail=5.0, stops=[
    (0.0, (52, 48, 58)), (0.40, (60, 56, 66)), (0.52, (68, 58, 50)), (0.62, (60, 64, 46)), (0.70, (66, 62, 72)), (0.80, (56, 52, 62))]))
box("ground", (0, 2, -0.05), (60, 40, 0.1), ground, pass_index=1)
gravel = [mat("grav1", (84, 80, 92), pass_index=1), mat("grav2", (100, 90, 82), pass_index=1)]
grass = [mat("gras1", (88, 96, 56), pass_index=1), mat("gras2", (112, 108, 62), pass_index=1)]
for k in range(420):
    gx, gy = rnd.uniform(-13, 3.0), rnd.uniform(-4.4, 10)
    if (gx + 6) ** 2 + (gy - 2.6) ** 2 < 1.6: continue
    if rnd.random() < 0.55:
        box("grv%d" % k, (gx, gy, 0.015), (rnd.uniform(0.05, 0.12), rnd.uniform(0.04, 0.09), 0.03), gravel[k % 2], rot=(0, 0, rnd.uniform(0, 3)), pass_index=1)
    else:
        for j in range(3):
            loft("grs%d_%d" % (k, j), [((gx + 0.04 * j, gy, 0.0), 0.02, 0.02), ((gx + 0.04 * j + rnd.uniform(-0.05, 0.05), gy + rnd.uniform(-0.03, 0.03), rnd.uniform(0.12, 0.22)), 0.003, 0.003)], grass[(k + j) % 2], seg=4, pass_index=1)
road = mat("road", (44, 42, 52), pass_index=1, noise=dict(scale=1.5, detail=2.0, stops=[(0.0, (40, 38, 48)), (0.5, (48, 46, 56)), (0.8, (58, 55, 64))]))
box("road", (0, -6.2, -0.03), (60, 3.2, 0.06), road, pass_index=1)
paint = mat("paint", (150, 146, 130), pass_index=1)
for x in range(-14, 16, 3): box("dash%d" % x, (x, -6.2, 0.005), (1.2, 0.12, 0.02), paint, pass_index=1)
curb = mat("curb", (98, 94, 104), pass_index=2)
box("curb", (0, -4.55, 0.06), (60, 0.18, 0.12), curb)

# ------------------------------------------------ palisada z brama
logm = mat("log", (104, 74, 46), pass_index=2)
logtop = mat("logtop", (140, 104, 66), pass_index=2)
wire = mat("wire", (90, 90, 100), pass_index=2)
PX = 3.2
y = -5.0
while y < 11:
    if abs(y) > 1.35:
        h = 2.0 + rnd.uniform(-0.15, 0.2)
        cyl("pal%.2f" % y, (PX + rnd.uniform(-0.03, 0.03), y, 0), (PX, y, h), 0.13, logm, seg=8)
        loft("palt%.2f" % y, [((PX, y, h), 0.13, 0.13), ((PX, y, h + 0.28), 0.01, 0.01)], logtop, seg=8)
    y += 0.27
for zz in (0.6, 1.5):
    box("wireA%.1f" % zz, (PX - 0.14, -3.2, zz), (0.03, 3.8, 0.04), wire); box("wireB%.1f" % zz, (PX - 0.14, 6.0, zz), (0.03, 9.6, 0.04), wire)
for gy in (-1.45, 1.45):
    cyl("gpost%.1f" % gy, (PX, gy, 0), (PX, gy, 2.7), 0.2, logm, seg=10)
    loft("gpostt%.1f" % gy, [((PX, gy, 2.7), 0.2, 0.2), ((PX, gy, 2.9), 0.05, 0.05)], logtop, seg=10)
box("lintel", (PX, 0, 2.55), (0.28, 3.2, 0.22), logm)

# ------------------------------------------------ latarnia (wieza ~4,5 wzrostu)
stone = mat("stone", (110, 106, 116), pass_index=2, brick=dict(scale=3.2, c1=(108, 104, 114), c2=(92, 88, 100), mortar=(60, 56, 66), mortar_size=0.015))
dmetal = mat("dmetal", (52, 50, 60), pass_index=2)
lglass = mat("lglass", (255, 230, 160), pass_index=2, emit=(255, 214, 140), strength=9)
TX, TY = -6.0, 2.6
loft("tower", [((TX, TY, 0), 1.15, 1.15), ((TX, TY, 4.0), 1.02, 1.02), ((TX, TY, 7.9), 0.92, 0.92)], stone, seg=8, smooth=False)
loft("plinth", [((TX, TY, 0), 1.35, 1.35), ((TX, TY, 0.45), 1.3, 1.3)], dmetal if False else stone, seg=8, smooth=False)
loft("gallery", [((TX, TY, 7.9), 1.35, 1.35), ((TX, TY, 8.08), 1.35, 1.35)], dmetal, seg=12, smooth=False)
for k in range(12):
    a = 2 * math.pi * k / 12
    cyl("rail%d" % k, (TX + 1.28 * math.cos(a), TY + 1.28 * math.sin(a), 8.08), (TX + 1.28 * math.cos(a), TY + 1.28 * math.sin(a), 8.6), 0.025, dmetal, seg=4)
loft("railtop", [((TX, TY, 8.58), 1.3, 1.3), ((TX, TY, 8.62), 1.3, 1.3)], dmetal, seg=12, cap=False)
loft("lantern_glass", [((TX, TY, 8.08), 0.68, 0.68), ((TX, TY, 9.0), 0.68, 0.68)], lglass, seg=8, smooth=False)
for k in range(8):
    a = 2 * math.pi * k / 8 + math.pi / 8
    cyl("mull%d" % k, (TX + 0.7 * math.cos(a), TY + 0.7 * math.sin(a), 8.08), (TX + 0.7 * math.cos(a), TY + 0.7 * math.sin(a), 9.0), 0.035, dmetal, seg=4)
loft("roof", [((TX, TY, 9.0), 0.86, 0.86), ((TX, TY, 9.55), 0.12, 0.12), ((TX, TY, 9.75), 0.03, 0.03)], dmetal, seg=8, smooth=False)
box("tdoor", (TX, TY - 1.12, 1.05), (0.85, 0.12, 2.1), mat("doorwood", (70, 48, 32), pass_index=2))
for z in (3.2, 5.6): box("slit%.1f" % z, (TX, TY - 0.99, z), (0.22, 0.1, 0.65), mat("void", (12, 10, 16), pass_index=2))
box("doorlamp", (TX, TY - 1.2, 2.35), (0.16, 0.12, 0.16), mat("doorlampm", (255, 210, 140), pass_index=2, emit=(255, 200, 120), strength=6))
point_light("doorlampL", (TX, TY - 1.5, 2.3), (1.0, 0.75, 0.45), 70, 0.08)
lantern = point_light("lantern", (TX, TY, 8.55), (1.0, 0.72, 0.42), 9000, 0.12)
for nm in ["tower", "lantern_glass", "gallery", "railtop", "roof"] + ["mull%d" % k for k in range(8)] + ["rail%d" % k for k in range(12)]:
    bpy.data.objects[nm].visible_shadow = False

# ------------------------------------------------ chata z desek + okno ze swiatlem
plank = mat("plank", (96, 70, 46), pass_index=2, brick=dict(scale=1.6, c1=(98, 72, 46), c2=(84, 60, 40), mortar=(42, 30, 22), mortar_size=0.01))
roofm = mat("roofm", (80, 78, 88), pass_index=2)
SX, SY = -9.2, -2.6
box("shack", (SX, SY, 1.15), (3.4, 2.6, 2.3), plank)
box("shroof", (SX, SY, 2.45), (3.8, 3.0, 0.22), roofm, rot=(math.radians(-8), 0, 0))
box("shdoor", (SX - 0.6, SY - 1.31, 0.95), (0.8, 0.06, 1.9), mat("doorwood", (70, 48, 32)))
box("shwin", (SX + 0.8, SY - 1.31, 1.35), (0.7, 0.05, 0.55), mat("winlight", (255, 200, 120), pass_index=2, emit=(255, 190, 110), strength=4))
point_light("shlight", (SX + 0.8, SY - 1.6, 1.4), (1.0, 0.7, 0.4), 30, 0.2)

# ------------------------------------------------ ognisko
FX, FY = -3.8, -2.0
rockm = mat("rock", (90, 86, 96), pass_index=2)
for k in range(8):
    a = 2 * math.pi * k / 8
    ellipsoid("frock%d" % k, (FX + 0.42 * math.cos(a), FY + 0.42 * math.sin(a), 0.07), (0.13, 0.11, 0.09), rockm)
for k in range(3):
    a = 2 * math.pi * k / 3
    cyl("flog%d" % k, (FX + 0.3 * math.cos(a), FY + 0.3 * math.sin(a), 0.05), (FX - 0.1 * math.cos(a), FY - 0.1 * math.sin(a), 0.22), 0.05, logm, seg=6)
fire_mats = [mat("fire1", (255, 120, 40), pass_index=2, emit=(255, 110, 30), strength=8), mat("fire2", (255, 210, 110), pass_index=2, emit=(255, 200, 100), strength=10)]
flames = []
for k in range(5):
    a = 2 * math.pi * k / 5
    flames.append(loft("flame%d" % k, [((FX + 0.1 * math.cos(a), FY + 0.1 * math.sin(a), 0.12), 0.09, 0.09), ((FX + 0.05 * math.cos(a), FY + 0.05 * math.sin(a), 0.5 + 0.12 * (k % 2)), 0.01, 0.01)], fire_mats[k % 2], seg=6))
firelight = point_light("fire", (FX, FY, 0.6), (1.0, 0.55, 0.25), 260, 0.1)

# ------------------------------------------------ ruina z cegly (za palisada)
brick = mat("brick", (130, 64, 42), pass_index=2, brick=dict(scale=5.5, c1=(132, 64, 42), c2=(112, 52, 36), mortar=(70, 60, 60), mortar_size=0.02))
BX0, BX1, BY0, BH = 4.6, 13.5, 7.4, 3.6
x = BX0
while x < BX1:
    w = 0.9
    if int((x - BX0) / 1.3) % 2 == 1:
        box("bw%.1f" % x, (x + 0.65, BY0, 0.5), (1.3, 0.35, 1.0), brick); box("bwt%.1f" % x, (x + 0.65, BY0, 2.9 + rnd.uniform(-0.3, 0.4) * (x > 9)), (1.3, 0.35, 1.4), brick)
    else:
        box("bp%.1f" % x, (x + 0.65, BY0, BH / 2 - (0.9 if 8.5 < x < 10 else 0)), (1.3, 0.35, BH - (1.8 if 8.5 < x < 10 else 0)), brick)
    x += 1.3
box("bside", (BX0, BY0 + 2.0, BH / 2), (0.35, 4.0, BH), brick)
box("bback", ((BX0 + BX1) / 2, BY0 + 4.0, BH / 2), (BX1 - BX0, 0.35, BH), brick)
box("bfloor", ((BX0 + BX1) / 2, BY0 + 2, 0.02), (BX1 - BX0, 4, 0.04), mat("void", (12, 10, 16)))
for k in range(60):   # gruz
    cx, cy = rnd.choice([(9.2, 6.6), (6.0, 6.8), (11.5, 6.5), (5.0, -3.5), (8.5, 2.5)])
    box("rub%d" % k, (cx + rnd.gauss(0, 0.6), cy + rnd.gauss(0, 0.35), 0.06), (rnd.uniform(0.1, 0.32), rnd.uniform(0.08, 0.22), rnd.uniform(0.06, 0.14)),
        brick if k % 3 else rockm, rot=(0, 0, rnd.uniform(0, 3)))

# ------------------------------------------------ wrak, beczki, skrzynie
rustm = mat("rustcar", (122, 62, 38), pass_index=2)
tyrem = mat("tyre", (34, 32, 38), pass_index=2)
CXc, CYc, CA = 6.6, 3.8, math.radians(18)
box("car", (CXc, CYc, 0.55), (3.8, 1.7, 0.6), rustm, rot=(0, 0, CA))
box("cab", (CXc - 0.2, CYc, 1.05), (1.9, 1.5, 0.5), rustm, rot=(0, math.radians(3), CA))
box("cabwin", (CXc - 0.2 + 0.0, CYc, 1.05), (1.7, 1.52, 0.32), mat("void", (12, 10, 16)), rot=(0, 0, CA))
for dx, dy in ((1.25, 0.86), (-1.25, 0.86), (1.25, -0.86), (-1.25, -0.86)):
    px = CXc + dx * math.cos(CA) - dy * math.sin(CA); py = CYc + dx * math.sin(CA) + dy * math.cos(CA)
    cyl("wheel%.1f%.1f" % (dx, dy), (px, py - 0.08 * (1 if dy > 0 else -1), 0.32), (px, py + 0.08 * (1 if dy > 0 else -1), 0.32), 0.3, tyrem, seg=10)
barrel = mat("barrel", (118, 54, 34), pass_index=2)
for (bx, by) in ((-4.7, 1.0), (-4.1, 1.35), (-4.5, 1.8)):
    cyl("barrel%.1f" % bx, (bx, by, 0), (bx, by, 0.88), 0.29, barrel, seg=12)
    loft("bring%.1f" % bx, [((bx, by, 0.6), 0.3, 0.3), ((bx, by, 0.64), 0.3, 0.3)], dmetal, seg=12, cap=False)
crate = mat("crate", (120, 88, 54), pass_index=2)
for (cx, cy, s_) in ((-4.9, 4.4, 0.7), (-4.2, 4.6, 0.55), (-4.6, 4.3, 0.5)):
    box("crate%.1f" % cx, (cx, cy, s_ / 2 + (0.7 if s_ == 0.5 else 0)), (s_, s_, s_), crate, rot=(0, 0, rnd.uniform(-0.3, 0.3)))

# ------------------------------------------------ postacie
squad = [
    ("tarcz1", dict(jacket="grey", pants="darkgrey", armor="plate", helmet="pot"), "spear", (2.45, 0.6)),
    ("tarcz2", dict(jacket="grey", pants="darkgrey", armor="plate", helmet="pot"), "spear", (2.45, -0.6)),
    ("strzel", dict(jacket="olive", pants="olive", helmet="mil"), "rifle", (1.25, 1.25)),
    ("zwiad", dict(jacket="teal", pants="darkgrey", mask="gas"), "rifle", (1.35, -0.15)),
    ("lamacz", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True), "hammer", (1.15, -1.45)),
    ("choraz", dict(jacket="blue", pants="blue", helmet="mil"), "banner", (0.05, 0.55)),
    ("luczn", dict(jacket="olive", pants="brown", hair="hair_l"), "bow", (-0.05, -0.85)),
]
rigs = {}
for n, o, pose, (x, y) in squad:
    r = human(n, o, pose); stand_pose(r, arms=(pose in ("idle", "banner"))); r.place((x, y, 0), -18); rigs[n] = r
walker = human("walker", dict(jacket="brown", pants="brown", beard=True, strap=False), "idle")
fireguy = human("fireguy", dict(jacket="leather", pants="brown", hair="hair_l", strap=False), "idle"); stand_pose(fireguy); fireguy.place((FX + 0.9, FY - 0.7, 0), 145)
mutw = human("mutw", dict(skin="pale", jacket="brown", pants="brown", third_arm=True, glow_eyes=True, strap=False), "idle"); stand_pose(mutw); mutw.place((-7.2, -0.6, 0), -50)
og1, og2 = ogar("og1"), ogar("og2")
kz = krzykacz("krz"); krzykacz_pose(kz, 0); kz.place((10.2, 4.4, 0), 196)
ns = nosiciel("nos"); stand_pose(ns); ns.place((8.8, -3.0, 0), 168)
rozrost("roz", (11.4, 1.0, 0.5))
rats = []
for k in range(14):
    rats.append((5.6 + rnd.uniform(0, 2.4), -3.0 - rnd.uniform(0, 1.6), rnd.uniform(-0.4, 0.4)))

# latarka zwiadowcy (stozek w Mgle)
zr = rigs["zwiad"]; yaw = math.radians(-18)
mz = V(zr.props["muzzle"]); mzw = V((1.35 + mz.x * math.cos(yaw) - mz.y * math.sin(yaw), -0.15 + mz.x * math.sin(yaw) + mz.y * math.cos(yaw), mz.z))
spot_light("torch", mzw, (0, math.radians(-90 + 5), yaw), (0.85, 0.92, 1.0), 2600, 24, 0.3)
sr = rigs["strzel"]; mz2 = V(sr.props["muzzle"])
mz2w = V((1.25 + mz2.x * math.cos(yaw) - mz2.y * math.sin(yaw), 1.25 + mz2.x * math.sin(yaw) + mz2.y * math.cos(yaw), mz2.z))
flash_light = point_light("flash", mz2w + V((0.15, 0, 0)), (1.0, 0.85, 0.6), 0, 0.05)
flash_obj = ellipsoid("flash_obj", mz2w + V((0.12, 0, 0)), (0.12, 0.06, 0.06), mat("flashm", (255, 240, 190), pass_index=3, emit=(255, 230, 170), strength=14))

camera((-0.2, 2.4, 1.4), 52, 24, (640, 360), yaw_deg=-32)
fill = sun("charfill", (math.radians(62), 0, math.radians(-32 + 180 + 20)), (1.0, 0.9, 0.78), 0.9)
fill.data.light_linking if False else None
fill.light_linking.receiver_collection = char_collection()

rat_objs = []
for t in range(T):
    walk_pose(walker, t % 8); walker.place((-9.8 + 0.16 * t, -0.9, 0), 0)
    ogar_pose(og1, t % 8); og1.place((6.0 - 0.14 * t, 0.35, 0), 186)
    ogar_pose(og2, (t + 3) % 8); og2.place((7.3 - 0.14 * t, -1.5, 0), 178)
    krzykacz_pose(kz, t)
    for o in rat_objs: bpy.data.objects.remove(o, do_unlink=True)
    rat_objs = []
    for k, (rx, ry, ra) in enumerate(rats):
        rat_objs += rat("rat%d_%d" % (k, t), (rx - 0.09 * t - 0.03 * (k % 3) * t, ry + 0.05 * math.sin(t + k), 0), math.pi + ra)
    fl = 1 + 0.18 * math.sin(t * 2.1) + 0.1 * math.sin(t * 5.3)
    firelight.data.energy = 260 * fl
    for k, f in enumerate(flames): f.scale = (1, 1, 0.85 + 0.25 * abs(math.sin(t * 1.7 + k)))
    shot = (t % 6) in (2,)
    flash_light.data.energy = 500 if shot else 0
    flash_obj.hide_render = not shot
    bpy.context.view_layer.update()
    render(OUT % t)
