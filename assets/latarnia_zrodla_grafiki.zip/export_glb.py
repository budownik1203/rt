"""Eksport postaci z animacjami do glTF (.glb) dla Godota: kazda akcja jako osobny klip."""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A
reset()
r = human("zolnierz", dict(jacket="olive", pants="olive", helmet="mil", armor="vest"), "rifle")
sc = bpy.context.scene; sc.render.fps = 12
CLIPS = {"idle": (24, lambda f: A.merge(A.stance(), A.low_ready(), A.breathe(f, 24))), "walk": (12, lambda f: A.merge(A.walk(f, 12, stride=24, arms=False), A.low_ready())),
         "run": (8, lambda f: A.run_rifle(f, 8)), "shoot": (24, A.clip_shoot().sample), "reload": (24, A.clip_reload().sample),
         "kneel_shoot": (24, A.clip_shoot(A.kneel()).sample), "prone": (16, lambda f: A.crawl(f, 16)), "flinch": (8, lambda f: A.flinch()),
         "stagger": (14, A.stagger), "death": (24, A.clip_death().sample)}
ob = r.ob; ob.animation_data_create()
bones = [pb for pb in ob.pose.bones]
for name, (n, fn) in CLIPS.items():
    act = bpy.data.actions.new(name); ob.animation_data.action = act
    for f in range(n + 1):
        A.apply(r, fn(f), (0, 0, 0), 0); bpy.context.view_layer.update()
        # wypiekamy IK do FK: zapisujemy wynikowe macierze kosci
        mats = {pb.name: pb.matrix.copy() for pb in bones}
        for pb in bones:
            for c in pb.constraints: c.mute = True
        for pb in bones:
            pb.matrix = mats[pb.name]; bpy.context.view_layer.update()
            pb.keyframe_insert("rotation_quaternion", frame=f); pb.keyframe_insert("location", frame=f)
        for pb in bones:
            for c in pb.constraints: c.mute = False
        ob.keyframe_insert("location", frame=f); ob.keyframe_insert("rotation_euler", frame=f)
    act.use_fake_user = True
    tr = ob.animation_data.nla_tracks.new(); tr.name = name; tr.strips.new(name, 0, act)
    ob.animation_data.action = None
for pb in bones:
    for c in list(pb.constraints): pb.constraints.remove(c)
bpy.ops.object.select_all(action="SELECT")
bpy.ops.export_scene.gltf(filepath="/home/claude/latarnia3d/export/zolnierz.glb", export_format="GLB", export_animations=True,
                          export_animation_mode="NLA_TRACKS", export_force_sampling=True, export_apply=False)
print("EXPORTED")
