"""Animacje bestiariusza (petle 24 klatki) - dopasowane do zachowan z dokumentu."""
import math
from anim import P, merge, walk, stance, clip_shoot, low_ready
def sn(f, n, ph=0.0): return math.sin(2 * math.pi * (f / n + ph))
def cs(f, n, ph=0.0): return math.cos(2 * math.pi * (f / n + ph))

def odmieniec_walk(rest):
    """Wolny, ciezki chod: prawa noga ciagnieta, przerosle ramie wahadlo z opoznieniem."""
    def fn(f):
        w = walk(f, 24, stride=17, arms=False)
        p = merge(rest, w)
        p["rot"]["upperarm.R"] = (-16, -10 + 14 * sn(f, 24, -0.15), 0)
        p["rot"]["forearm.R"] = (0, -20 - 6 * sn(f, 24, -0.3), 0)
        p["rot"]["foot.R"] = (0, 22 * max(0.0, sn(f, 24, 0.5)), 0)
        p["rot"]["chest"] = (0, 6, -10 + 6 * sn(f, 24))
        p["root"] = (0, 0, 0, 0, 3 * sn(f, 24))
        return p
    return fn

def nasladowca_twitch(rest):
    """Nasluchuje: gwaltowne przechylenia glowy, kolysanie, chwilami bezruch."""
    def fn(f):
        k = f % 24
        jerk = (22 if k in (3, 4, 5) else -18 if k in (11, 12) else 10 if k in (18, 19, 20) else 0)
        return merge(rest, P(rot={"head": (jerk * 0.4, 0, jerk), "neck": (0, 4 * sn(f, 24), 6 * sn(f, 12)), "chest": (0, 2 * sn(f, 24), 0)}))
    return fn

def spiacy_wake(rest):
    """Oddycha w kokonie; w polowie petli budzi sie na halas: szarpniecie glowy i wstrzymanie."""
    def fn(f):
        k = f % 24
        p = merge(rest, P(rot={"chest": (0, 1.5 * sn(f, 24), 0)}, loc={"hips": (0, 0, 0.006 * sn(f, 24))}))
        if 10 <= k <= 18:
            t = min(1.0, (k - 10) / 2.0)
            p = merge(p, P(rot={"neck": (0, -40 * t, 0), "head": (0, -25 * t, 6 * sn(f, 4) * t)}))
        return p
    return fn

def zrosnieci_shuffle(rest):
    def fn(f):
        w = walk(f, 20, stride=14, arms=False)
        p = merge(rest, w)
        p["rot"]["chest"] = (0, 4, -6 + 10 * sn(f, 20, 0.25))
        p["rot"]["upperarm.L"] = (20, -10 + 18 * sn(f, 10), 0); p["rot"]["upperarm.R"] = (-24, -16 + 18 * sn(f, 10, 0.5), 0)
        p["root"] = (0, 0, 0, 0, 5 * sn(f, 20))
        return p
    return fn

def zolnierz_tremor(rest):
    sh = clip_shoot()
    def fn(f):
        p = sh.sample(f % 24)
        return merge(p, P(rot={"head": (0, 6, 14 + 4 * sn(f, 3)), "chest": (0, 0, 2 * sn(f, 5)), "weapon": (2 * sn(f, 4), 0, 0)}))
    return fn

def opiekunka_stalk(rest):
    def fn(f):
        w = walk(f, 24, stride=26, arms=False)
        p = merge(rest, w)
        reach = max(0.0, sn(f, 24, 0.1))
        p["rot"]["upperarm.L"] = (12, -30 - 30 * reach, 0); p["rot"]["upperarm.R"] = (-12, -40 - 30 * (1 - reach), 0)
        p["rot"]["forearm.L"] = (0, -40 + 20 * reach, 0)
        p["rot"]["head"] = (0, -10, 14 * sn(f, 24))
        return p
    return fn

def pielgrzym_walk(rest):
    def fn(f):
        w = walk(f, 20, stride=14, arms=False)
        p = merge(rest, w)
        p["rot"]["weapon"] = (0, 6 * sn(f, 20), 0)
        p["rot"]["upperarm.L"] = (6, 6 * cs(f, 20), 0)
        return p
    return fn

def echo_drift(rest):
    def fn(f):
        p = merge(rest, P(rot={"head": (0, 0, 20 * sn(f, 24)), "spine": (0, 4 * sn(f, 12), 0)}))
        r = p["root"]; p["root"] = (0.15 * sn(f, 24), 0, r[2] + 0.06 * sn(f, 8), 0, 2 * sn(f, 24))
        return p
    return fn

def pasterz_command(rest):
    """Wznosi kostur, wskazuje cel, wydaje rozkaz (dowodzi jak oficer)."""
    def fn(f):
        k = f % 24
        t = min(1.0, max(0.0, (k - 4) / 4.0)) if k < 16 else max(0.0, 1 - (k - 16) / 5.0)
        return merge(rest, P(rot={"upperarm.L": (40 * t, -70 * t, 0), "forearm.L": (0, 30 * t, 0), "chest": (0, -6 * t, 12 * t), "head": (0, -10 * t, -12 * t),
                                  "upperarm.R": (0, -20 * t, 0)}, loc={"hips": (0, 0, 0.02 * t)}))
    return fn

def bezoki_crawl(rest):
    def fn(f):
        p = merge(rest, P())
        for b, ph, base in (("upperarm.L", 0.0, -70), ("upperarm.R", 0.5, -64), ("thigh.L", 0.5, -60), ("thigh.R", 0.0, -40)):
            p["rot"][b] = (p["rot"].get(b, (0, 0, 0))[0], base + 18 * sn(f, 12, ph), 0)
        p["rot"]["head"] = (0, -30, 12 * sn(f, 6))
        p["root"] = (0, 0, 0.02 * abs(sn(f, 6)), 0, 3 * sn(f, 12))
        return p
    return fn

def cma_flap(rest):
    def fn(f):
        a = 35 * sn(f, 4)
        p = merge(rest, P(rot={"wing.L": (a, 0, 0), "wing.R": (-a, 0, 0), "wing2.L": (a * 0.8, 0, 0), "wing2.R": (-a * 0.8, 0, 0)}))
        r = p["root"]; p["root"] = (0.3 * cs(f, 24), 0.3 * sn(f, 24), r[2] + 0.1 * sn(f, 4, 0.25), 6 * sn(f, 24), 10 * cs(f, 24))
        return p
    return fn

def kopacz_dig(rest):
    def fn(f):
        p = merge(rest, P())
        p["rot"]["upperarm.L"] = (30, -50 + 40 * sn(f, 8), 0); p["rot"]["upperarm.R"] = (-30, -50 + 40 * sn(f, 8, 0.5), 0)
        p["rot"]["forearm.L"] = (0, -40 - 20 * sn(f, 8), 0); p["rot"]["forearm.R"] = (0, -40 - 20 * sn(f, 8, 0.5), 0)
        p["rot"]["chest"] = (0, 16, 8 * sn(f, 8)); p["loc"]["hips"] = (0, 0, -0.16 - 0.03 * abs(sn(f, 8)))
        return p
    return fn

ANIMS = {"Odmieniec": odmieniec_walk, "Naśladowca": nasladowca_twitch, "Śpiący": spiacy_wake, "Zrośnięci": zrosnieci_shuffle,
         "Dawny Żołnierz": zolnierz_tremor, "Opiekunka": opiekunka_stalk, "Pielgrzym": pielgrzym_walk, "Echo": echo_drift,
         "Pasterz": pasterz_command, "Bezoki": bezoki_crawl, "Ćma": cma_flap, "Kopacz": kopacz_dig}
