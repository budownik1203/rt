"""Animacje mutantow: Ogar (galop, skok z ugryzieniem, smierc), Krzykacz (chod, krzyk, ciecie, smierc),
Nosiciel (chod kaczkowaty, nabrzmienie i wybuch), szczury (roj)."""
import math, random
from mathutils import Vector as V, Matrix
from anim import P, merge, Clip, ease, lerp_pose, walk, stance

def recenter(ob):
    """Przenosi poczatek obiektu do srodka bryly, zeby skalowanie dzialalo wokol srodka."""
    c = sum((v.co for v in ob.data.vertices), V()) / len(ob.data.vertices)
    ob.data.transform(Matrix.Translation(-c)); ob.matrix_basis = Matrix.Translation(c)
    return ob

# ------------------------------------------------------------------ OGAR (czworonog, chitynowy pancerz)
def ogar_gallop(f, n=6):
    """Galop obrotowy: tylne nogi lekko przesuniete w fazie, przednie w przeciwfazie; kregoslup zgina sie i prostuje,
    faza lotu przy wyprostowaniu, glowa stabilna."""
    p = (f % n) / n
    pose = P()
    ph = {"hup.L": 0.0, "hup.R": 0.10, "fup.L": 0.50, "fup.R": 0.60}
    for b, q0 in ph.items():
        q = (p + q0) % 1.0; c = math.cos(2 * math.pi * q); sn = math.sin(2 * math.pi * q)
        side = b[-1]; leg = b[0]
        pose["rot"][b] = (0, -46 * c, 0)
        lo = leg + "lo." + side; paw = leg + "paw." + side
        if leg == "f":
            pose["rot"][lo] = (0, 50 * max(0.0, sn), 0)              # przednia zgina sie do tylu przy przenoszeniu
            pose["rot"][paw] = (0, 40 * max(0.0, sn), 0)
        else:
            pose["rot"][lo] = (0, -45 * max(0.0, sn), 0)             # tylna zgina sie do przodu
            pose["rot"][paw] = (0, -30 * max(0.0, sn), 0)
    flex = math.sin(2 * math.pi * p)
    pose["rot"]["spine"] = (0, -15 * flex, 0)                         # zebranie / wyprostowanie
    pose["rot"]["chest"] = (0, 12 * flex, 0)
    pose["rot"]["neck"] = (0, -4 * flex, 0)
    pose["rot"]["head"] = (0, 6 * flex, 0)
    pose["rot"]["jaw"] = (0, 18, 0)
    pose["rot"]["tail1"] = (0, -12 * flex, 6 * math.cos(2 * math.pi * p))
    pose["rot"]["tail2"] = (0, -10 * flex, 0)
    pose["loc"]["pelvis"] = (0, 0, 0.06 * max(0.0, math.sin(2 * math.pi * p + 0.6)) - 0.03)
    pose["root"] = (0, 0, 0, 4 * flex, 0)
    return pose

def ogar_crouch():
    return P(rot={"fup.L": (0, -20, 0), "fup.R": (0, -16, 0), "flo.L": (0, 60, 0), "flo.R": (0, 60, 0), "fpaw.L": (0, -30, 0), "fpaw.R": (0, -30, 0),
                  "hup.L": (0, -30, 0), "hup.R": (0, -30, 0), "hlo.L": (0, 40, 0), "hlo.R": (0, 40, 0),
                  "neck": (0, 18, 0), "head": (0, -16, 0), "jaw": (0, 8, 0), "tail1": (0, 20, 0), "spine": (0, -6, 0)},
             loc={"pelvis": (0, 0, -0.16)}, root=(0, 0, 0, 6))

def ogar_air(t):
    """t 0..1 w locie: przednie lapy wyciagniete do celu, tylne do tylu, paszcza otwarta."""
    return P(rot={"fup.L": (0, -75, 0), "fup.R": (0, -65, 0), "flo.L": (0, -10, 0), "flo.R": (0, -5, 0), "fpaw.L": (0, -30, 0), "fpaw.R": (0, -30, 0),
                  "hup.L": (0, 70, 0), "hup.R": (0, 62, 0), "hlo.L": (0, 20, 0), "hlo.R": (0, 20, 0), "hpaw.L": (0, 40, 0), "hpaw.R": (0, 40, 0),
                  "spine": (0, 6, 0), "neck": (0, -10, 0), "head": (0, 10, 0), "jaw": (0, 42, 0), "tail1": (0, -18, 0), "tail2": (0, -10, 0)},
             root=(0.0, 0, 0, -14 + 26 * t))

def clip_ogar_pounce():
    idle = merge(ogar_gallop(0, 6), P(rot={"jaw": (0, -10, 0)}))
    idle = P(rot={"jaw": (0, 10, 0), "neck": (0, 6, 0), "head": (0, -4, 0)})
    land = merge(ogar_crouch(), P(rot={"neck": (0, 10, 0), "head": (0, 6, 0), "jaw": (0, 40, 0)}, root=(1.7, 0, 0, 10)))
    bite = merge(ogar_crouch(), P(rot={"neck": (0, 26, 0), "head": (0, 22, 0), "jaw": (0, -4, 0), "fup.L": (0, -35, 0), "fup.R": (0, -35, 0)},
                                 loc={"pelvis": (0.08, 0, 0.04)}, root=(1.85, 0, 0, 14)))
    shake = merge(bite, P(rot={"neck": (0, 0, 18), "head": (0, 0, 10)}))
    shake2 = merge(bite, P(rot={"neck": (0, 0, -18), "head": (0, 0, -10)}))
    def air(t, dx, dz): return merge(ogar_air(t), P(root=(dx, 0, dz, 0)))
    return Clip(24, [(0, idle, "io"), (4, ogar_crouch(), "hold"), (6, ogar_crouch(), "snap"),
                     (7, air(0.0, 0.25, 0.20), "lin"), (8, air(0.2, 0.60, 0.48), "lin"), (9, air(0.4, 0.95, 0.58), "lin"),
                     (10, air(0.6, 1.25, 0.52), "lin"), (11, air(0.85, 1.55, 0.28), "in"), (12, land, "out"),
                     (14, bite, "snap"), (15, shake, "io"), (16, shake2, "io"), (17, shake, "io"), (18, bite, "io"),
                     (21, merge(idle, P(root=(1.85, 0, 0, 0))), "io"), (23, idle, "hold")], loop=True)

def clip_ogar_death():
    run = ogar_gallop(2, 6)
    hit = merge(run, P(rot={"neck": (0, -30, 0), "head": (0, -25, 0), "jaw": (0, 40, 0), "spine": (0, 10, 0)}, root=(0.05, 0, 0.05, -12, 0)))
    tumble = P(rot={"fup.L": (0, -60, 0), "fup.R": (0, 30, 0), "flo.L": (0, 70, 0), "hup.L": (0, 50, 0), "hup.R": (0, -40, 0), "hlo.R": (0, -60, 0),
                    "neck": (0, 20, 12), "head": (0, 30, 0), "jaw": (0, 30, 0), "spine": (0, -12, 0), "tail1": (0, 0, 30)},
               loc={"pelvis": (0, 0, -0.2)}, root=(0.35, 0, -0.05, 8, 60))
    lie = P(rot={"fup.L": (0, -30, 0), "fup.R": (0, -10, 0), "flo.L": (0, 40, 0), "flo.R": (0, 30, 0), "hup.L": (0, 20, 0), "hup.R": (0, 10, 0),
                 "hlo.L": (0, -40, 0), "hlo.R": (0, -30, 0), "neck": (0, 10, 18), "head": (0, 20, 10), "jaw": (0, 26, 0), "tail1": (0, 0, 24), "tail2": (0, 0, 20)},
            loc={"pelvis": (0, 0, -0.32)}, root=(0.55, 0, 0.1, 0, 86))
    twitch = merge(lie, P(rot={"hup.L": (0, 14, 0), "hlo.L": (0, -18, 0), "jaw": (0, -10, 0)}))
    return Clip(24, [(0, run, "snap"), (2, hit, "io"), (5, tumble, "in"), (8, lie, "out"), (9, merge(lie, P(root=(0, 0, 0.04, 0, -6))), "io"),
                     (11, lie, "hold"), (15, twitch, "io"), (17, lie, "hold"), (20, twitch, "io"), (22, lie, "hold")])

# ------------------------------------------------------------------ KRZYKACZ (wychudzony, dlugie rece)
def krz_hunch():
    return P(rot={"spine": (0, 18, 0), "chest": (0, 14, 0), "neck": (0, 28, 0), "head": (0, -30, 0),
                  "upperarm.L": (14, 0, 0), "upperarm.R": (-14, 0, 0), "forearm.L": (0, -18, 0), "forearm.R": (0, -18, 0),
                  "thigh.L": (0, -14, 0), "shin.L": (0, 22, 0), "thigh.R": (0, -14, 0), "shin.R": (0, 22, 0)}, loc={"hips": (0, 0, -0.05)})

def krz_walk(f, n=14):
    """Powloczysty chod: nierowny krok (prawa noga ciagnie sie), rece zwisaja z opoznieniem, kiwanie glowa."""
    p = (f % n) / n
    w = walk(f, n, stride=20, arms=False)
    pose = merge(krz_hunch(), w)
    lag = math.cos(2 * math.pi * (p - 0.12))
    pose["rot"]["upperarm.L"] = (14, 16 * lag, 0); pose["rot"]["upperarm.R"] = (-14, -16 * lag, 0)
    pose["rot"]["forearm.L"] = (0, -18 - 8 * max(0, lag), 0); pose["rot"]["forearm.R"] = (0, -18 - 8 * max(0, -lag), 0)
    drag = max(0.0, math.sin(2 * math.pi * (p + 0.5)))
    pose["rot"]["foot.R"] = (0, -0.55 * pose["rot"]["thigh.R"][1] + 18 * drag, 0)        # ciagniecie stopy
    pose["rot"]["head"] = (0, -30 + 6 * math.sin(4 * math.pi * p), 8 * math.sin(2 * math.pi * p))
    pose["rot"]["chest"] = (0, 14, 7 * math.cos(2 * math.pi * p))
    return pose

def clip_krz_scream():
    h = krz_hunch()
    inhale = merge(h, P(rot={"spine": (0, -16, 0), "chest": (0, -18, 0), "neck": (0, -10, 0), "head": (0, -16, 0),
                             "upperarm.L": (20, 20, 0), "upperarm.R": (-20, 20, 0), "forearm.L": (0, -40, 0), "forearm.R": (0, -40, 0)},
                       loc={"hips": (-0.03, 0, 0.03)}, scl={"mouth": 0.7}))
    scream = merge(h, P(rot={"spine": (0, 6, 0), "chest": (0, 4, 0), "neck": (0, -8, 0), "head": (0, 10, 0),
                             "upperarm.L": (75, -10, 0), "upperarm.R": (-75, -10, 0), "forearm.L": (0, -10, 0), "forearm.R": (0, -10, 0),
                             "thigh.L": (0, -6, 6), "thigh.R": (0, 6, -6)}, loc={"hips": (0.03, 0, -0.04)}, scl={"mouth": 1.9, "throat": 1.6}))
    shake = merge(scream, P(rot={"head": (0, 0, 6), "chest": (0, 0, 3)}))
    shake2 = merge(scream, P(rot={"head": (0, 0, -6), "chest": (0, 0, -3)}))
    keys = [(0, h, "io"), (5, inhale, "hold"), (7, inhale, "snap"), (9, scream, "lin")]
    for k in range(10, 17): keys.append((k, shake if k % 2 else shake2, "lin"))
    keys += [(17, scream, "io"), (21, h, "hold")]
    return Clip(24, keys)

def clip_krz_slash():
    h = krz_hunch()
    wind = merge(h, P(rot={"upperarm.R": (-60, 40, 0), "forearm.R": (-40, -30, 0), "chest": (0, 6, -28), "spine": (0, 4, -8), "head": (0, 0, 20),
                           "upperarm.L": (20, -20, 0), "thigh.R": (0, 14, 0)}, loc={"hips": (-0.04, 0, -0.03)}))
    slash = merge(h, P(rot={"upperarm.R": (-30, -95, 0), "forearm.R": (0, -10, 0), "chest": (0, 22, 32), "spine": (0, 14, 10), "head": (0, 10, -20),
                            "upperarm.L": (25, 30, 0), "thigh.L": (0, -30, 0), "shin.L": (0, 30, 0)}, loc={"hips": (0.10, 0, -0.08)}, root=(0.18, 0, 0, 0)))
    follow = merge(slash, P(rot={"upperarm.R": (10, -40, 0), "chest": (0, 26, 40)}))
    return Clip(24, [(0, h, "io"), (6, wind, "hold"), (8, wind, "snap"), (10, slash, "out"), (12, follow, "io"), (14, follow, "io"), (21, h, "hold")])

def clip_krz_death():
    h = krz_hunch()
    jerk = merge(h, P(rot={"spine": (0, -20, 0), "chest": (0, -14, 0), "head": (0, -30, 0), "upperarm.L": (40, -30, 0), "upperarm.R": (-40, -30, 0)}))
    knees = merge(h, P(rot={"thigh.L": (0, -60, 0), "shin.L": (0, 110, 0), "thigh.R": (0, -50, 0), "shin.R": (0, 120, 0), "foot.L": (0, -40, 0), "foot.R": (0, -50, 0),
                            "spine": (0, 10, 0), "upperarm.L": (10, 0, 0), "upperarm.R": (-10, 0, 0)}, loc={"hips": (0, 0, -0.48)}))
    face = merge(knees, P(rot={"head": (0, -10, 20), "upperarm.L": (20, -60, 0), "upperarm.R": (-25, -70, 0)}, root=(0.3, 0, 0.14, 64)))
    lie = merge(face, P(root=(0.1, 0, 0.0, 8)))
    return Clip(24, [(0, h, "snap"), (2, jerk, "io"), (6, knees, "in"), (9, knees, "hold"), (10, knees, "in"), (13, face, "out"), (14, lie, "io"), (23, lie, "hold")])

# ------------------------------------------------------------------ NOSICIEL (nabrzmialy, zarodnikowy)
def nos_walk(f, n=16):
    """Ciezki chod kaczkowaty: krotki krok, duze kolysanie na boki, brzuch spozniony w ruchu."""
    p = (f % n) / n
    w = walk(f, n, stride=16, arms=False)
    sway = math.sin(2 * math.pi * p)
    w["rot"]["hips"] = (0, 0, 0); w["rot"]["chest"] = (0, -4, 0)
    w["rot"]["spine"] = (0, -6, 0)
    w["rot"]["upperarm.L"] = (24, 6 * sway, 0); w["rot"]["upperarm.R"] = (-24, -6 * sway, 0)
    w["rot"]["forearm.L"] = (0, -20, 0); w["rot"]["forearm.R"] = (0, -20, 0)
    w["rot"]["thigh.L"] = (8, w["rot"]["thigh.L"][1], 0); w["rot"]["thigh.R"] = (-8, w["rot"]["thigh.R"][1], 0)
    w["root"] = (0, 0, 0, 0, 7 * sway)
    w["scl"] = {"belly": 1.0 + 0.03 * math.sin(4 * math.pi * p - 0.8)}                 # brzuch faluje z opoznieniem
    return w

def clip_nos_burst():
    base = nos_walk(0)
    swell = lambda s, tw: merge(base, P(rot={"spine": (0, -10, 0), "head": (0, -18, 0), "upperarm.L": (45, 0, 0), "upperarm.R": (-45, 0, 0)},
                                       root=(0, 0, 0, 0, tw), scl={"belly": s}))
    keys = [(0, merge(base, P(scl={"belly": 1.0})), "io")]
    for k, f in enumerate(range(3, 13)):
        keys.append((f, swell(1.0 + 0.04 * (k + 1), 4 if k % 2 else -4), "lin"))
    pop = P(rot={"spine": (0, 30, 0), "head": (0, 30, 0), "thigh.L": (0, -50, 0), "shin.L": (0, 90, 0), "thigh.R": (0, -40, 0), "shin.R": (0, 90, 0)},
            loc={"hips": (0, 0, -0.30)}, root=(0, 0, 0, 0, 0), scl={"belly": 0.25}, vis={"belly": 0})
    keys += [(13, pop, "out"), (16, merge(pop, P(root=(0.15, 0, 0, 70))), "out"), (23, merge(pop, P(root=(0.15, 0, -0.02, 76))), "hold")]
    return Clip(24, keys)

# ------------------------------------------------------------------ szczury (roj)
def rat_path(k, f, n=24):
    rnd = random.Random(k * 13 + 1)
    ph = rnd.uniform(0, 6.28); r = rnd.uniform(0.3, 0.9); sp = rnd.choice((1, -1)) * rnd.uniform(0.8, 1.3)
    a = ph + sp * 2 * math.pi * f / n
    x = r * math.cos(a) * 1.3 + 0.15 * math.sin(3 * a); y = r * math.sin(a) * 0.9
    yaw = a + sp * math.pi / 2
    bob = 0.012 * abs(math.sin(2 * math.pi * f / 3 + k))
    return x, y, bob, yaw
