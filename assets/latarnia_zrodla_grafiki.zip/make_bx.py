import sys, math, json
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
W, H, ORT, T = 960, 640, 10.4, math.radians(50)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 15)
im = stylize('out/bestiary.exr').resize((W * 2, H * 2), Image.NEAREST); d = ImageDraw.Draw(im)
for nm, x, y in json.load(open('out/bestiary.json')):
    px = (W / 2 + x * W / ORT) * 2; py = (H / 2 - (y * math.cos(T) - 0.9 * math.sin(T)) * W / ORT) * 2 + 26
    w = d.textlength(nm, font=font)
    d.rectangle((px - w / 2 - 4, py - 2, px + w / 2 + 4, py + 18), fill=(20, 17, 28)); d.text((px - w / 2, py - 1), nm, font=font, fill=(226, 200, 150))
im.save('out/latarnia3d_bestiariusz.png')
