"""Eksport jednostek do symulatora bitew: kazda jednostka z pelnym zestawem klipow walki (anim_combat.py).
Uzycie: python3 export_combat.py -- [ludzie|mutanty|wszystko] [nazwa...]
Wynik: /home/claude/latarnia3d/export/walka/<nazwa>.glb
"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import lat3d, chars
from chars import *
import anim as A
import anim_combat as AC
from mathutils import Vector as V, Matrix

OUT = "/home/claude/latarnia3d/export/walka"
os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------------ kosci dodatkowe (skala 0/1 wlacza czesci)
EXTRA = {
    "bow": [("b_str_rest", (0.43, 0.03, 1.40), (0.43, 0.03, 1.46), "weapon"),
            ("b_str_draw", (0.06, -0.04, 1.50), (0.06, -0.04, 1.56), "chest"),
            ("b_arrow", (0.06, -0.04, 1.50), (0.12, -0.04, 1.50), "chest")],
    "crossbow": [("c_str_cock", (0.37, -0.08, 1.27), (0.37, -0.08, 1.33), "weapon"),
                 ("c_str_rel", (0.64, -0.08, 1.23), (0.64, -0.08, 1.29), "weapon"),
                 ("c_bolt", (0.37, -0.05, 1.30), (0.43, -0.05, 1.30), "weapon")],
}
_orig_bones = chars.human_bones
def _bones_ext(arm=1.0, leg=1.0, torso=1.0, pose="idle"):
    B = _orig_bones(arm, leg, torso, pose)
    return B + EXTRA.get(pose, [])

def rewire(r, n, kind):
    """Cieciwy i strzaly na kosci dodatkowe (naciagnieta/luzna, strzala, belt)."""
    obs = bpy.data.objects
    string = M("string", (200, 200, 190))
    if kind == "bow":
        for k in ("_str1", "_str2", "_arrow"):
            if n + k in obs: bpy.data.objects.remove(obs[n + k], do_unlink=True)
        top = V((0.50 - 0.10 * (1 - math.cos(1.25)), 0.03, 1.40 + 0.5 * math.sin(1.25))); bot = V((top.x, 0.03, 1.40 - 0.5 * math.sin(1.25)))
        draw = V((0.06, -0.04, 1.50))
        r.attach(cyl(n + "_strrest", top, bot, 0.004, string, seg=4), "b_str_rest")
        r.attach(cyl(n + "_strd1", top, draw, 0.004, string, seg=4), "b_str_draw")
        r.attach(cyl(n + "_strd2", draw, bot, 0.004, string, seg=4), "b_str_draw")
        r.attach(cyl(n + "_arrow", draw, (0.70, 0.02, 1.43), 0.006, WOOD(), seg=4), "b_arrow")
        r.attach(loft(n + "_arrowh", [((0.70, 0.02, 1.43), 0.012, 0.012), ((0.76, 0.024, 1.422), 0.001, 0.001)], METAL(), seg=4), "b_arrow")
        # kolczan na plecach
        r.attach(cyl(n + "_quiver", (-0.16, 0.08, 1.05), (-0.20, -0.06, 1.55), 0.045, STRAP(), seg=8), "chest")
        for k in range(4):
            r.attach(cyl(n + "_qa%d" % k, (-0.20 + 0.01 * k, -0.06 + 0.015 * k, 1.55), (-0.21 + 0.01 * k, -0.08 + 0.015 * k, 1.64), 0.005, WOOD(), seg=4), "chest")
    if kind == "crossbow":
        t = math.radians(8.2)
        D = V((math.cos(t), 0, -math.sin(t))); U = V((math.sin(t), 0, math.cos(t))); Y = V((0, 1, 0)); O = V((-0.03, -0.085, 1.318))
        G = lambda u, v=0.0, w=0.0: O + D * u + U * v + Y * w
        for k in ("_s1", "_s2"):
            if n + k in obs: r.attach(obs[n + k], "c_str_cock")
        for k in ("_bolt", "_boltp"):
            if n + k in obs: r.attach(obs[n + k], "c_bolt")
        tipL = G(0.74 - 0.10 * (1 - math.cos(1.2)), 0.0, 0.34 * math.sin(1.2)); tipR = G(0.74 - 0.10 * (1 - math.cos(1.2)), 0.0, -0.34 * math.sin(1.2))
        r.attach(cyl(n + "_srel", tipL, tipR, 0.003, string, seg=4), "c_str_rel")

def medic_kit(r, n):
    """Sanitariusz: torba z czerwonym krzyzem na biodrze i opaska na ramieniu."""
    r.attach(box(n + "_medbag", (0.02, 0.17, 0.98), (0.16, 0.07, 0.13), M("medbag", (150, 140, 110))), "spine")
    r.attach(box(n + "_medx1", (0.02, 0.207, 0.98), (0.07, 0.004, 0.022), M("redx", (170, 30, 30))), "spine")
    r.attach(box(n + "_medx2", (0.02, 0.207, 0.98), (0.022, 0.004, 0.07), M("redx", (170, 30, 30))), "spine")
    r.attach(loft(n + "_armband", [((-0.03, 0.20, 1.31), 0.052, 0.052), ((-0.03, 0.20, 1.26), 0.052, 0.052)], M("whiteb", (220, 214, 200))), "upperarm.L")

# ------------------------------------------------------------------ jednostki
import factions as FC
U = {
    # sklad gracza (epoka Zlomu)
    "tarczownik": ("spear", dict(jacket="leather", pants="brown", armor="plate", helmet="pot"), []),
    "rebacz": ("hammer", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True), []),
    "strzelec_luk": ("bow", dict(jacket="olive", pants="brown"), []),
    "strzelec_kusza": ("crossbow", dict(jacket="grey", pants="darkgrey", helmet="pot"), []),
    "sanitariusz": ("club", dict(jacket="grey", pants="brown", hair="hair_l"), [medic_kit]),
    "zwiadowca": ("bow", dict(jacket="olive", pants="olive"), [lambda r, n: FC.hood(r, n, M("hood_g", (70, 78, 56)))]),
    "nozownik_sklad": ("knife", dict(jacket="leather", pants="darkgrey"), []),
    "maczeta_sklad": ("machete", dict(jacket="brown", pants="brown", helmet="pot"), []),
}
BANDITS = {   # Szabrownicy: modele z frakcji, bronie jak w symulacji
    "sz_herszt": ("machete", 6), "sz_rozbijacz": ("club", 4), "sz_nozownik": ("knife", 1),
    "sz_lucznik": ("bow", 3), "sz_obdartus": ("spear", 0), "sz_psiarz": ("machete", 5),
}

def fresh():
    reset(); lat3d.MATS.clear(); lat3d.CHAR_COL = None
    bpy.context.scene.render.fps = 12

def apply_ext(r, pose):
    A.apply(r, pose, (0, 0, 0), 0)
    for b, s in pose.get("bscl", {}).items():
        if b in r.ob.pose.bones:
            v = max(0.001, float(s)); r.ob.pose.bones[b].scale = (v, v, v)

def bake(r, clips):
    ob = r.ob; ob.animation_data_create(); bones = list(ob.pose.bones)
    for pb in bones: pb.scale = (1, 1, 1)
    for cname, (n, fn) in clips.items():
        act = bpy.data.actions.new(cname); ob.animation_data.action = act
        for f in range(n + 1):
            for pb in bones: pb.scale = (1, 1, 1)
            apply_ext(r, fn(f)); bpy.context.view_layer.update()
            mats = {pb.name: pb.matrix.copy() for pb in bones}
            scl = {pb.name: tuple(pb.scale) for pb in bones}
            for pb in bones:
                for c in pb.constraints: c.mute = True
            for pb in bones:
                pb.matrix = mats[pb.name]; pb.scale = scl[pb.name]; bpy.context.view_layer.update()
                pb.keyframe_insert("rotation_quaternion", frame=f); pb.keyframe_insert("location", frame=f); pb.keyframe_insert("scale", frame=f)
            for pb in bones:
                for c in pb.constraints: c.mute = False
            ob.keyframe_insert("location", frame=f); ob.keyframe_insert("rotation_euler", frame=f)
        act.use_fake_user = True
        tr = ob.animation_data.nla_tracks.new(); tr.name = cname; tr.strips.new(cname, 0, act)
        ob.animation_data.action = None
    for pb in bones:
        for c in list(pb.constraints): pb.constraints.remove(c)

def save(path):
    for o in list(bpy.data.objects):
        if o.type in ("LIGHT", "CAMERA"): bpy.data.objects.remove(o, do_unlink=True)
        elif o.type == "MESH" and o.hide_render: bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.export_scene.gltf(filepath=path, export_format="GLB", export_animations=True, export_animation_mode="NLA_TRACKS",
                              export_force_sampling=True, export_apply=False)

def build_human(name, kind, outfit, acc):
    chars.human_bones = _bones_ext
    try:
        r = human(name, outfit, kind)
    finally:
        chars.human_bones = _orig_bones
    rewire(r, name, kind)
    for a in acc: a(r, name)
    return r

def build_bandit(name, kind, idx):
    import factions2 as F2
    label, _pose, outfit, accs = F2.UNITS["szabrownicy"][idx]
    acc = [a for a in accs if callable(a)]
    chars.human_bones = _bones_ext
    try:
        r = F2.build_unit("szabrownicy", idx, label, kind, outfit, acc + (["noshield"] if kind == "spear" else []))
    finally:
        chars.human_bones = _orig_bones
    rewire(r, "szabrownicy%d" % idx, kind)
    return r

def export_humans(only=None):
    for nm, (kind, outfit, acc) in U.items():
        if only and nm not in only: continue
        fresh(); r = build_human(nm, kind, outfit, acc); bake(r, AC.human_set(kind)); save(OUT + "/%s.glb" % nm); print("EXPORTED", nm)
    for nm, (kind, idx) in BANDITS.items():
        if only and nm not in only: continue
        fresh(); r = build_bandit(nm, kind, idx); bake(r, AC.human_set(kind)); save(OUT + "/%s.glb" % nm); print("EXPORTED", nm)

if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    what = args[0] if args else "ludzie"
    only = set(args[1:]) or None
    if what in ("ludzie", "wszystko"): export_humans(only)
    if what in ("mutanty", "wszystko"):
        import export_mutants; export_mutants.run(OUT, only)
