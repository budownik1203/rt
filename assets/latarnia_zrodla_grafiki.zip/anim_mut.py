"""Animacje mutantow: Ogar (galop, skok z ugryzieniem, smierc), Krzykacz (pokraczny bieg, krzyk), Nosiciel (chod, pekniecie)."""
import math
from anim import P, merge, lerp_pose, Clip, ease, run

# ------------------------------------------------------------------ OGAR (kosci: pelvis, spine, chest, neck, head, jaw, tail1/2, fup/flo/fpaw, hup/hlo/hpaw)
def ogar_gallop(f, n=8):
    """Galop obrotowy: przednie lapy prawie razem, tylne w przeciwfazie; kregoslup na przemian sie skraca i wydluza."""
    p = (f % n) / n
    pose = P()
    for leg, ph in (("f", 0.0), ("h", 0.5)):
        for side, ps in (("L", 0.0), ("R", 0.09)):
            q = (p + ph + ps) % 1.0
            c = math.cos(2 * math.pi * q); s = math.sin(2 * math.pi * q)
            if leg == "f":
                pose["rot"]["fup." + side] = (0, -38 * c, 0)
                pose["rot"]["flo." + side] = (0, -45 * max(0.0, s), 0)
                pose["rot"]["fpaw." + side] = (0, 30 * max(0.0, s), 0)
            else:
                pose["rot"]["hup." + side] = (0, -42 * c, 0)
                pose["rot"]["hlo." + side] = (0, 40 * max(0.0, -s) + 10, 0)
                pose["rot"]["hpaw." + side] = (0, -30 * max(0.0, -s), 0)
    flex = math.sin(2 * math.pi * p)
    pose["rot"]["spine"] = (0, 7 * flex, 0)
    pose["rot"]["chest"] = (0, -5 * flex, 0)
    pose["rot"]["neck"] = (0, -6 * flex + 6, 0)
    pose["rot"]["head"] = (0, 4 * flex, 0)
    pose["rot"]["jaw"] = (0, 14 + 6 * flex, 0)
    pose["rot"]["tail1"] = (0, 10 * flex, 6 * math.cos(2 * math.pi * p))
    pose["rot"]["tail2"] = (0, 12 * flex, 0)
    pose["root"] = (0, 0, 0.07 * max(0.0, math.sin(2 * math.pi * p + 0.6)), 4 * flex, 0)
    return pose

def _ogar_crouch(d=1.0):
    return P(rot={"fup.L": (0, -20 * d, 0), "fup.R": (0, -16 * d, 0), "flo.L": (0, -50 * d, 0), "flo.R": (0, -50 * d, 0), "fpaw.L": (0, 40 * d, 0), "fpaw.R": (0, 40 * d, 0),
                  "hup.L": (0, -34 * d, 0), "hup.R": (0, -34 * d, 0), "hlo.L": (0, 40 * d, 0), "hlo.R": (0, 40 * d, 0), "hpaw.L": (0, -20 * d, 0), "hpaw.R": (0, -20 * d, 0),
                  "neck": (0, 18 * d, 0), "head": (0, -16 * d, 0), "jaw": (0, 10, 0), "tail1": (0, -14 * d, 0)},
             root=(0, 0, -0.14 * d, 6 * d, 0))

def clip_ogar_pounce():
    stand = P(rot={"jaw": (0, 10, 0), "neck": (0, 4, 0)})
    crouch = _ogar_crouch(1.0)
    shiver = merge(crouch, P(rot={"tail1": (0, -4, 8)}))
    launch = P(rot={"hup.L": (0, 40, 0), "hup.R": (0, 44, 0), "hlo.L": (0, -10, 0), "hlo.R": (0, -10, 0), "hpaw.L": (0, 30, 0), "hpaw.R": (0, 30, 0),
                    "fup.L": (0, -70, 0), "fup.R": (0, -64, 0), "flo.L": (0, -20, 0), "flo.R": (0, -20, 0),
                    "neck": (0, -10, 0), "head": (0, 6, 0), "jaw": (0, 38, 0), "tail1": (0, 18, 0)}, root=(0.25, 0, 0.12, -14, 0))
    air = merge(launch, P(root=(0.95, 0, 0.32, -6, 0)))
    land = P(rot={"fup.L": (0, -30, 0), "fup.R": (0, -26, 0), "flo.L": (0, -30, 0), "flo.R": (0, -30, 0), "hup.L": (0, -20, 0), "hup.R": (0, -20, 0),
                  "hlo.L": (0, 30, 0), "hlo.R": (0, 30, 0), "neck": (0, 20, 0), "head": (0, 10, 0), "jaw": (0, 4, 0), "tail1": (0, 12, 0)}, root=(1.55, 0, -0.08, 10, 0))
    shake_a = merge(land, P(rot={"neck": (0, 0, 18), "head": (0, 0, 12), "jaw": (0, -2, 0)}))
    shake_b = merge(land, P(rot={"neck": (0, 0, -18), "head": (0, 0, -12), "jaw": (0, -2, 0)}))
    back = merge(stand, P(root=(1.55, 0, 0, 0, 0)))
    return Clip(28, [(0, stand, "io"), (4, crouch, "io"), (6, shiver, "io"), (7, crouch, "snap"), (8, launch, "out"), (10, air, "in"), (12, land, "out"),
                     (14, shake_a, "io"), (16, shake_b, "io"), (18, shake_a, "io"), (20, shake_b, "io"), (22, back, "hold"), (27, back, "hold")], loop=True)

def clip_ogar_death():
    stand = ogar_gallop(0)
    hit = merge(stand, P(rot={"neck": (0, -30, 10), "head": (0, -20, 0), "jaw": (0, 40, 0), "spine": (0, -8, 0)}, root=(-0.08, 0, 0.05, -10, 0)))
    buckle = P(rot={"fup.L": (0, -10, 0), "fup.R": (0, -10, 0), "flo.L": (0, -70, 0), "flo.R": (0, -70, 0), "hup.L": (0, -30, 0), "hup.R": (0, -30, 0),
                    "hlo.L": (0, 50, 0), "hlo.R": (0, 50, 0), "neck": (0, 30, 0), "jaw": (0, 30, 0)}, root=(0.05, 0, -0.18, 8, 0))
    side = P(rot={"fup.L": (20, -30, 0), "fup.R": (-10, 20, 0), "flo.L": (0, -40, 0), "hup.L": (10, -40, 0), "hup.R": (-10, 30, 0), "hlo.R": (0, 30, 0),
                  "neck": (0, 10, -30), "head": (0, 0, -10), "jaw": (0, 34, 0), "tail1": (0, -10, 20), "tail2": (0, -10, 0)}, root=(0.1, 0, 0.12, 0, 84))
    twitch = merge(side, P(rot={"hup.R": (0, -16, 0), "fup.R": (0, -14, 0), "jaw": (0, -10, 0)}))
    return Clip(24, [(0, stand, "snap"), (1, hit, "io"), (4, buckle, "in"), (8, side, "out"), (9, merge(side, P(root=(0, 0, 0.06, 0, -6))), "io"),
                     (11, side, "hold"), (15, twitch, "snap"), (16, side, "io"), (19, side, "hold"), (23, side, "hold")], loop=False)

# ------------------------------------------------------------------ KRZYKACZ (szkielet czlowieka, dlugie rece)
def krzykacz_base():
    return P(rot={"spine": (0, 18, 0), "chest": (0, 14, 0), "neck": (0, 28, 0), "head": (0, -30, 0),
                  "upperarm.L": (14, 0, 0), "upperarm.R": (-14, 0, 0), "forearm.L": (0, -18, 0), "forearm.R": (0, -18, 0),
                  "thigh.L": (0, -14, 0), "shin.L": (0, 22, 0), "thigh.R": (0, -14, 0), "shin.R": (0, 22, 0)}, loc={"hips": (0, 0, -0.06)})

def krzykacz_lope(f, n=8):
    """Pokraczny bieg: mocno pochylony, rece wloka sie za cialem, glowa kiwa sie z opoznieniem."""
    b = run(f, n, stride=40, arms=False)
    p = (f % n) / n; c = math.cos(2 * math.pi * p)
    b["rot"]["spine"] = (0, 34, 0); b["rot"]["chest"] = (0, 12, 10 * c)
    b["rot"]["neck"] = (0, -10, 0); b["rot"]["head"] = (0, -24 + 8 * math.sin(4 * math.pi * p + 1.2), -8 * c)
    for side, s in (("L", 1), ("R", -1)):
        b["rot"]["upperarm." + side] = (s * 22, 40 + 14 * c * s, 0)
        b["rot"]["forearm." + side] = (0, -10 - 12 * max(0, c * s), 0)
    return b

def clip_krzykacz_scream():
    base = krzykacz_base()
    inhale = merge(base, P(rot={"spine": (0, -12, 0), "chest": (0, -20, 0), "neck": (0, -18, 0), "head": (0, -18, 0),
                                "upperarm.L": (30, 10, 0), "upperarm.R": (-30, 10, 0), "forearm.L": (0, -40, 0), "forearm.R": (0, -40, 0)}, loc={"hips": (0, 0, 0.03)}))
    scream = merge(base, P(rot={"spine": (0, 6, 0), "chest": (0, 6, 0), "neck": (0, -10, 0), "head": (0, 14, 0),
                                "upperarm.L": (75, -30, 0), "upperarm.R": (-75, -30, 0), "forearm.L": (0, -10, 0), "forearm.R": (0, -10, 0),
                                "thigh.L": (0, -30, 0), "shin.L": (0, 26, 0), "thigh.R": (0, 10, 0)}, loc={"hips": (0.04, 0, -0.08)}))
    sa = merge(scream, P(rot={"head": (0, 0, 6), "chest": (0, 0, 3)})); sb = merge(scream, P(rot={"head": (0, 0, -6), "chest": (0, 0, -3)}))
    return Clip(24, [(0, base, "io"), (5, inhale, "hold"), (7, inhale, "snap"), (9, scream, "io"), (10, sa, "io"), (11, sb, "io"), (12, sa, "io"),
                     (13, sb, "io"), (14, sa, "io"), (15, sb, "io"), (16, scream, "io"), (21, base, "hold")])

# ------------------------------------------------------------------ NOSICIEL (ciezki, krotkie nogi)
def nosiciel_walk(f, n=16):
    p = (f % n) / n
    pose = P()
    for side, ph in (("L", 0.0), ("R", 0.5)):
        c = math.cos(2 * math.pi * (p + ph)); s = math.sin(2 * math.pi * (p + ph))
        pose["rot"]["thigh." + side] = (0, -16 * c, (4 if side == "L" else -4))
        pose["rot"]["shin." + side] = (0, 6 + 22 * max(0.0, -s), 0)
        pose["rot"]["foot." + side] = (0, -0.5 * (-16 * c), 0)
        pose["rot"]["upperarm." + side] = ((22 if side == "L" else -22), 10 * c, 0)
        pose["rot"]["forearm." + side] = (0, -30, 0)
    sway = math.sin(2 * math.pi * p)
    pose["rot"]["hips"] = (8 * sway, 0, 0)                   # kolysanie na boki przy kazdym kroku
    pose["rot"]["spine"] = (-6 * sway, -6, 0)
    pose["rot"]["head"] = (-4 * sway, 10, 0)
    pose["loc"]["hips"] = (0, 0.03 * sway, -0.02 * abs(math.cos(2 * math.pi * p)))
    return pose

def nosiciel_swell(f):
    """0..1: puchnie przed peknieciem (skala brzucha liczona osobno)."""
    k = min(f / 12, 1.0)
    jit = math.sin(f * 2.3) * 4 * k
    return P(rot={"spine": (jit, -14 * k, 0), "head": (0, -30 * k, jit), "neck": (0, -10 * k, 0),
                  "upperarm.L": (40 * k, -20 * k, 0), "upperarm.R": (-40 * k, -20 * k, 0), "forearm.L": (0, -30, 0), "forearm.R": (0, -30, 0),
                  "thigh.L": (0, -10 * k, 6), "thigh.R": (0, -10 * k, -6), "shin.L": (0, 18 * k, 0), "shin.R": (0, 18 * k, 0)}, loc={"hips": (0, 0, -0.06 * k)})
