"""Bron Latarni wg epok. Kazda funkcja buduje bron w ukladzie lokalnym (chwyt w 0, lufa/ostrze w +X, gora +Z)
i zwraca liste obiektow; place() przenosi je w dowolne miejsce (stojak, dlon postaci)."""
import math
from mathutils import Vector as V, Matrix, Euler
from lat3d import mat, box, cyl, loft, ellipsoid

WOOD = lambda: mat("w_wood", (112, 78, 48)); WOOD_D = lambda: mat("w_wood_d", (78, 54, 36)); STEEL = lambda: mat("w_steel", (140, 140, 150))
STEEL_D = lambda: mat("w_steel_d", (64, 64, 74)); RUST = lambda: mat("w_rust", (130, 74, 46)); LEATH = lambda: mat("w_leather", (96, 62, 40))
BRASS = lambda: mat("w_brass", (190, 150, 70)); CLOTH = lambda: mat("w_cloth", (150, 140, 120)); OLIVE = lambda: mat("w_olive", (80, 90, 60))
ROPE = lambda: mat("w_rope", (160, 140, 100)); GLOW = lambda: mat("w_pilot", (120, 190, 255), emit=(100, 170, 255), strength=5)

class W:
    def __init__(self, n): self.n, self.k, self.objs = n, 0, []
    def nm(self): self.k += 1; return "%s_%d" % (self.n, self.k)
    def box(self, c, s, m, rot=(0, 0, 0)): o = box(self.nm(), c, s, m, rot=rot); self.objs.append(o); return o
    def cyl(self, a, b, r, m, r1=None, seg=8): o = cyl(self.nm(), a, b, r, m, r1=r1, seg=seg); self.objs.append(o); return o
    def loft(self, rings, m, seg=8): o = loft(self.nm(), rings, m, seg=seg); self.objs.append(o); return o
    def ell(self, c, s, m): o = ellipsoid(self.nm(), c, s, m); self.objs.append(o); return o

def place(objs, loc, rot=(0, 0, 0), scale=1.0):
    Mx = Matrix.Translation(V(loc)) @ Euler(rot).to_matrix().to_4x4() @ Matrix.Scale(scale, 4)
    for o in objs: o.data.transform(Mx)
    return objs

def noz():
    w = W("noz")
    w.loft([((0.0, 0, 0), 0.016, 0.022), ((0.11, 0, 0), 0.016, 0.022)], WOOD_D())
    w.box((0.115, 0, 0), (0.015, 0.06, 0.03), STEEL_D())
    w.loft([((0.12, 0, 0.004), 0.004, 0.022), ((0.25, 0, 0.006), 0.003, 0.016), ((0.31, 0, 0.012), 0.001, 0.002)], STEEL())
    return w.objs

def dzida():
    w = W("dzida")
    w.cyl((-0.75, 0, 0), (1.45, 0, 0), 0.018, WOOD())
    w.cyl((1.40, 0, 0), (1.47, 0, 0), 0.024, ROPE())
    w.loft([((1.45, 0, 0), 0.012, 0.005), ((1.55, 0, 0), 0.04, 0.008), ((1.72, 0, 0), 0.002, 0.002)], STEEL())
    return w.objs

def wlocznia_tarcza():
    w = W("wlocznia")
    w.cyl((-0.5, 0, 0), (1.15, 0, 0), 0.016, WOOD())
    w.loft([((1.15, 0, 0), 0.01, 0.005), ((1.22, 0, 0), 0.03, 0.007), ((1.34, 0, 0), 0.002, 0.002)], STEEL())
    # tarcza z deski i blachy (osobno, obok)
    w.loft([((-0.05, -0.06, 0.0), 0.32, 0.32), ((-0.05, -0.02, 0.0), 0.32, 0.32)], RUST(), seg=16)
    w.ell((-0.05, -0.065, 0.0), (0.08, 0.04, 0.08), STEEL())
    for k in range(3): w.box((-0.05, -0.065, 0.0), (0.62, 0.01, 0.03), WOOD_D(), rot=(0, k * 1.05, 0))
    return w.objs

def luk():
    w = W("luk")
    pts = [((0.55 * math.sin(a) * 0.0 + 0.10 * (1 - math.cos(a)), 0, 0.62 * math.sin(a)), 0.014, 0.014) for a in [-1.2, -0.8, -0.4, 0, 0.4, 0.8, 1.2]]
    pts = [((p[0][2], p[0][0] * 0 - p[0][0], 0), p[1], p[2]) for p in pts]       # poziomo na stojaku: cieciwa wzdluz x
    w.loft(pts, WOOD(), seg=6)
    a = pts[0][0]; b = pts[-1][0]
    w.cyl(a, b, 0.003, ROPE(), seg=3)
    w.ell((0, -0.02, 0), (0.04, 0.025, 0.025), LEATH())
    w.cyl((-0.3, 0.15, 0), (0.45, 0.15, 0), 0.005, WOOD_D(), seg=4)                 # strzala
    w.loft([((0.45, 0.15, 0), 0.01, 0.003), ((0.5, 0.15, 0), 0.001, 0.001)], STEEL())
    w.box((-0.27, 0.15, 0), (0.07, 0.003, 0.03), CLOTH())
    return w.objs

def mlot():
    w = W("mlot")
    w.cyl((-0.15, 0, 0), (0.85, 0, 0), 0.022, WOOD())
    w.cyl((-0.15, 0, 0), (0.15, 0, 0), 0.026, LEATH())
    w.box((0.88, 0, 0), (0.12, 0.10, 0.24), STEEL_D()); w.box((0.88, 0, 0.14), (0.08, 0.08, 0.05), STEEL())
    w.loft([((0.88, 0, -0.12), 0.04, 0.04), ((0.88, 0, -0.24), 0.005, 0.005)], STEEL_D())
    return w.objs

def kusza():
    w = W("kusza")
    w.box((0.15, 0, 0), (0.75, 0.05, 0.06), WOOD())
    w.box((-0.15, 0, -0.04), (0.25, 0.06, 0.12), WOOD_D())
    for s in (1, -1): w.loft([((0.5, 0, 0.02), 0.012, 0.016), ((0.55, s * 0.22, 0.02), 0.01, 0.012), ((0.5, s * 0.36, 0.02), 0.006, 0.008)], STEEL_D(), seg=6)
    w.cyl((0.5, 0.36, 0.02), (0.18, 0, 0.03), 0.003, ROPE(), seg=3); w.cyl((0.5, -0.36, 0.02), (0.18, 0, 0.03), 0.003, ROPE(), seg=3)
    w.cyl((0.18, 0, 0.045), (0.6, 0, 0.045), 0.006, WOOD_D(), seg=4)
    w.box((0.53, 0, 0.0), (0.05, 0.06, 0.08), STEEL()); w.box((0.0, 0, -0.06), (0.04, 0.02, 0.05), STEEL_D())
    return w.objs

def muszkiet():
    w = W("muszkiet")
    w.loft([((-0.42, 0, -0.04), 0.03, 0.06), ((-0.12, 0, 0.0), 0.022, 0.035), ((0.9, 0, 0.0), 0.02, 0.02)], WOOD())
    w.cyl((-0.05, 0, 0.03), (1.25, 0, 0.03), 0.012, STEEL_D())
    w.box((0.02, -0.03, 0.03), (0.09, 0.02, 0.05), STEEL()); w.box((0.03, -0.035, 0.07), (0.02, 0.01, 0.04), STEEL())        # zamek skalkowy
    for x in (0.4, 0.8): w.cyl((x - 0.01, 0, 0.02), (x + 0.01, 0, 0.02), 0.025, BRASS())
    w.cyl((0.2, 0, -0.02), (1.15, 0, -0.02), 0.004, WOOD_D(), seg=4)                                                       # stempel
    w.box((-0.43, 0, -0.04), (0.03, 0.06, 0.13), BRASS())
    return w.objs

def obrzyn():
    w = W("obrzyn")
    w.loft([((-0.18, 0, -0.06), 0.022, 0.035), ((0.0, 0, 0.0), 0.022, 0.03)], WOOD())
    w.box((0.05, 0, 0.01), (0.12, 0.05, 0.06), STEEL_D())
    for s in (1, -1): w.cyl((0.08, s * 0.013, 0.03), (0.46, s * 0.013, 0.03), 0.013, STEEL_D())
    w.box((0.2, 0, 0.0), (0.2, 0.04, 0.03), WOOD_D())
    for s in (1, -1): w.ell((0.465, s * 0.013, 0.03), (0.003, 0.009, 0.009), mat("w_bore", (20, 18, 22)))
    w.cyl((0.0, 0.0, -0.01), (0.0, 0.0, -0.06), 0.006, STEEL(), seg=4)
    return w.objs

def pistolet():
    w = W("pistolet")
    w.box((0.0, 0, -0.06), (0.05, 0.03, 0.12), WOOD_D(), rot=(0, -0.3, 0))
    w.box((0.05, 0, 0.02), (0.09, 0.035, 0.05), STEEL_D())
    w.cyl((0.03, 0, 0.022), (0.09, 0, 0.022), 0.026, STEEL(), seg=8)                                                       # beben
    w.cyl((0.08, 0, 0.035), (0.26, 0, 0.035), 0.01, STEEL_D(), seg=6)
    w.box((0.25, 0, 0.05), (0.01, 0.005, 0.015), STEEL()); w.cyl((0.0, 0, 0.0), (0.0, 0, -0.03), 0.014, STEEL_D(), seg=6)
    return w.objs

def karabin():
    w = W("karabin")
    w.loft([((-0.42, 0, -0.06), 0.03, 0.065), ((-0.15, 0, -0.01), 0.022, 0.04), ((0.0, 0, 0.0), 0.024, 0.035), ((0.62, 0, 0.01), 0.02, 0.024)], WOOD())
    w.box((0.1, 0, 0.035), (0.26, 0.035, 0.04), STEEL_D()); w.cyl((0.05, -0.03, 0.05), (0.05, -0.07, 0.05), 0.006, STEEL(), seg=4)
    w.ell((0.05, -0.075, 0.05), (0.012, 0.012, 0.012), STEEL())
    w.cyl((0.22, 0, 0.04), (0.98, 0, 0.04), 0.011, STEEL_D())
    w.box((0.1, 0, -0.03), (0.06, 0.03, 0.06), STEEL_D()); w.box((0.95, 0, 0.06), (0.01, 0.004, 0.02), STEEL())
    w.cyl((-0.3, 0.03, -0.03), (0.5, 0.03, 0.0), 0.004, LEATH(), seg=3)
    return w.objs

def automat():
    w = W("automat")
    w.loft([((-0.38, 0, -0.04), 0.028, 0.06), ((-0.08, 0, 0.0), 0.022, 0.035)], WOOD())
    w.box((0.12, 0, 0.02), (0.36, 0.045, 0.07), STEEL_D())
    w.cyl((0.28, 0, 0.03), (0.58, 0, 0.03), 0.028, STEEL_D(), seg=10)                                                      # oslona lufy
    for k in range(5): w.ell((0.32 + 0.055 * k, -0.028, 0.035), (0.012, 0.004, 0.008), mat("w_bore", (20, 18, 22)))
    w.cyl((0.58, 0, 0.03), (0.63, 0, 0.03), 0.009, STEEL())
    w.cyl((0.12, -0.07, -0.08), (0.12, 0.07, -0.08), 0.1, STEEL_D(), seg=14)                                             # beben
    w.box((0.0, 0, -0.05), (0.03, 0.025, 0.06), STEEL())
    return w.objs

def km():
    w = W("km")
    w.box((-0.35, 0, 0.0), (0.3, 0.05, 0.1), WOOD()); w.box((0.05, 0, 0.03), (0.5, 0.09, 0.11), STEEL_D())
    w.cyl((0.3, 0, 0.04), (1.05, 0, 0.04), 0.032, OLIVE(), seg=10); w.cyl((1.05, 0, 0.04), (1.2, 0, 0.04), 0.012, STEEL_D())
    w.cyl((1.18, 0, 0.04), (1.23, 0, 0.04), 0.025, STEEL_D(), seg=8)
    for s in (1, -1): w.cyl((0.95, 0, 0.0), (0.95 + 0.12, s * 0.22, -0.32), 0.012, STEEL_D(), seg=4)                    # dwojnog
    w.box((0.12, 0.1, -0.02), (0.14, 0.1, 0.12), OLIVE())                                                                  # skrzynka
    for k in range(8): w.box((0.05 + 0.03 * k, 0.15 - 0.04 * k, -0.08 - 0.012 * k), (0.02, 0.015, 0.05), BRASS())         # tasma
    w.box((0.2, 0, 0.1), (0.08, 0.02, 0.06), STEEL())
    return w.objs

def miotacz():
    w = W("miotacz")
    for s in (1, -1): w.cyl((-0.6, s * 0.12, -0.25), (-0.6, s * 0.12, 0.35), 0.1, RUST(), seg=12); w.ell((-0.6, s * 0.12, 0.35), (0.1, 0.1, 0.05), RUST())
    w.cyl((-0.6, 0, 0.1), (-0.6, 0, 0.3), 0.06, STEEL_D(), seg=10)
    w.loft([((-0.6, 0.0, -0.25), 0.02, 0.02), ((-0.35, 0.05, -0.35), 0.02, 0.02), ((-0.05, 0.0, -0.05), 0.02, 0.02)], mat("w_hose", (40, 38, 40)), seg=6)
    w.cyl((-0.05, 0, 0.0), (0.65, 0, 0.02), 0.02, STEEL_D(), seg=8); w.cyl((0.6, 0, 0.02), (0.72, 0, 0.02), 0.032, STEEL(), r1=0.02, seg=8)
    w.box((0.05, 0, -0.06), (0.04, 0.03, 0.1), WOOD_D()); w.box((0.35, 0, -0.06), (0.04, 0.03, 0.09), WOOD_D())
    w.ell((0.73, 0, 0.0), (0.012, 0.012, 0.012), GLOW())
    return w.objs

ARSENAL = [("Nóż", "Złom", noz), ("Dzida", "Złom", dzida), ("Włócznia i tarcza", "Złom", wlocznia_tarcza), ("Łuk", "Złom", luk),
           ("Młot", "Kuźnia", mlot), ("Kusza", "Kuźnia", kusza), ("Muszkiet", "Czarny proch", muszkiet), ("Obrzyn", "Czarny proch", obrzyn),
           ("Rewolwer", "Nabój", pistolet), ("Karabin", "Nabój", karabin), ("Pistolet maszynowy", "Silnik", automat),
           ("Karabin maszynowy", "Silnik", km), ("Miotacz ognia", "Silnik", miotacz)]
