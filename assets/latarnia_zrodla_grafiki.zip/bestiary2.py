"""Plansze nowych wrogow. python3 bestiary2.py -- zwierzeta|stworzenia|ludzie SAMPLES"""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import chars, anim as A, anim_mut as AM, mutants2 as M2
args = sys.argv[sys.argv.index("--") + 1:]
MODE, SAMP = args[0], int(args[1])
reset(); setup_render(samples=SAMP)
world((40, 36, 58), 0.5)
box("ground", (0, 0, -0.05), (40, 20, 0.1), mat("ground", (62, 58, 66), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
    (0.0, (58, 55, 62)), (0.45, (62, 58, 66)), (0.66, (66, 62, 66)), (0.82, (60, 62, 58))])), pass_index=1)
CAMYAW = -25
cy = math.radians(CAMYAW); RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
def at(c, r=0.0): return RIGHT * c + FWD * r
anim = []   # (rig, fn, loc, yaw)
if MODE == "zwierzeta":
    W = 13.0; NF = 8
    for i, (kind, c, r) in enumerate((("pies", -4.6, 0), ("wilk", -1.6, 0.6), ("wilk", -1.0, -0.7), ("wilk", -2.3, -0.2), ("dzik", 1.6, 0), ("jelen", 4.6, 0))):
        rig = M2.quadruped("q%d" % i, kind)
        anim.append((rig, (lambda f, i=i: AM.ogar_gallop(f + i * 3, 8)), at(c, r), CAMYAW - 20))
    LABELS = [("Ogar (pies)", -4.6), ("Wataha (wilki)", -1.6), ("Ryjec (dzik)", 1.6), ("Rogacz (jeleń)", 4.6)]
elif MODE == "stworzenia":
    W = 17.0; NF = 1
    M2.zwiewnik("zw", at(-7.0)); M2.nici("ni", at(-4.3)); M2.klebowisko("kl", at(-1.4)); M2.oddech("od", at(1.6)); M2.gasiciel("ga", at(4.2)); M2.siewca("si", at(7.0))
    LABELS = [("Zwiewnik", -7.0), ("Nici", -4.3), ("Kłębowisko", -1.4), ("Oddech", 1.6), ("Gasiciel", 4.2), ("Siewca", 7.0)]
else:
    W = 12.0; NF = 8
    b = M2.biegacz("bg"); anim.append((b, lambda f: A.merge(A.run(f, 8, stride=46), A.P(rot={"spine": (0, 14, 0), "upperarm.L": (20, 30, 0), "upperarm.R": (-20, 30, 0)})), at(-4.2), CAMYAW - 30))
    w = M2.wydrazony("wd"); anim.append((w, lambda f: A.merge(A.stance(), A.low_ready(), A.P(rot={"head": (8 * math.sin(f), 0, 14 * math.sin(f * 0.7)), "spine": (0, 0, 4 * math.sin(f * 1.3))})), at(-1.4), CAMYAW - 50))
    fl = M2.falszywy_latarnik("fl"); anim.append((fl, lambda f: A.merge(A.stance(), A.P(rot={"upperarm.L": (10, -20, 0), "forearm.L": (0, -30, 0), "upperarm.R": (-10, -50 - 8 * math.sin(f), 0), "head": (0, 10, 12)})), at(1.4), CAMYAW - 60))
    M2.kokon("ko", at(4.2))
    LABELS = [("Biegacz", -4.2), ("Wydrążony", -1.4), ("Fałszywy Latarnik", 1.4), ("Kokon", 4.2)]
sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.88, 0.72), 3.0)
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.72, 0.78, 1.0), 1.4)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
camera(V((0, 0, 1.0)), 50, W, (int(W * 70), 300), yaw_deg=CAMYAW)
import json
json.dump(dict(labels=LABELS, W=W, nf=NF), open("/home/claude/latarnia3d/out/b2_%s.json" % MODE, "w"))
for f in range(NF):
    for r, fn, loc, yaw in anim: A.apply(r, fn(f), tuple(loc), yaw)
    render("/home/claude/latarnia3d/out/b2_%s_%02d.exr" % (MODE, f))
