import sys; sys.path.insert(0, '/home/claude/latarnia3d')
from make_seq import build
labs = [("1", -6.4, 3.2, -24), ("2", -6.8, 0.2, 14), ("3", -2.0, 0.2, 14), ("4", -5.8, -2.3, 14), ("5", -0.2, -2.3, 14), ("6", -6.4, 1.8, -24)]
leg = ["1 — Ogary w galopie (galop obrotowy, praca kręgosłupa i ogona)", "2 — Skok Ogara: przyczajenie, wybicie, lot, zagryzienie i szarpanie; strzelec pada",
       "3 — Szarża Ogara przerwana strzałem: przewrót na bok, drgawki", "4 — Krzykacz: wdech, krzyk z falą dźwięku, pobliski człowiek się kuli",
       "5 — Nosiciel: ciężki chód, puchnie i pęka (gaz, szczątki)", "6 — Krzykacz w pokracznym biegu"]
fr = build("mut", 48, 640, 400, 13.0, 0.5, labs, "out/latarnia3d_mutanty.gif", legend=leg)
for i in (12, 30, 38): fr[i].save("out/mut_k%02d.png" % i)
