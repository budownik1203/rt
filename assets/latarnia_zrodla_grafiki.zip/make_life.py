import sys, math
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
W, H, ORT, T = 640, 320, 17.0, math.radians(50)
R1 = ["Rewolwer", "Nóż", "Łuk", "Sztandar w marszu", "Wartownik"]
R2 = ["Kowal", "Noszenie skrzyni", "Kopanie", "Gotowanie", "Kłótnia", "Przy ognisku"]
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 13)
def label(im):
    d = ImageDraw.Draw(im)
    for row, names, sp, yy in ((0, R1, 2.8, 1.9), (1, R2, 2.5, -1.9)):
        n = len(names)
        for ci, nm in enumerate(names):
            x = (ci - (n - 1) / 2) * sp
            px = (W / 2 + x * W / ORT) * 2; py = (H / 2 - (yy * math.cos(T) - 0.7 * math.sin(T)) * W / ORT) * 2 + 22
            w = d.textlength(nm, font=font)
            d.rectangle((px - w / 2 - 4, py - 2, px + w / 2 + 4, py + 15), fill=(20, 17, 28)); d.text((px - w / 2, py - 1), nm, font=font, fill=(226, 200, 150))
    return im
fr = [label(stylize('out/life_%02d.exr' % f).resize((W * 2, H * 2), Image.NEAREST)) for f in range(24)]
fr[0].save('out/latarnia3d_osada_i_bron.gif', save_all=True, append_images=fr[1:], duration=83, loop=0)
fr[12].save('out/lifechk.png')
