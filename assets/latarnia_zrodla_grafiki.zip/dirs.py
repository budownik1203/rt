"""Pokaz: 8 kierunkow chodu (cywil) + strzelec w 8 kierunkach w gotowosci, zblizenie."""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *

F = int(sys.argv[sys.argv.index("--") + 1]) if "--" in sys.argv else 0
reset(); setup_render(samples=20)
world((30, 26, 48), 0.3)
g = mat("ground", (60, 56, 66), pass_index=1, noise=dict(scale=2.4, detail=5.0, stops=[(0.0, (58, 54, 64)), (0.5, (61, 57, 67)), (0.7, (64, 59, 60))]))
box("ground", (0, 0, -0.05), (40, 20, 0.1), g, pass_index=1)
point_light("lamp", (-4, 0.5, 7.5), (1.0, 0.75, 0.45), 4200, 0.1); point_light("lamp2", (4, 0.5, 7.5), (1.0, 0.75, 0.45), 4200, 0.1)
fill = sun("charfill", (math.radians(62), 0, math.radians(-32 + 200)), (1.0, 0.9, 0.78), 0.9)
fill.light_linking.receiver_collection = char_collection()
for i in range(8):
    yaw = i * 45
    w = human("w%d" % i, dict(jacket="brown", pants="brown", beard=True, strap=False), "idle")
    walk_pose(w, F); w.place((-6.3 + i * 1.8, 1.9, 0), yaw)
    s = human("s%d" % i, dict(jacket="olive", pants="olive", helmet="mil"), "rifle")
    walk_pose(s, F, arms=False); s.place((-6.3 + i * 1.8, -1.3, 0), yaw)
camera((0, 0.3, 0.9), 52, 16, (480, 200), yaw_deg=0)
render("/home/claude/latarnia3d/out/dirs_%02d.exr" % F)
