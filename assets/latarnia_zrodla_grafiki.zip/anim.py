"""System animacji Latarni: pozy jako slowniki, klatki kluczowe z krzywymi (wolny start/koniec, szybki atak),
cykle chodu i biegu generowane proceduralnie, akcje bojowe z antycypacja, uderzeniem i powrotem."""
import math
from mathutils import Vector as V, Matrix

# ------------------------------------------------------------------ krzywe
def ease(t, kind):
    if kind == "lin": return t
    if kind == "hold": return 0.0
    if kind == "in": return t ** 3                      # przyspieszenie (zamach w dol, upadek)
    if kind == "out": return 1 - (1 - t) ** 3           # szybki start, wyhamowanie (uderzenie, odrzut)
    if kind == "snap": return 1 - (1 - t) ** 5
    return t * t * (3 - 2 * t)                          # io: wolny start i koniec

# ------------------------------------------------------------------ poza
def P(rot=None, loc=None, tgt=None, ik=None, root=None, vis=None, scl=None):
    r = tuple(root or (0, 0, 0, 0)); r = r + (0,) * (5 - len(r))      # (dx, dy, dz, pochylenie, przechyl)
    return dict(rot=rot or {}, loc=loc or {}, tgt=tgt or {}, ik=ik or {}, root=r, vis=vis or {}, scl=scl or {})

def merge(*poses):
    out = P()
    for p in poses:
        for k in ("rot", "loc", "tgt", "ik", "vis", "scl"):
            for kk, vv in p.get(k, {}).items():
                if k in ("rot", "loc", "tgt") and kk in out[k]:
                    out[k][kk] = tuple(a + b for a, b in zip(out[k][kk], vv))
                else:
                    out[k][kk] = vv
        out["root"] = tuple(a + b for a, b in zip(out["root"], p["root"]))
    return out

def lerp_pose(a, b, t):
    out = P()
    for k in ("rot", "loc", "tgt"):
        keys = set(a[k]) | set(b[k])
        for kk in keys:
            va = a[k].get(kk, (0, 0, 0)); vb = b[k].get(kk, (0, 0, 0))
            out[k][kk] = tuple(x + (y - x) * t for x, y in zip(va, vb))
    for kk in set(a.get("scl", {})) | set(b.get("scl", {})):
        va = a.get("scl", {}).get(kk, 1.0); vb = b.get("scl", {}).get(kk, 1.0); out["scl"][kk] = va + (vb - va) * t
    for kk in set(a["ik"]) | set(b["ik"]):
        va = a["ik"].get(kk, 1.0); vb = b["ik"].get(kk, 1.0); out["ik"][kk] = va + (vb - va) * t
    out["root"] = tuple(x + (y - x) * t for x, y in zip(a["root"], b["root"]))
    out["vis"] = dict(a["vis"]); out["vis"].update(b["vis"] if t >= 0.999 else {})
    if t > 0.001 and "flash" in out["vis"] and out["vis"]["flash"] and not (t >= 0.999 and b["vis"].get("flash")): out["vis"].pop("flash")
    return out

class Clip:
    """keys: lista (klatka, poza, krzywa_do_nastepnej)."""
    def __init__(self, length, keys, loop=True):
        self.length, self.keys, self.loop = length, sorted(keys, key=lambda k: k[0]), loop
    def sample(self, f):
        f = f % self.length if self.loop else min(f, self.length)
        ks = self.keys
        for i in range(len(ks)):
            f0, p0, e0 = ks[i]
            f1, p1 = (ks[i + 1][0], ks[i + 1][1]) if i + 1 < len(ks) else (self.length, ks[0][1] if self.loop else p0)
            if f0 <= f < f1 or i == len(ks) - 1:
                t = 0 if f1 == f0 else min(max((f - f0) / (f1 - f0), 0), 1)
                return lerp_pose(p0, p1, ease(t, e0))
        return ks[0][1]

# ------------------------------------------------------------------ zastosowanie pozy do szkieletu
def apply(rig, pose, base_loc, yaw_deg):
    rig.reset_pose()
    for bone, (rx, ry, rz) in pose["rot"].items():
        if bone not in rig.ob.pose.bones: continue
        if rx: rig.rot(bone, (1, 0, 0), rx)
        if ry: rig.rot(bone, (0, 1, 0), ry)
        if rz: rig.rot(bone, (0, 0, 1), rz)
    for bone, d in pose["loc"].items():
        if bone not in rig.ob.pose.bones: continue
        R = rig.ob.data.bones[bone].matrix_local.to_3x3()
        rig.ob.pose.bones[bone].location = R.inverted() @ V(d)
    for name, e in getattr(rig, "tg", {}).items():
        e.location = rig.tg_base[name] + V(pose["tgt"].get(name, (0, 0, 0)))
    for bone, infl in pose["ik"].items():
        pb = rig.ob.pose.bones[bone]
        for c in pb.constraints:
            if c.type == "IK": c.influence = infl
    dx, dy, dz, pitch, roll = (tuple(pose["root"]) + (0,) * 5)[:5]
    yaw = math.radians(yaw_deg)
    off = V((dx * math.cos(yaw) - dy * math.sin(yaw), dx * math.sin(yaw) + dy * math.cos(yaw), dz))
    rig.ob.location = V(base_loc) + off
    rig.ob.rotation_euler = (math.radians(roll), math.radians(pitch), yaw)
    for key, sc in pose.get("scl", {}).items():
        if key in getattr(rig, "objs", {}): rig.objs[key].scale = (sc, sc, sc)
    for key in ("flash", "flash2"):                      # blysk zawsze gasnie, chyba ze poza go wlacza
        if key in getattr(rig, "objs", {}) and key not in pose["vis"]: rig.objs[key].hide_render = True
    for key, on in pose["vis"].items():
        if key in getattr(rig, "objs", {}): rig.objs[key].hide_render = not on

# ------------------------------------------------------------------ pozy bazowe
def stance():
    return P(rot={"thigh.L": (0, -7, 0), "shin.L": (0, 6, 0), "foot.L": (0, 1, 0),
                  "thigh.R": (0, 9, 0), "shin.R": (0, 4, 0), "foot.R": (0, -12, 0)})

def arms_down():
    return P(rot={"upperarm.L": (6, 0, 0), "upperarm.R": (-6, 0, 0), "forearm.L": (0, -12, 0), "forearm.R": (0, -12, 0)})

def breathe(f, n):
    s = math.sin(2 * math.pi * f / n)
    return P(rot={"chest": (0, 1.2 * s, 0), "neck": (0, -0.8 * s, 0)}, loc={"hips": (0, 0, 0.004 * s)})

# ------------------------------------------------------------------ cykle
def walk(f, n=12, stride=27, arms=True):
    p = (f % n) / n
    pose = P()
    for side, ph in (("L", 0.0), ("R", 0.5)):
        c = math.cos(2 * math.pi * (p + ph)); sn = math.sin(2 * math.pi * (p + ph))
        sw = -stride * c
        knee = 5 + 40 * max(0.0, -sn)
        pose["rot"]["thigh." + side] = (0, sw, 0)
        pose["rot"]["shin." + side] = (0, knee, 0)
        pose["rot"]["foot." + side] = (0, -0.55 * (sw + knee) + 3, 0)
        if arms:
            pose["rot"]["upperarm." + side] = ((6 if side == "L" else -6), 0.62 * stride * c, 0)
            pose["rot"]["forearm." + side] = (0, -12 - 10 * max(0.0, -c), 0)
    bob = 0.034 * (1 - abs(math.cos(2 * math.pi * p))) - 0.020
    pose["loc"]["hips"] = (0, 0, bob)
    tw = 5 * math.cos(2 * math.pi * p)
    pose["rot"]["hips"] = (0, 0, -tw)                       # miednica skreca z noga
    pose["rot"]["spine"] = (0, 3 + 2 * abs(math.sin(2 * math.pi * p)), 0)
    pose["rot"]["chest"] = (0, 2, tw * 1.4)                 # klatka przeciwnie (kontrrotacja)
    pose["rot"]["head"] = (0, -0.8 * math.sin(4 * math.pi * p), -tw * 0.8)   # glowa stabilizuje sie (opoznienie)
    return pose

def run(f, n=10, stride=42, arms=True):
    """Bieg: kontakt -> ugiecie -> wybicie -> faza lotu; pochylenie, mocna praca rak."""
    p = (f % n) / n
    pose = P()
    for side, ph in (("L", 0.0), ("R", 0.5)):
        q = (p + ph) % 1.0
        c = math.cos(2 * math.pi * q); sn = math.sin(2 * math.pi * q)
        sw = -stride * c - 6
        knee = 12 + 85 * max(0.0, -sn) + 18 * max(0.0, sn) * (q < 0.25)
        pose["rot"]["thigh." + side] = (0, sw, 0)
        pose["rot"]["shin." + side] = (0, knee, 0)
        pose["rot"]["foot." + side] = (0, -0.45 * (sw + knee) + (18 if 0.35 < q < 0.55 else 0), 0)
        if arms:
            pose["rot"]["upperarm." + side] = ((10 if side == "L" else -10), 0.85 * stride * c, 0)
            pose["rot"]["forearm." + side] = (0, -78 - 10 * c, 0)
    # wysokosc bioder: dol przy kontakcie, gora w fazie lotu (dwa razy na cykl)
    hb = 0.055 * max(0.0, math.sin(4 * math.pi * p - 1.0)) - 0.035
    pose["loc"]["hips"] = (0, 0, hb)
    tw = 8 * math.cos(2 * math.pi * p)
    pose["rot"]["hips"] = (0, 0, -tw)
    pose["rot"]["spine"] = (0, 18, 0)                        # pochylenie do przodu
    pose["rot"]["chest"] = (0, 4, tw * 1.5)
    pose["rot"]["head"] = (0, -14, -tw)
    return pose

def run_rifle(f, n=10):
    base = run(f, n, stride=36, arms=False)
    p = (f % n) / n
    base["rot"]["weapon"] = (8, 18, 0)                       # bron nisko przy biegu
    base["loc"]["weapon"] = (-0.02, 0.03, -0.06 + 0.012 * math.sin(4 * math.pi * p))
    return base

# ------------------------------------------------------------------ akcje bojowe (24 klatki = 2 s przy 12 kl/s)
def low_ready(): return P(rot={"weapon": (0, 10, 0), "head": (0, 4, 0)}, loc={"weapon": (0, 0, -0.03)})
def aim(): return P(rot={"weapon": (0, -7, 0), "head": (0, 18, 4), "neck": (0, 6, 0), "chest": (0, -3, 4), "spine": (0, 3, 0)}, loc={"weapon": (-0.06, 0.03, 0.12)})
def recoil(): return P(rot={"weapon": (0, -13, 0), "head": (0, 8, 4), "neck": (0, 3, 0), "chest": (0, -9, 6), "spine": (0, -3, 0)},
                       loc={"weapon": (-0.14, 0.03, 0.15), "hips": (-0.025, 0, 0)}, vis={"flash": 1})
def wide():   # szersza postawa strzelecka: lewa noga z przodu
    return P(rot={"thigh.L": (0, -14, 0), "shin.L": (0, 10, 0), "foot.L": (0, 3, 0), "thigh.R": (0, 14, 0), "shin.R": (0, 6, 0), "foot.R": (0, -18, 0)}, loc={"hips": (0, 0, -0.03)})

def clip_shoot(S=None):
    S = S or wide()
    k = lambda *ps: merge(S, *ps)
    return Clip(24, [
        (0, k(low_ready()), "io"),
        (5, k(aim()), "hold"),
        (8, k(aim(), P(vis={"flash": 0})), "snap"),
        (9, k(recoil()), "out"),
        (10, k(recoil(), P(vis={"flash": 0})), "io"),
        (13, k(aim()), "hold"),
        (14, k(aim()), "snap"),
        (15, k(recoil()), "out"),
        (16, k(recoil(), P(vis={"flash": 0})), "io"),
        (19, k(aim()), "io"),
        (22, k(low_ready()), "hold"),
    ])

def clip_reload():
    S = wide()
    k = lambda *ps: merge(S, *ps)
    tilt = P(rot={"weapon": (40, -38, 0), "head": (0, 30, 0), "neck": (0, 10, 0), "chest": (0, 8, 0)}, loc={"weapon": (-0.12, 0.08, 0.0)})
    M0 = (-0.20, -0.01, -0.03)
    return Clip(24, [
        (0, k(low_ready()), "io"),
        (3, k(tilt), "io"),
        (5, k(tilt, P(tgt={"ikL": M0})), "out"),                                                     # dlon na magazynek
        (7, k(tilt, P(tgt={"ikL": (-0.20, 0.02, -0.18)}, vis={"mag": 0, "maghand": 1})), "snap"),    # wyrwanie
        (8, k(tilt, P(tgt={"ikL": (-0.26, 0.20, -0.30)}, vis={"mag": 0, "maghand": 1})), "io"),      # wyrzut w bok
        (9, k(tilt, P(tgt={"ikL": (-0.30, 0.22, -0.34)}, vis={"mag": 0, "maghand": 0})), "io"),
        (11, k(tilt, P(tgt={"ikL": (-0.40, 0.24, -0.44)}, vis={"mag": 0, "maghand": 0})), "io"),     # do ladownicy
        (13, k(tilt, P(tgt={"ikL": (-0.40, 0.24, -0.44)}, vis={"mag": 0, "maghand": 1})), "io"),     # nowy magazynek
        (15, k(tilt, P(tgt={"ikL": (-0.20, 0.00, -0.14)}, vis={"mag": 0, "maghand": 1})), "out"),
        (17, k(tilt, P(tgt={"ikL": M0}, vis={"mag": 1, "maghand": 0})), "snap"),                     # wcisniecie
        (18, k(tilt, P(rot={"weapon": (0, 4, 0)}, tgt={"ikL": (-0.20, -0.01, 0.01)})), "io"),        # klepniecie
        (20, k(tilt, P(rot={"weapon": (-15, 10, 0)})), "io"),                                       # sprawdzenie
        (23, k(low_ready()), "hold"),
    ])

def crouch(depth=1.0):
    d = depth
    return P(rot={"thigh.L": (0, -78 * d, 0), "shin.L": (0, 105 * d, 0), "foot.L": (0, -28 * d, 0),
                  "thigh.R": (0, -45 * d, 8), "shin.R": (0, 118 * d, 0), "foot.R": (0, -60 * d, 0),
                  "spine": (0, 18 * d, 0), "chest": (0, 8 * d, 0)},
             loc={"hips": (-0.06 * d, 0, -0.44 * d)})

def clip_cover():
    lr = low_ready()
    hide = merge(crouch(1.0), lr, P(rot={"spine": (0, 14, 0), "neck": (0, 10, 0), "head": (0, 14, 0)}, loc={"hips": (0, 0, -0.05)}))
    peek = merge(crouch(0.45), aim())
    peek_r = merge(crouch(0.45), recoil())
    return Clip(24, [
        (0, hide, "io"),
        (5, hide, "out"),
        (8, peek, "hold"),
        (10, peek, "snap"), (11, peek_r, "out"), (12, merge(peek_r, P(vis={"flash": 0})), "io"),
        (15, peek, "snap"), (16, peek_r, "out"), (17, merge(peek_r, P(vis={"flash": 0})), "io"),
        (19, peek, "in"),
        (21, hide, "hold"),
    ])

def clip_spear():
    guard = merge(stance(), P(rot={"weapon": (0, 82, 0), "shield": (0, 0, 0), "chest": (0, 2, -6)},
                              loc={"weapon": (0.0, 0.0, 0.22), "shield": (0.02, 0, 0.08)}))
    wind = merge(guard, P(rot={"weapon": (0, 7, 0), "chest": (0, -4, 14), "spine": (0, -3, 4), "thigh.R": (0, 6, 0), "shin.R": (0, 10, 0)},
                         loc={"weapon": (-0.28, 0.02, 0.02), "hips": (-0.05, 0, -0.03)}))
    thrust = merge(stance(), P(rot={"weapon": (0, 64, 0), "chest": (0, 10, -18), "spine": (0, 6, -6),
                                    "thigh.L": (0, -32, 0), "shin.L": (0, 30, 0), "foot.L": (0, 6, 0), "thigh.R": (0, 26, 0), "shin.R": (0, 6, 0)},
                               loc={"weapon": (0.50, 0.0, 0.18), "shield": (0.06, 0, 0.05), "hips": (0.12, 0, -0.08)}, root=(0.22, 0, 0, 0)))
    return Clip(24, [
        (0, guard, "io"), (5, wind, "hold"), (7, wind, "snap"), (9, thrust, "hold"), (11, thrust, "io"), (19, guard, "hold")])

def clip_hammer():
    ready = stance()
    wind = merge(stance(), P(rot={"weapon": (0, -55, 0), "spine": (0, -12, 0), "chest": (0, -6, 10), "head": (0, -6, 0), "foot.R": (0, 10, 0)},
                             loc={"weapon": (-0.06, 0, 0.12), "hips": (-0.04, 0, 0.02)}))
    strike = merge(stance(), P(rot={"weapon": (0, 118, 0), "spine": (0, 22, 0), "chest": (0, 14, -14), "head": (0, 10, 0),
                                    "thigh.L": (0, -34, 0), "shin.L": (0, 40, 0), "thigh.R": (0, 22, 0), "shin.R": (0, 20, 0)},
                               loc={"weapon": (0.20, 0, -0.10), "hips": (0.10, 0, -0.10)}, root=(0.16, 0, 0, 0)))
    return Clip(24, [
        (0, ready, "io"), (6, wind, "hold"), (8, wind, "in"), (10, strike, "hold"), (13, strike, "io"), (20, ready, "hold")])

def clip_grenade():
    base = merge(stance(), arms_down())
    wind = merge(stance(), P(rot={"upperarm.R": (-90, 0, -35), "forearm.R": (-90, 0, 0), "upperarm.L": (10, -75, 0), "forearm.L": (0, -20, 0),
                                  "chest": (0, -8, -30), "spine": (0, -6, -10), "head": (0, -4, 30), "thigh.R": (0, 10, 0), "shin.R": (0, 14, 0)},
                             loc={"hips": (-0.06, 0, -0.03)}, ik={}))
    throw = merge(stance(), P(rot={"upperarm.R": (-10, -150, 0), "forearm.R": (0, -10, 0), "upperarm.L": (8, 30, 0), "forearm.L": (0, -30, 0),
                                   "chest": (0, 14, 26), "spine": (0, 10, 10), "head": (0, 6, -24), "thigh.L": (0, -26, 0), "shin.L": (0, 22, 0), "thigh.R": (0, 20, 0)},
                              loc={"hips": (0.10, 0, -0.05)}, vis={"gren": 0}))
    follow = merge(stance(), P(rot={"upperarm.R": (20, -40, 0), "forearm.R": (0, -20, 0), "chest": (0, 16, 22), "spine": (0, 12, 8), "head": (0, 4, -20),
                                    "thigh.L": (0, -24, 0), "shin.L": (0, 20, 0), "thigh.R": (0, 18, 0)},
                               loc={"hips": (0.10, 0, -0.07)}, vis={"gren": 0}))
    duck_g = merge(crouch(0.55), P(rot={"head": (0, 22, 0), "upperarm.R": (-10, -50, 0), "forearm.R": (0, -100, 0), "upperarm.L": (10, -40, 0), "forearm.L": (0, -90, 0)}, vis={"gren": 0}))
    return Clip(24, [
        (0, merge(base, P(vis={"gren": 1})), "io"), (6, merge(wind, P(vis={"gren": 1})), "hold"), (7, merge(wind, P(vis={"gren": 1})), "snap"),
        (9, throw, "out"), (12, follow, "io"), (14, duck_g, "hold"), (18, duck_g, "io"), (22, merge(base, P(vis={"gren": 0})), "hold"), (23, merge(base, P(vis={"gren": 1})), "hold")])

def clip_death():
    base = merge(stance(), arms_down())
    hit = merge(base, P(rot={"spine": (0, -16, 6), "chest": (0, -12, 8), "head": (0, -22, 10), "upperarm.L": (20, -40, 0), "upperarm.R": (-25, -30, 0),
                             "forearm.L": (0, -40, 0), "forearm.R": (0, -30, 0), "thigh.R": (0, 24, 0), "shin.R": (0, 12, 0)}, loc={"hips": (-0.06, 0, 0)}, root=(-0.12, 0, 0, 0)))
    buckle = merge(base, P(rot={"spine": (0, 8, 0), "chest": (0, 6, -4), "head": (0, 14, 0), "thigh.L": (0, -30, 0), "shin.L": (0, 60, 0),
                                "thigh.R": (0, -10, 0), "shin.R": (0, 70, 0), "upperarm.L": (14, 10, 0), "upperarm.R": (-14, 8, 0)},
                       loc={"hips": (-0.04, 0, -0.22)}, root=(-0.15, 0, 0, 0)))
    fall = merge(base, P(rot={"spine": (0, -10, 0), "head": (0, -20, 0), "upperarm.L": (40, -20, 0), "upperarm.R": (-40, -25, 0),
                              "thigh.L": (0, -40, 0), "shin.L": (0, 50, 0), "thigh.R": (0, -20, 0), "shin.R": (0, 30, 0)},
                     loc={"hips": (0, 0, -0.10)}, root=(-0.15, 0, 0.0, -84)))
    lie = merge(base, P(rot={"spine": (0, -4, 0), "head": (0, -10, 12), "upperarm.L": (60, -30, 0), "upperarm.R": (-55, -40, 0),
                             "forearm.L": (0, -30, 0), "thigh.L": (0, -30, 0), "shin.L": (0, 40, 0), "thigh.R": (0, -10, 0), "shin.R": (0, 10, 0)},
                    loc={"hips": (0, 0, -0.10)}, root=(-0.15, 0, 0.0, -89)))
    drop = P(rot={"weapon": (0, 90, 0)}, loc={"weapon": (-0.18, -0.30, 0.0)}, ik={"forearm.L": 0.0, "forearm.R": 0.0})   # bron wypada z rak
    fall = merge(fall, drop); lie = merge(lie, drop)
    bounce = merge(lie, P(root=(0, 0, 0.0, 6)))
    return Clip(24, [(0, base, "snap"), (2, hit, "io"), (5, hit, "io"), (8, buckle, "in"), (12, fall, "out"), (13, bounce, "io"), (15, lie, "hold"), (23, lie, "hold")], loop=True)


# ================================================================== reakcje i przejscia
def kneel():
    return P(rot={"thigh.L": (0, -82, 0), "shin.L": (0, 84, 0), "foot.L": (0, 0, 0),
                  "thigh.R": (0, 4, 6), "shin.R": (0, 92, 0), "foot.R": (0, -32, 0), "spine": (0, 4, 0)},
             loc={"hips": (-0.04, 0, -0.46)})

def flinch():
    """Reakcja na ostrzal: skulenie, glowa w dol, barki w gore."""
    return P(rot={"spine": (0, 14, 0), "chest": (0, 10, 0), "neck": (0, 16, 0), "head": (0, 12, 0),
                  "thigh.L": (0, -24, 0), "shin.L": (0, 40, 0), "thigh.R": (0, -8, 0), "shin.R": (0, 46, 0), "foot.R": (0, -20, 0),
                  "weapon": (0, 20, 0)}, loc={"hips": (-0.04, 0, -0.16), "weapon": (0, 0, -0.04)})

def prone():
    return P(rot={"neck": (0, -38, 0), "head": (0, -30, 0), "spine": (0, -6, 0), "chest": (0, -6, 0),
                  "thigh.L": (0, 0, 0), "shin.L": (0, 8, 0), "foot.L": (0, 40, 0), "thigh.R": (0, 4, 0), "shin.R": (0, 10, 0), "foot.R": (0, 40, 0),
                  "weapon": (0, -88, 0)},
             loc={"weapon": (-0.40, 0.0, 0.30)}, root=(0, 0, 0.16, 88))

def crawl(f, n=16):
    p = (f % n) / n; c = math.cos(2 * math.pi * p)
    base = prone()
    base["rot"]["thigh.L"] = (12 + 12 * c, -22 - 22 * c, 0); base["shin.L"] = None
    base["rot"]["shin.L"] = (0, 40 + 40 * c, 0)
    base["rot"]["thigh.R"] = (-12 + 12 * c, -22 + 22 * c, 0)
    base["rot"]["shin.R"] = (0, 40 - 40 * c, 0)
    base["rot"]["chest"] = (0, -6, 5 * c); base["rot"]["hips"] = (0, 0, -4 * c)
    base["loc"]["weapon"] = (-0.40, 0.0, 0.30 + 0.06 * c)
    base.pop("shin.L", None)
    return base

def stagger(f):
    """Trafienie, ale nie smierc: szarpniecie, krok w tyl, powrot do pozycji."""
    hit = P(rot={"spine": (0, -14, 8), "chest": (0, -10, 10), "head": (0, -18, 8), "weapon": (0, 22, 10),
                 "thigh.R": (0, 26, 0), "shin.R": (0, 14, 0)}, loc={"hips": (-0.05, 0, -0.02)}, root=(-0.10, 0, 0, 0))
    hunch = P(rot={"spine": (0, 18, -4), "chest": (0, 8, 0), "head": (0, 10, 0), "weapon": (0, 30, 0),
                   "thigh.L": (0, -20, 0), "shin.L": (0, 30, 0), "thigh.R": (0, 10, 0), "shin.R": (0, 36, 0)}, loc={"hips": (-0.03, 0, -0.12)}, root=(-0.18, 0, 0, 0))
    c = Clip(14, [(0, P(), "snap"), (2, hit, "io"), (5, hunch, "io"), (9, merge(hunch, P(root=(0.02, 0, 0, 0))), "io"), (13, P(root=(-0.18, 0, 0, 0)), "hold")], loop=False)
    return c.sample(f)

def dive_mid():
    return P(rot={"thigh.L": (0, -40, 0), "shin.L": (0, 60, 0), "thigh.R": (0, 30, 0), "shin.R": (0, 20, 0), "spine": (0, 20, 0),
                  "neck": (0, -20, 0), "head": (0, -20, 0), "weapon": (0, -40, 0)}, loc={"hips": (0, 0, -0.10), "weapon": (-0.20, 0, 0.15)}, root=(0, 0, 0.30, 45))

class Seq:
    """Sekwencja segmentow (klatka_startu, funkcja_pozy(f_lokalna), predkosc_m_na_klatke, klatki_przejscia).
    Przejscia: plynne mieszanie poprzedniej i nowej pozy, predkosc tez sie miesza, wiec stopy nie slizgaja sie."""
    def __init__(self, segs): self.segs = segs
    def _at(self, f):
        i = max(k for k, s in enumerate(self.segs) if s[0] <= f)
        f0, fn, v, fade = self.segs[i]
        pose = fn(f - f0); w = 1.0
        if i > 0 and f - f0 < fade:
            pf0, pfn, pv, _ = self.segs[i - 1]
            w = ease((f - f0) / fade, "io")
            pose = lerp_pose(pfn(f - pf0), pose, w); v = pv + (v - pv) * w
        return pose, v
    def sample(self, f):
        dist = sum(self._at(k)[1] for k in range(int(f)))
        pose, _ = self._at(f)
        r = pose["root"]; pose["root"] = (r[0] + dist,) + tuple(r[1:])
        return pose


# ------------------------------------------------------------------ gotowe sekwencje pokazowe (48 klatek)
def seq_walk_run_shoot():
    sh = clip_shoot(stance())
    return Seq([(0, lambda f: walk(f, 12), 0.137, 0), (12, lambda f: run_rifle(f, 8), 0.30, 4),
                (28, lambda f: sh.sample(min(f + 3, 23)), 0.0, 4)])

def seq_suppressed():
    return Seq([(0, lambda f: merge(walk(f, 12, stride=24, arms=False), low_ready()), 0.12, 0),
                (10, lambda f: flinch(), 0.02, 2), (16, lambda f: dive_mid(), 0.22, 2),
                (20, lambda f: prone(), 0.0, 3), (26, lambda f: crawl(f, 16), 0.035, 4)])

def seq_kneel_shoot():
    sh = clip_shoot(kneel())
    return Seq([(0, lambda f: merge(stance(), aim()), 0.0, 0), (6, lambda f: merge(kneel(), aim()), 0.0, 5),
                (12, lambda f: sh.sample(min(f + 5, 23)), 0.0, 2), (34, lambda f: merge(kneel(), low_ready()), 0.0, 3),
                (40, lambda f: merge(stance(), low_ready()), 0.0, 5)])

def seq_stagger():
    return Seq([(0, lambda f: merge(walk(f, 12, stride=24, arms=False), low_ready()), 0.12, 0),
                (10, lambda f: stagger(f), 0.0, 1), (24, lambda f: merge(wide(), aim(), P(root=(-0.18, 0, 0, 0))), 0.0, 4),
                (36, lambda f: merge(walk(f, 12, stride=24, arms=False), low_ready(), P(root=(-0.18, 0, 0, 0))), 0.12, 4)])

def seq_to_cover():
    cv = clip_cover()
    return Seq([(0, lambda f: run_rifle(f, 8), 0.30, 0), (14, lambda f: merge(crouch(0.8), low_ready(), P(rot={"spine": (0, 14, 0)})), 0.05, 3),
                (18, lambda f: cv.sample(f), 0.0, 3)])

# ================================================================== bron jednoręczna
def guard1():
    """Garda z bronia jednoręczna (noz, rura, maczeta): reka przed soba, lewa oslania."""
    return P(rot={"weapon": (0, -38, 0), "upperarm.L": (14, -24, 0), "forearm.L": (0, -100, 0), "chest": (0, 4, -10), "head": (0, 4, 8)},
             loc={"weapon": (0.06, 0.04, 0.40), "hips": (0, 0, -0.04)})

def clip_slash():
    """Ciecie z zamachem: antycypacja w tyl i w gore, szybkie ciecie po skosie, powrot do gardy."""
    g = merge(wide(), guard1())
    wind = merge(wide(), P(rot={"weapon": (-30, -70, 0), "upperarm.L": (14, -50, 0), "forearm.L": (0, -60, 0), "chest": (0, -6, -28), "spine": (0, -4, -8), "head": (0, 4, 24)},
                           loc={"weapon": (-0.10, -0.04, 0.48), "hips": (-0.04, 0, -0.02)}))
    cut = merge(wide(), P(rot={"weapon": (30, 110, 0), "upperarm.L": (10, 20, 0), "forearm.L": (0, -30, 0), "chest": (0, 14, 26), "spine": (0, 8, 10), "head": (0, 8, -18),
                               "thigh.L": (0, -30, 0), "shin.L": (0, 30, 0)},
                          loc={"weapon": (0.28, 0.20, 0.02), "hips": (0.08, 0, -0.08)}, root=(0.14, 0, 0, 0)))
    return Clip(16, [(0, g, "io"), (4, wind, "hold"), (5, wind, "snap"), (7, cut, "hold"), (9, cut, "io"), (14, g, "hold")])

def pistol_aim():
    return P(rot={"head": (0, 6, 8), "chest": (0, 0, 12), "upperarm.L": (8, 0, 0), "forearm.L": (0, -14, 0)})
def pistol_recoil():
    return P(rot={"weapon": (0, -26, 0), "head": (0, 2, 8), "chest": (0, -4, 12), "upperarm.L": (8, 0, 0), "forearm.L": (0, -14, 0)},
             loc={"weapon": (-0.06, 0, 0.05)}, vis={"flash": 1})

# ================================================================== praca w osadzie
def clip_chop():
    """Rabanie drewna: zamach nad glowe, uderzenie z ugieciem kolan, wyrwanie siekiery."""
    ready = merge(wide(), P(rot={"weapon": (0, 70, 0), "spine": (0, 12, 0)}, loc={"weapon": (0.05, 0, -0.15)}))
    up = merge(wide(), P(rot={"weapon": (0, -60, 0), "spine": (0, -8, 0), "chest": (0, -8, 0), "head": (0, 10, 0)}, loc={"weapon": (-0.08, 0, 0.20), "hips": (0, 0, 0.02)}))
    hit = merge(wide(), P(rot={"weapon": (0, 120, 0), "spine": (0, 28, 0), "chest": (0, 10, 0), "head": (0, 14, 0), "thigh.L": (0, -24, 0), "shin.L": (0, 30, 0), "thigh.R": (0, -10, 0), "shin.R": (0, 26, 0)},
                         loc={"weapon": (0.18, 0, -0.18), "hips": (0.02, 0, -0.12)}))
    yank = merge(hit, P(rot={"weapon": (0, -14, 0), "spine": (0, -6, 0)}, loc={"hips": (0, 0, 0.04)}))
    return Clip(20, [(0, ready, "io"), (6, up, "hold"), (8, up, "in"), (10, hit, "hold"), (12, hit, "io"), (14, yank, "io"), (19, ready, "hold")])

def clip_dig():
    """Kopanie: wbicie lopaty z docisnieciem noga, podwazenie, wyrzut ziemi w bok."""
    stand = merge(wide(), P(rot={"spine": (0, 14, 0)}))
    stab = merge(wide(), P(rot={"weapon": (0, -6, 0), "spine": (0, 24, 0), "thigh.R": (0, -30, 0), "shin.R": (0, 40, 0)}, loc={"weapon": (0.06, 0, -0.22), "hips": (0, 0, -0.06)}))
    pry = merge(wide(), P(rot={"weapon": (0, -40, 0), "spine": (0, 30, 0), "chest": (0, 6, 0), "thigh.L": (0, -26, 0), "shin.L": (0, 40, 0)}, loc={"weapon": (-0.06, 0, -0.14), "hips": (-0.04, 0, -0.14)}))
    lift = merge(wide(), P(rot={"weapon": (0, -24, 0), "spine": (0, 12, 0), "chest": (0, 0, 30), "head": (0, 0, 20)}, loc={"weapon": (0.04, 0.05, 0.10), "hips": (0, 0, -0.04)}))
    toss = merge(wide(), P(rot={"weapon": (-30, -10, 0), "spine": (0, 14, 0), "chest": (0, 0, 48), "head": (0, 0, 30)}, loc={"weapon": (0.06, 0.20, 0.12)}))
    return Clip(24, [(0, stand, "io"), (4, stab, "out"), (6, stab, "hold"), (8, pry, "io"), (12, lift, "io"), (15, toss, "snap"), (17, toss, "io"), (22, stand, "hold")])

def carry_walk(f, n=14):
    w = walk(f, n, stride=20, arms=False)
    p = (f % n) / n
    w["rot"]["spine"] = (0, -8, 0); w["rot"]["chest"] = (0, -4, 0)                         # odchylenie pod ciezarem
    w["rot"]["weapon"] = (0, 0, 3 * math.cos(2 * math.pi * p))
    w["loc"]["weapon"] = (0, 0, 0.012 * math.sin(4 * math.pi * p))
    w["loc"]["hips"] = tuple(a + b for a, b in zip(w["loc"]["hips"], (0, 0, -0.03)))
    return w

def clip_smith():
    """Kucie: krotki zamach i uderzenie co 8 klatek, przytrzymanie preta szczypcami."""
    base = merge(wide(), P(rot={"spine": (0, 20, 0), "upperarm.L": (8, -30, 0), "forearm.L": (0, -40, 0), "head": (0, 16, 0)}))
    up = merge(base, P(rot={"weapon": (0, -70, 0), "chest": (0, -6, -10)}, loc={"weapon": (-0.10, 0, 0.32)}))
    hit = merge(base, P(rot={"weapon": (0, 40, 0), "chest": (0, 6, 6)}, loc={"weapon": (0.06, 0, -0.08)}))
    return Clip(8, [(0, base, "io"), (3, up, "in"), (5, hit, "hold"), (6, hit, "io")])

def sit():
    return P(rot={"thigh.L": (0, -88, 4), "shin.L": (0, 84, 0), "thigh.R": (0, -84, -6), "shin.R": (0, 80, 0), "spine": (0, 14, 0), "chest": (0, 8, 0),
                  "upperarm.L": (10, -28, 0), "forearm.L": (0, -60, 0), "upperarm.R": (-10, -30, 0), "forearm.R": (0, -62, 0)},
             loc={"hips": (-0.05, 0, -0.48)})

def talk(f):
    """Rozmowa przy ognisku: gest reka, kiwanie glowa."""
    s = math.sin(2 * math.pi * f / 16); s2 = math.sin(2 * math.pi * f / 8)
    return merge(sit(), P(rot={"upperarm.R": (-20, -30 * max(0, s), 0), "forearm.R": (0, -40 - 30 * max(0, s), 0), "head": (0, 4 * s2, 8 * s), "chest": (0, 0, 6 * s)}))

# ================================================================== skret w biegu i drabina
def run_turn(f, bank=1.0, n=8):
    """Bieg z broni po luku: przechyl calego ciala do srodka skretu, glowa patrzy w kierunek skretu.
    bank > 0 skret w lewo, < 0 w prawo (1.0 = ok. 15 stopni przechylu)."""
    p = run_rifle(f, n)
    p["root"] = tuple(p["root"][:4]) + (-15 * bank,)
    p["rot"]["head"] = tuple(a + b for a, b in zip(p["rot"].get("head", (0, 0, 0)), (12 * bank, 0, 18 * bank)))
    p["rot"]["chest"] = tuple(a + b for a, b in zip(p["rot"].get("chest", (0, 0, 0)), (0, 0, 8 * bank)))
    return p

def climb(f, n=12):
    """Wspinaczka po drabinie: na przemian reka i przeciwna noga w gore, cialo podciaga sie 0,6 m na cykl."""
    p = (f % n) / n; c = math.cos(2 * math.pi * p)
    pose = P()
    for side, s in (("L", 1), ("R", -1)):
        up = max(0.0, c * s)
        pose["rot"]["upperarm." + side] = (s * 6, -150 + 30 * c * s, 0)
        pose["rot"]["forearm." + side] = (0, -30 - 30 * (1 - up), 0)
        pose["rot"]["thigh." + side] = (0, -20 - 45 * max(0.0, -c * s), 0)
        pose["rot"]["shin." + side] = (0, 20 + 70 * max(0.0, -c * s), 0)
        pose["rot"]["foot." + side] = (0, 10, 0)
    pose["rot"]["spine"] = (0, 6, 0); pose["rot"]["head"] = (0, -16, 0)
    pose["root"] = (0, 0, 0.6 * (f / n), 0, 0)
    return pose
