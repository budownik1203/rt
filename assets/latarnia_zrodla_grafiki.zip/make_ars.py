import sys, math, json
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
W, H, ORT, T = 960, 640, 8.0, math.radians(34)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 13)
fs = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf', 11)
im = stylize('out/arsenal.exr').resize((W * 2, H * 2), Image.NEAREST); d = ImageDraw.Draw(im)
for name, era, x, y in json.load(open('out/arsenal.json')):
    px = (W / 2 + (x - 1.55) * W / ORT) * 2; py = (H / 2 - ((y + 0.15) * math.cos(T) + 0.58 * math.sin(T)) * W / ORT) * 2
    t = "%s  ·  %s" % (name, era)
    d.text((px, py), name, font=font, fill=(226, 200, 150)); d.text((px + d.textlength(name, font=font) + 8, py + 2), era, font=fs, fill=(150, 140, 160))
im.save('out/latarnia3d_bron.png')
