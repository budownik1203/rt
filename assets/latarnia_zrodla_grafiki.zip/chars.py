"""Postacie Latarni: czlowiek z warstwami ubran (bez przenikania), pozy z IK na broni, chod 8-klatkowy, mutanty."""
import math, random
from mathutils import Vector as V, Matrix
from lat3d import *
import lat3d as _L

# --------------------------------------------------------------- materialy postaci (sRGB, matowe)
def M(name, rgb, **kw): return mat(name, rgb, pass_index=3, **kw)
SKIN = lambda: M("skin", (196, 146, 112))
SKIN_PALE = lambda: M("skin_pale", (150, 150, 135))
HAIR = lambda: M("hair", (58, 40, 30))
HAIR_L = lambda: M("hair_l", (150, 110, 60))
CLOTH = {
    "brown": (106, 76, 50), "leather": (92, 62, 42), "olive": (86, 96, 60), "blue": (70, 82, 110),
    "teal": (56, 82, 80), "grey": (78, 74, 84), "darkgrey": (52, 50, 60),
}
def cloth(n): return M("cloth_" + n, CLOTH[n])
METAL = lambda: M("metal", (128, 128, 140))
METAL_D = lambda: M("metal_d", (70, 70, 80))
RUST = lambda: M("rust", (140, 76, 44))
WOOD = lambda: M("wood", (110, 78, 48))
STRAP = lambda: M("strap", (60, 42, 30))
BOOT = lambda: M("boot", (40, 34, 36))
GLASS = lambda: M("glass", (120, 150, 140))
REDC = lambda: M("redcloth", (150, 34, 36))
EYE = lambda: M("eye", (14, 12, 18))
GLOW_RED = lambda: M("glow_red", (255, 70, 50), emit=(255, 60, 40), strength=6)
GLOW_YEL = lambda: M("glow_yel", (255, 220, 120), emit=(255, 210, 110), strength=5)
CHITIN = lambda: M("chitin", (92, 74, 104))
CHITIN_L = lambda: M("chitin_l", (150, 128, 138))
FLESH = lambda: M("flesh", (130, 40, 40))
PALE = lambda: M("pale", (120, 150, 136))
BLOAT = lambda: M("bloat", (92, 104, 60))
TOOTH = lambda: M("tooth", (210, 200, 180))

# --------------------------------------------------------------- szkielet czlowieka (patrzy w +X, lewo = +Y)
WEAPON_BONES = {
    "rifle":  [("weapon", (0.26, -0.105, 1.26), (0.56, -0.09, 1.22))],
    "spear":  [("weapon", (0.29, -0.25, 1.18), (0.30, -0.25, 1.48)), ("shield", (0.30, 0.10, 1.15), (0.50, 0.10, 1.15))],
    "hammer": [("weapon", (0.20, -0.125, 1.10), (-0.10, -0.145, 1.50))],
    "banner": [("weapon", (0.24, -0.24, 1.18), (0.24, -0.24, 1.48))],
    "bow":    [("weapon", (0.49, 0.03, 1.40), (0.49, 0.03, 1.70))],
    "grenade": [],
    "idle": [],
}
def human_bones(arm=1.0, leg=1.0, torso=1.0, pose="idle"):
    hz = 0.92 * leg
    B = [("hips", (0, 0, hz), (0, 0, hz + 0.10), None),
         ("spine", (0, 0, hz + 0.10), (0, 0, hz + 0.10 + 0.20 * torso), "hips")]
    cz = hz + 0.10 + 0.20 * torso
    B += [("chest", (0, 0, cz), (0, 0, cz + 0.20 * torso), "spine"),
          ("neck", (0, 0, cz + 0.20 * torso), (0, 0, cz + 0.28 * torso), "chest"),
          ("head", (0, 0, cz + 0.28 * torso), (0, 0, cz + 0.56 * torso), "neck")]
    sz = cz + 0.18 * torso
    for s, n in ((1, "L"), (-1, "R")):
        ua = 0.27 * arm; fa = 0.24 * arm
        B += [("shoulder." + n, (0, s * 0.10, sz), (0, s * 0.18, sz), "chest"),
              ("upperarm." + n, (-0.01, s * 0.19, sz - 0.01), (-0.035, s * 0.20, sz - 0.01 - ua), "shoulder." + n),
              ("forearm." + n, (-0.035, s * 0.20, sz - 0.01 - ua), (0.01, s * 0.20, sz - 0.01 - ua - fa), "upperarm." + n),
              ("hand." + n, (0.01, s * 0.20, sz - 0.01 - ua - fa), (0.02, s * 0.20, sz - 0.09 - ua - fa), "forearm." + n),
              ("thigh." + n, (0, s * 0.09, hz), (0.012, s * 0.095, hz * 0.545), "hips"),
              ("shin." + n, (0.012, s * 0.095, hz * 0.545), (-0.01, s * 0.10, 0.09), "thigh." + n),
              ("foot." + n, (-0.01, s * 0.10, 0.09), (0.15, s * 0.10, 0.04), "shin." + n)]
    for n, h, t in WEAPON_BONES.get(pose, []):
        B.append((n, h, t, "chest"))
    return B

def bone_pts(rig, name):
    b = rig.ob.data.bones[name]
    return V(b.head_local), V(b.tail_local)

# --------------------------------------------------------------- czlowiek
def human(name, outfit, pose="idle"):
    o = dict(skin="skin", hair="hair", jacket="brown", pants="brown", helmet=None, armor=None, mask=None,
             beard=False, strap=True, pouches=True, third_arm=False, glow_eyes=False)
    o.update(outfit)
    rig = Rig(name, human_bones(pose=pose))
    rig.tg = {}; rig.objs = {}
    skin = SKIN() if o["skin"] == "skin" else SKIN_PALE()
    J = cloth(o["jacket"]); P = cloth(o["pants"])
    A = rig.attach
    hips_h, _ = bone_pts(rig, "hips"); chest_h, chest_t = bone_pts(rig, "chest")
    # --- tulow: dwa segmenty ubrania z zakladka (dolny na spine, gorny na chest)
    A(loft(name + "_jkt_lo", [((0, 0, 0.88), 0.104, 0.150), ((0, 0, 1.00), 0.098, 0.143), ((0, 0, 1.12), 0.094, 0.134), ((0, 0, 1.25), 0.104, 0.150)], J), "spine")
    A(loft(name + "_jkt_up", [((0, 0, 1.20), 0.100, 0.145), ((0.006, 0, 1.31), 0.114, 0.163), ((0, 0, 1.40), 0.108, 0.172),
                              ((-0.005, 0, 1.46), 0.080, 0.140), ((0, 0, 1.50), 0.050, 0.060)], J), "chest")
    A(loft(name + "_collar", [((0, 0, 1.455), 0.075, 0.085), ((0, 0, 1.49), 0.062, 0.070)], cloth("darkgrey") if o["jacket"] != "darkgrey" else J), "chest")
    # --- pas, klamra, sakwy, pas na skos
    A(loft(name + "_belt", [((0, 0, 0.955), 0.112, 0.158), ((0, 0, 1.005), 0.108, 0.153)], STRAP()), "spine")
    A(box(name + "_buckle", (0.112, 0.02, 0.98), (0.012, 0.035, 0.035), METAL()), "spine")
    if o["pouches"]:
        A(box(name + "_pouch1", (0.09, -0.12, 0.95), (0.05, 0.05, 0.07), STRAP()), "spine")
        A(box(name + "_pouch2", (0.10, 0.08, 0.95), (0.045, 0.05, 0.065), STRAP()), "spine")
    if o["strap"]:
        A(box(name + "_strap", (0.112, 0.01, 1.25), (0.016, 0.035, 0.46), STRAP(), rot=(math.radians(34), 0, 0)), "chest")
    # --- pancerz (sztywny, +3 cm nad kurtka)
    if o["armor"] == "plate":
        A(loft(name + "_cuirass", [((0, 0, 1.13), 0.124, 0.165), ((0.008, 0, 1.30), 0.142, 0.190), ((0, 0, 1.43), 0.130, 0.190), ((-0.005, 0, 1.46), 0.100, 0.165)], METAL()), "chest")
        for s in (1, -1):
            A(ellipsoid(name + "_pauld" + str(s), (-0.01, s * 0.175, 1.425), (0.085, 0.075, 0.06), METAL(), clip_z=-0.2), "shoulder." + ("L" if s > 0 else "R"))
    if o["armor"] == "vest":
        A(loft(name + "_vest", [((0, 0, 1.08), 0.122, 0.162), ((0.008, 0, 1.30), 0.134, 0.182), ((0, 0, 1.43), 0.122, 0.180)], RUST()), "chest")
    # --- rekawy (barki zakryte czasza, zeby nie bylo szpary w stawie)
    for s, n in ((1, "L"), (-1, "R")):
        sh, ua_t = bone_pts(rig, "upperarm." + n); fa_h, fa_t = bone_pts(rig, "forearm." + n); h_h, h_t = bone_pts(rig, "hand." + n)
        A(ellipsoid(name + "_shcap" + n, (-0.005, s * 0.175, 1.405), (0.068, 0.068, 0.064), J), "shoulder." + n)
        A(loft(name + "_slv_u" + n, [(sh, 0.058, 0.058), ((sh + ua_t) / 2, 0.054, 0.052), (ua_t, 0.048, 0.048)], J), "upperarm." + n)
        A(ellipsoid(name + "_elb" + n, ua_t, (0.05, 0.048, 0.05), J), "forearm." + n)
        A(loft(name + "_slv_f" + n, [(fa_h, 0.047, 0.046), ((fa_h + fa_t) / 2, 0.044, 0.042), (fa_t + V((0, 0, 0.02)), 0.040, 0.038)], J), "forearm." + n)
        A(loft(name + "_cuff" + n, [(fa_t + V((0, 0, 0.045)), 0.045, 0.043), (fa_t + V((0, 0, 0.012)), 0.044, 0.042)], cloth("darkgrey")), "forearm." + n)
        A(ellipsoid(name + "_hand" + n, (h_h + h_t) / 2, (0.042, 0.032, 0.055), skin), "hand." + n)
        # --- nogawki, kolano, buty
        th_h, th_t = bone_pts(rig, "thigh." + n); sn_h, sn_t = bone_pts(rig, "shin." + n); ft_h, ft_t = bone_pts(rig, "foot." + n)
        A(loft(name + "_pant_u" + n, [(th_h + V((0, -s * 0.005, 0.02)), 0.088, 0.082), ((th_h + th_t) / 2, 0.074, 0.068), (th_t, 0.060, 0.056)], P), "thigh." + n)
        A(ellipsoid(name + "_knee" + n, th_t, (0.062, 0.058, 0.062), P), "shin." + n)
        A(loft(name + "_pant_l" + n, [(sn_h, 0.058, 0.055), (sn_h * 0.55 + sn_t * 0.45, 0.052, 0.049), (sn_t + V((0, 0, 0.10)), 0.050, 0.048)], P), "shin." + n)
        A(loft(name + "_boot_s" + n, [(sn_t + V((0, 0, 0.16)), 0.056, 0.054), (sn_t + V((0, 0, -0.03)), 0.058, 0.056)], BOOT()), "shin." + n)
        A(box(name + "_boot_f" + n, (0.05, s * 0.10, 0.045), (0.25, 0.105, 0.09), BOOT()), "foot." + n)
    # --- szyja i glowa (3/4: twarz w +X)
    A(cyl(name + "_neck", (0, 0, 1.43), (0, 0, 1.54), 0.046, skin), "neck")
    hc = V((0.012, 0, 1.635))
    A(ellipsoid(name + "_head", hc, (0.118, 0.102, 0.135), skin), "head")
    A(ellipsoid(name + "_jaw", hc + V((0.04, 0, -0.06)), (0.075, 0.085, 0.06), skin), "head")
    A(ellipsoid(name + "_nose", hc + V((0.115, 0, -0.005)), (0.03, 0.02, 0.028), skin), "head")
    for s in (1, -1):
        A(ellipsoid(name + "_eye" + str(s), hc + V((0.097, s * 0.045, 0.02)), (0.016, 0.018, 0.016), GLOW_RED() if o["glow_eyes"] else EYE()), "head")
        A(ellipsoid(name + "_ear" + str(s), hc + V((-0.01, s * 0.10, 0.0)), (0.025, 0.018, 0.035), skin), "head")
    if o["beard"]:
        A(ellipsoid(name + "_beard", hc + V((0.06, 0, -0.08)), (0.07, 0.09, 0.055), HAIR()), "head")
    if o["helmet"] is None:
        hair = HAIR() if o["hair"] == "hair" else HAIR_L()
        hm = ellipsoid(name + "_hair", hc + V((-0.012, 0, 0.018)), (0.128, 0.112, 0.138), hair)
        import bmesh as _bm
        bm = _bm.new(); bm.from_mesh(hm.data)
        kill = [v for v in bm.verts if not (v.co.z > hc.z + 0.03 or v.co.x < hc.x - 0.035)]
        _bm.ops.delete(bm, geom=kill, context="VERTS"); bm.to_mesh(hm.data); bm.free()
        A(hm, "head")
    if o["helmet"] == "pot":
        A(ellipsoid(name + "_helm", hc + V((0, 0, 0.05)), (0.138, 0.125, 0.085), METAL(), clip_z=-0.05), "head")
        A(loft(name + "_helmrim", [(hc + V((0, 0, 0.055)), 0.20, 0.19), (hc + V((0, 0, 0.04)), 0.20, 0.19)], METAL_D(), seg=14), "head")
    if o["helmet"] == "mil":
        A(ellipsoid(name + "_helm", hc + V((-0.005, 0, 0.05)), (0.148, 0.132, 0.12), cloth("olive"), clip_z=-0.1), "head")
        A(box(name + "_brim", hc + V((0.12, 0, 0.04)), (0.06, 0.2, 0.014), cloth("olive"), rot=(0, math.radians(18), 0)), "head")
        A(box(name + "_chin", hc + V((0.02, 0, -0.06)), (0.012, 0.215, 0.012), STRAP(), rot=(0, 0, 0)), "head")
    if o["mask"] == "gas":
        A(cyl(name + "_snout", hc + V((0.09, 0, -0.04)), hc + V((0.17, 0, -0.07)), 0.045, METAL_D()), "head")
        A(cyl(name + "_filter", hc + V((0.16, 0, -0.07)), hc + V((0.21, 0, -0.09)), 0.035, METAL()), "head")
        for s in (1, -1):
            A(ellipsoid(name + "_goggle" + str(s), hc + V((0.105, s * 0.045, 0.02)), (0.02, 0.032, 0.03), GLASS()), "head")
        A(loft(name + "_maskband", [(hc + V((0, 0, 0.02)), 0.125, 0.108), (hc + V((0, 0, 0.0)), 0.125, 0.108)], STRAP()), "head")
    if o["third_arm"]:
        A(loft(name + "_arm3a", [((0.04, 0.15, 1.27), 0.045, 0.045), ((0.10, 0.25, 1.10), 0.04, 0.04), ((0.16, 0.27, 0.95), 0.035, 0.035)], SKIN_PALE()), "chest")
        A(ellipsoid(name + "_arm3h", (0.18, 0.27, 0.90), (0.04, 0.03, 0.05), SKIN_PALE()), "chest")
        A(ellipsoid(name + "_arm3f", (0.07, 0.2, 1.19), (0.03, 0.03, 0.03), FLESH()), "chest")
    rig.pose = pose; rig.props = {}; rig.tg_base = {}
    build_weapon(rig, name, pose)
    return rig

def build_weapon(rig, name, pose):
    A = rig.attach
    def tgt(n, loc, bone):
        e = empty(name + "_" + n, loc); A(e, bone); e.location = V(loc); rig.tg[n] = e; rig.tg_base[n] = V(loc); return e
    def keep(key, ob): rig.objs[key] = ob; return ob
    if pose == "rifle":
        W = "weapon"
        A(box(name + "_stock", (0.10, -0.10, 1.30), (0.26, 0.045, 0.085), WOOD(), rot=(0, math.radians(8), 0)), W)
        A(box(name + "_rbody", (0.34, -0.085, 1.27), (0.26, 0.04, 0.06), METAL_D(), rot=(0, math.radians(8), 0)), W)
        A(box(name + "_fore", (0.55, -0.08, 1.24), (0.24, 0.042, 0.05), WOOD(), rot=(0, math.radians(8), 0)), W)
        A(cyl(name + "_barrel", (0.60, -0.08, 1.245), (0.98, -0.08, 1.19), 0.012, METAL(), seg=6), W)
        A(box(name + "_sight", (0.30, -0.085, 1.31), (0.06, 0.02, 0.025), METAL_D()), W)
        keep("mag", A(box(name + "_mag", (0.36, -0.085, 1.21), (0.05, 0.03, 0.09), METAL_D(), rot=(0, math.radians(-10), 0)), W))
        hm = box(name + "_maghand", (0.02, 0.20, 0.80), (0.05, 0.03, 0.09), METAL_D()); keep("maghand", A(hm, "hand.L")); hm.hide_render = True
        fl = ellipsoid(name + "_flash", (1.04, -0.08, 1.185), (0.10, 0.05, 0.05), M("flashm", (255, 240, 190), emit=(255, 230, 170), strength=14)); keep("flash", A(fl, W)); fl.hide_render = True
        rig.ik("forearm.R", tgt("ikR", (0.26, -0.105, 1.26), W))
        rig.ik("forearm.L", tgt("ikL", (0.54, -0.075, 1.225), W))
        rig.props["muzzle"] = (1.0, -0.08, 1.19)
        ej = empty(name + "_eject", (0.36, -0.11, 1.29)); A(ej, W); ej.location = V((0.36, -0.11, 1.29)); keep("eject", ej)
        mz = empty(name + "_muzzle", (1.0, -0.08, 1.19)); A(mz, W); mz.location = V((1.0, -0.08, 1.19)); keep("muzzle", mz)
    if pose == "spear":
        W, S = "weapon", "shield"
        A(loft(name + "_shield", [((0.30, 0.10, 1.15), 0.30, 0.30), ((0.34, 0.10, 1.15), 0.30, 0.30)], RUST(), seg=14), S)
        A(ellipsoid(name + "_boss", (0.345, 0.10, 1.15), (0.03, 0.08, 0.08), METAL()), S)
        A(loft(name + "_shrim", [((0.335, 0.10, 1.15), 0.31, 0.31), ((0.345, 0.10, 1.15), 0.31, 0.31)], METAL_D(), seg=14, cap=False), S)
        A(cyl(name + "_spear", (0.27, -0.25, 0.05), (0.31, -0.25, 2.30), 0.017, WOOD(), seg=6), W)
        A(loft(name + "_spearhead", [((0.31, -0.25, 2.28), 0.012, 0.03), ((0.315, -0.25, 2.50), 0.002, 0.002)], METAL(), seg=6), W)
        rig.ik("forearm.R", tgt("ikR", (0.29, -0.25, 1.18), W))
        rig.ik("forearm.L", tgt("ikL", (0.24, 0.10, 1.15), S))
    if pose == "bow":
        W = "weapon"
        arc = [((0.50 - 0.10 * (1 - math.cos(a)), 0.03, 1.40 + 0.5 * math.sin(a)), 0.016, 0.016) for a in [-1.25, -0.6, 0, 0.6, 1.25]]
        A(loft(name + "_bow", arc, WOOD(), seg=6), W)
        top = V((0.50 - 0.10 * (1 - math.cos(1.25)), 0.03, 1.40 + 0.5 * math.sin(1.25))); bot = V((top.x, 0.03, 1.40 - 0.5 * math.sin(1.25)))
        draw = V((0.06, -0.04, 1.50))
        A(cyl(name + "_str1", top, draw, 0.004, M("string", (200, 200, 190)), seg=4), "chest")
        A(cyl(name + "_str2", draw, bot, 0.004, M("string", (200, 200, 190)), seg=4), "chest")
        A(cyl(name + "_arrow", draw, (0.70, 0.02, 1.43), 0.006, WOOD(), seg=4), "chest")
        rig.ik("forearm.L", tgt("ikL", (0.49, 0.03, 1.40), W))
        rig.ik("forearm.R", tgt("ikR", (0.08, -0.05, 1.49), "chest"))
    if pose == "hammer":
        W = "weapon"
        A(cyl(name + "_haft", (0.26, -0.12, 1.02), (-0.30, -0.16, 1.78), 0.02, WOOD(), seg=6), W)
        A(box(name + "_hhead", (-0.32, -0.16, 1.80), (0.16, 0.09, 0.09), METAL(), rot=(0, math.radians(-50), 0)), W)
        rig.ik("forearm.R", tgt("ikR", (0.20, -0.125, 1.10), W))
        rig.ik("forearm.L", tgt("ikL", (0.04, -0.14, 1.30), W))
    if pose == "banner":
        W = "weapon"
        A(cyl(name + "_pole", (0.24, -0.24, 0.25), (0.24, -0.24, 2.75), 0.018, WOOD(), seg=6), W)
        A(box(name + "_flag", (0.52, -0.24, 2.48), (0.55, 0.012, 0.42), REDC()), W)
        A(box(name + "_emblem", (0.52, -0.257, 2.48), (0.16, 0.004, 0.16), GLOW_YEL()), W)
        rig.ik("forearm.R", tgt("ikR", (0.24, -0.24, 1.18), W))
    if pose == "grenade":
        g = ellipsoid(name + "_gren", (0.02, -0.20, 0.80), (0.04, 0.035, 0.05), M("grenm", (70, 80, 56))); keep("gren", A(g, "hand.R"))

# --------------------------------------------------------------- pozy i chod
def walk_pose(rig, f, n=8, arms=True, stride=28):
    """Chod: noga podporowa sunie do tylu, druga przechodzi zgieta do przodu; rece przeciwnie do nog; podskok."""
    rig.reset_pose()
    p = (f % n) / n
    for side, ph in (("L", 0.0), ("R", 0.5)):
        c = math.cos(2 * math.pi * (p + ph))
        sw = -stride * c                                     # ujemny kat = noga do przodu
        knee = 6 + 38 * max(0.0, -math.sin(2 * math.pi * (p + ph)))
        rig.rot("thigh." + side, (0, 1, 0), sw)
        rig.rot("shin." + side, (0, 1, 0), knee)
        rig.rot("foot." + side, (0, 1, 0), -0.55 * (sw + knee) + 4)
        if arms:
            rig.rot("upperarm." + side, (0, 1, 0), 0.65 * stride * c)
            rig.rot("forearm." + side, (0, 1, 0), -10 - 8 * max(0.0, -c))
    bob = 0.022 * (1 - abs(math.cos(2 * math.pi * p))) - 0.011
    rig.ob.pose.bones["hips"].location = V((0, bob, 0))
    rig.rot("spine", (0, 1, 0), -3)

def stand_pose(rig, arms=True):
    rig.reset_pose()
    rig.rot("thigh.L", (0, 1, 0), -6); rig.rot("shin.L", (0, 1, 0), 6); rig.rot("foot.L", (0, 1, 0), 0)
    rig.rot("thigh.R", (0, 1, 0), 8); rig.rot("shin.R", (0, 1, 0), 4); rig.rot("foot.R", (0, 1, 0), -10)
    if arms:
        rig.rot("upperarm.L", (1, 0, 0), 6); rig.rot("upperarm.R", (1, 0, 0), -6)
        rig.rot("forearm.L", (0, 1, 0), -12); rig.rot("forearm.R", (0, 1, 0), -12)

# --------------------------------------------------------------- mutanty
def ogar(name):
    B = [("pelvis", (-0.50, 0, 0.62), (-0.20, 0, 0.66), None), ("spine", (-0.20, 0, 0.66), (0.25, 0, 0.72), "pelvis"),
         ("chest", (0.25, 0, 0.72), (0.45, 0, 0.74), "spine"), ("neck", (0.45, 0, 0.76), (0.68, 0, 0.84), "chest"),
         ("head", (0.68, 0, 0.84), (0.96, 0, 0.80), "neck"), ("jaw", (0.70, 0, 0.76), (0.95, 0, 0.70), "head"),
         ("tail1", (-0.50, 0, 0.62), (-0.85, 0, 0.74), "pelvis"), ("tail2", (-0.85, 0, 0.74), (-1.12, 0, 0.92), "tail1")]
    for s, n in ((1, "L"), (-1, "R")):
        B += [("fup." + n, (0.38, s * 0.14, 0.64), (0.42, s * 0.15, 0.38), "chest"), ("flo." + n, (0.42, s * 0.15, 0.38), (0.36, s * 0.15, 0.10), "fup." + n),
              ("fpaw." + n, (0.36, s * 0.15, 0.10), (0.47, s * 0.15, 0.04), "flo." + n),
              ("hup." + n, (-0.42, s * 0.15, 0.60), (-0.26, s * 0.16, 0.36), "pelvis"), ("hlo." + n, (-0.26, s * 0.16, 0.36), (-0.44, s * 0.16, 0.14), "hup." + n),
              ("hpaw." + n, (-0.44, s * 0.16, 0.14), (-0.33, s * 0.16, 0.04), "hlo." + n)]
    rig = Rig(name, B); A = rig.attach
    C, CL = CHITIN(), CHITIN_L()
    A(loft(name + "_body", [((-0.62, 0, 0.64), 0.09, 0.08), ((-0.45, 0, 0.66), 0.14, 0.12), ((-0.15, 0, 0.66), 0.13, 0.115),
                             ((0.12, 0, 0.70), 0.17, 0.14), ((0.36, 0, 0.73), 0.19, 0.16), ((0.52, 0, 0.77), 0.13, 0.11)], C), "spine")
    xs = [-0.52, -0.38, -0.24, -0.10, 0.04, 0.18, 0.32, 0.46]
    for i, x in enumerate(xs):
        zt = 0.74 + 0.10 * max(0.0, (x + 0.1)) + (0.02 if i % 2 else 0)
        A(ellipsoid(name + "_plate%d" % i, (x, 0, zt), (0.11, 0.15 + 0.04 * (x > 0), 0.055), C if i % 2 else CL), "spine" if x < 0.25 else "chest")
        A(loft(name + "_spike%d" % i, [((x - 0.02, 0, zt + 0.03), 0.03, 0.02), ((x - 0.08, 0, zt + 0.16 + 0.05 * (x > 0)), 0.003, 0.003)], CL, seg=5), "spine" if x < 0.25 else "chest")
    A(loft(name + "_neckm", [((0.45, 0, 0.78), 0.12, 0.10), ((0.68, 0, 0.86), 0.09, 0.08)], C), "neck")
    A(loft(name + "_skull", [((0.62, 0, 0.88), 0.12, 0.11), ((0.80, 0, 0.88), 0.10, 0.095), ((1.00, 0, 0.83), 0.04, 0.05)], C), "head")
    A(ellipsoid(name + "_brow", (0.78, 0, 0.95), (0.12, 0.11, 0.04), CL), "head")
    A(loft(name + "_jawm", [((0.70, 0, 0.77), 0.05, 0.07), ((0.95, 0, 0.71), 0.02, 0.035)], C), "jaw")
    A(loft(name + "_mouth", [((0.72, 0, 0.80), 0.03, 0.06), ((0.93, 0, 0.765), 0.012, 0.03)], FLESH()), "head")
    for s in (1, -1):
        A(ellipsoid(name + "_eye%d" % s, (0.82, s * 0.075, 0.905), (0.03, 0.022, 0.026), GLOW_RED()), "head")
        for k in range(3):
            A(loft(name + "_tooth%d%d" % (s, k), [((0.80 + 0.05 * k, s * 0.035, 0.795), 0.009, 0.009), ((0.80 + 0.05 * k, s * 0.035, 0.765), 0.001, 0.001)], TOOTH(), seg=4), "jaw")
    A(loft(name + "_tail_a", [((-0.50, 0, 0.64), 0.06, 0.06), ((-0.85, 0, 0.75), 0.035, 0.035)], C), "tail1")
    A(loft(name + "_tail_b", [((-0.85, 0, 0.75), 0.035, 0.035), ((-1.14, 0, 0.94), 0.008, 0.008)], C), "tail2")
    for s, n in ((1, "L"), (-1, "R")):
        for seg_, r0, r1 in (("fup", 0.085, 0.055), ("flo", 0.05, 0.036), ("hup", 0.11, 0.06), ("hlo", 0.055, 0.036)):
            h, t = bone_pts(rig, seg_ + "." + n)
            A(loft(name + "_%s%s" % (seg_, n), [(h, r0, r0), (t, r1, r1)], C if s > 0 else C), seg_ + "." + n)
        for seg_ in ("fpaw", "hpaw"):
            h, t = bone_pts(rig, seg_ + "." + n)
            A(loft(name + "_%s%s" % (seg_, n), [(h, 0.03, 0.03), (t, 0.02, 0.035)], C), seg_ + "." + n)
    return rig

def ogar_pose(rig, f, n=8):
    rig.reset_pose()
    p = (f % n) / n
    for leg, ph in (("f", 0.0), ("h", 0.5)):
        for side, ps in (("L", 0.0), ("R", 0.5)):
            c = math.cos(2 * math.pi * (p + ph + ps))
            rig.rot(leg + "up." + side, (0, 1, 0), -24 * c)
            rig.rot(leg + "lo." + side, (0, 1, 0), (18 if leg == "f" else -18) * max(0.0, -math.sin(2 * math.pi * (p + ph + ps))) * (1 if leg == "f" else -1))
    rig.ob.pose.bones["pelvis"].location = V((0, 0, 0.02 * math.sin(4 * math.pi * p)))
    rig.rot("jaw", (0, 1, 0), 12 + 6 * math.sin(2 * math.pi * p))
    rig.rot("tail1", (0, 0, 1), 10 * math.sin(2 * math.pi * p))

def krzykacz(name):
    rig = Rig(name, human_bones(arm=1.35, leg=1.02, torso=1.05)); A = rig.attach
    Pm = PALE()
    A(loft(name + "_torso_lo", [((0, 0, 0.90), 0.075, 0.10), ((0, 0, 1.10), 0.065, 0.09), ((0, 0, 1.26), 0.07, 0.10)], Pm), "spine")
    A(loft(name + "_torso_up", [((0, 0, 1.22), 0.07, 0.10), ((0, 0, 1.36), 0.085, 0.125), ((0, 0, 1.47), 0.065, 0.11), ((0, 0, 1.52), 0.04, 0.045)], Pm), "chest")
    for k in range(3):
        A(loft(name + "_rib%d" % k, [((0.07, -0.08, 1.30 + 0.05 * k), 0.008, 0.008), ((0.085, 0.08, 1.30 + 0.05 * k), 0.008, 0.008)], FLESH(), seg=4), "chest")
    for s, n in ((1, "L"), (-1, "R")):
        for b, r0, r1 in (("upperarm", 0.04, 0.032), ("forearm", 0.03, 0.024), ("thigh", 0.055, 0.04), ("shin", 0.04, 0.03)):
            h, t = bone_pts(rig, b + "." + n); A(loft(name + "_" + b + n, [(h, r0, r0), (t, r1, r1)], Pm), b + "." + n)
        h, t = bone_pts(rig, "hand." + n)
        A(loft(name + "_claw" + n, [(h, 0.03, 0.035), (t + V((0, 0, -0.06)), 0.008, 0.02)], Pm), "hand." + n)
        h, t = bone_pts(rig, "foot." + n); A(loft(name + "_ft" + n, [(h, 0.035, 0.03), (t, 0.02, 0.03)], Pm), "foot." + n)
    A(cyl(name + "_neckm", (0, 0, 1.47), (0, 0, 1.60), 0.035, Pm), "neck")
    hc = V((0.03, 0, 1.73))
    A(ellipsoid(name + "_head", hc, (0.10, 0.085, 0.15), Pm), "head")
    A(ellipsoid(name + "_mouth", hc + V((0.075, 0, -0.06)), (0.04, 0.045, 0.075), EYE()), "head")
    A(ellipsoid(name + "_throat", hc + V((0.085, 0, -0.06)), (0.02, 0.03, 0.05), FLESH()), "head")
    for s in (1, -1):
        A(ellipsoid(name + "_eye%d" % s, hc + V((0.085, s * 0.035, 0.04)), (0.015, 0.016, 0.02), EYE()), "head")
    return rig

def krzykacz_pose(rig, f):
    rig.reset_pose()
    rig.rot("spine", (0, 1, 0), 18); rig.rot("chest", (0, 1, 0), 14); rig.rot("neck", (0, 1, 0), 28); rig.rot("head", (0, 1, 0), -30)
    sway = 6 * math.sin(2 * math.pi * f / 8)
    for s, n in ((1, "L"), (-1, "R")):
        rig.rot("upperarm." + n, (1, 0, 0), s * (14 + sway)); rig.rot("forearm." + n, (0, 1, 0), -18)
        rig.rot("thigh." + n, (0, 1, 0), -14); rig.rot("shin." + n, (0, 1, 0), 22)

def nosiciel(name):
    rig = Rig(name, human_bones(arm=0.95, leg=0.78, torso=0.95)); A = rig.attach
    Bm = BLOAT()
    A(ellipsoid(name + "_belly", (0.05, 0, 0.98), (0.36, 0.34, 0.40), Bm), "spine")
    rnd = random.Random(4)
    for k in range(9):
        a = rnd.uniform(-1.2, 1.2); z = rnd.uniform(0.75, 1.25)
        A(ellipsoid(name + "_pust%d" % k, (0.05 + 0.34 * math.cos(a), 0.32 * math.sin(a), z), (0.035, 0.035, 0.035), GLOW_YEL()), "spine")
    for s, n in ((1, "L"), (-1, "R")):
        for b, r0, r1 in (("upperarm", 0.06, 0.05), ("forearm", 0.05, 0.045), ("thigh", 0.09, 0.07), ("shin", 0.07, 0.06)):
            h, t = bone_pts(rig, b + "." + n); A(loft(name + "_" + b + n, [(h, r0, r0), (t, r1, r1)], Bm), b + "." + n)
        h, t = bone_pts(rig, "hand." + n); A(ellipsoid(name + "_h" + n, (h + t) / 2, (0.05, 0.04, 0.06), Bm), "hand." + n)
        h, t = bone_pts(rig, "foot." + n); A(box(name + "_f" + n, (0.04, s * 0.10, 0.045), (0.22, 0.11, 0.09), Bm), "foot." + n)
    hc = V((0.03, 0, 1.47))
    A(ellipsoid(name + "_head", hc, (0.09, 0.08, 0.10), SKIN_PALE()), "head")
    for s in (1, -1):
        A(ellipsoid(name + "_eye%d" % s, hc + V((0.075, s * 0.035, 0.01)), (0.018, 0.018, 0.018), GLOW_RED()), "head")
    return rig

def rozrost(name, loc):
    import bmesh as _bm
    bm = _bm.new(); _bm.ops.create_icosphere(bm, subdivisions=3, radius=1.0)
    rnd = random.Random(7)
    for v in bm.verts:
        d = v.co.normalized(); k = 1 + 0.18 * math.sin(5 * d.x + 2 * d.y) + 0.12 * math.sin(7 * d.z + d.x) + rnd.uniform(-0.04, 0.04)
        v.co = V((d.x * 1.05 * k, d.y * 0.95 * k, max(d.z * 0.8 * k, -0.15)))
    ob = bm_obj(name, bm, FLESH(), True, 3); ob.location = V(loc)
    parts = [ob]
    for k in range(5):
        a = rnd.uniform(0, 6.28); r = 0.85
        e = ellipsoid(name + "_organ%d" % k, (loc[0] + r * math.cos(a) * 0.8, loc[1] + r * math.sin(a) * 0.8, loc[2] + 0.45 + rnd.uniform(-0.1, 0.25)), (0.1, 0.1, 0.1), GLOW_YEL())
        parts.append(e)
    for k in range(10):
        a = rnd.uniform(0, 6.28)
        p0 = V((loc[0] + 0.9 * math.cos(a), loc[1] + 0.9 * math.sin(a), loc[2] + 0.1))
        p1 = V((loc[0] + 1.8 * math.cos(a), loc[1] + 1.7 * math.sin(a), 0.03))
        parts.append(cyl(name + "_tend%d" % k, p0, p1, 0.07, FLESH(), r1=0.015, seg=6))
    return parts

def rat(name, loc, yaw):
    rig_parts = []
    c = V(loc)
    ca, sa = math.cos(yaw), math.sin(yaw)
    def P(x, y, z): return V((c.x + x * ca - y * sa, c.y + x * sa + y * ca, z))
    rig_parts.append(loft(name + "_b", [(P(-0.10, 0, 0.06), 0.035, 0.04), (P(0.0, 0, 0.07), 0.05, 0.055), (P(0.09, 0, 0.06), 0.03, 0.03), (P(0.14, 0, 0.05), 0.008, 0.01)], M("ratfur", (104, 94, 100)), seg=8))
    rig_parts.append(cyl(name + "_t", P(-0.10, 0, 0.05), P(-0.28, 0.03, 0.02), 0.01, SKIN_PALE(), r1=0.003, seg=4))
    rig_parts.append(ellipsoid(name + "_e", P(0.105, 0.02, 0.08), (0.012, 0.012, 0.012), GLOW_RED()))
    return rig_parts

# =============================================================== arsenal epok: bron dluga na wspolnej kosci "weapon" (chwyty jak karabin)
LONG = ("musket", "shotgun", "smg", "mg", "crossbow", "lance")
for _k in LONG: WEAPON_BONES[_k] = WEAPON_BONES["rifle"]
WEAPON_BONES["pistol"] = [("weapon", (0.46, -0.13, 1.36), (0.60, -0.13, 1.36))]
WEAPON_BONES["knife"] = [("weapon", (0.16, -0.26, 0.86), (0.30, -0.26, 1.02))]
WEAPON_BONES["club"] = WEAPON_BONES["knife"]
WEAPON_BONES["machete"] = WEAPON_BONES["knife"]
BRASS_M = lambda: M("brass_w", (190, 150, 70))
LAMPGLOW = lambda: M("lampglow", (220, 240, 255), emit=(200, 230, 255), strength=8)
_base_build_weapon = build_weapon

def build_weapon(rig, name, pose):
    if pose not in LONG + ("pistol", "knife", "club", "machete"):
        return _base_build_weapon(rig, name, pose)
    A = rig.attach; W = "weapon"
    def tgt(n, loc, bone):
        e = empty(name + "_" + n, loc); A(e, bone); e.location = V(loc); rig.tg[n] = e; rig.tg_base[n] = V(loc); return e
    def keep(key, ob): rig.objs[key] = ob; return ob
    if pose in LONG:
        t = math.radians(8.2)
        D = V((math.cos(t), 0, -math.sin(t))); U = V((math.sin(t), 0, math.cos(t))); Y = V((0, 1, 0)); O = V((-0.03, -0.085, 1.318))
        G = lambda u, v=0.0, w=0.0: O + D * u + U * v + Y * w
        def bx(n, u0, u1, v, h, wdt, m, w=0.0, extra=0.0):
            return A(box(name + "_" + n, G((u0 + u1) / 2, v, w), (u1 - u0, wdt, h), m, rot=(0, t + extra, 0)), W)
        def cy(n, u0, u1, v, r, m, w=0.0, seg=6):
            return A(cyl(name + "_" + n, G(u0, v, w), G(u1, v, w), r, m, seg=seg), W)
        wood, met, dk = WOOD(), METAL(), METAL_D()
        if pose == "musket":       # czarny proch: dlugi skalkowy muszkiet
            bx("stock", 0.0, 0.40, -0.02, 0.11, 0.045, wood, extra=math.radians(6)); bx("fore", 0.40, 1.15, 0.0, 0.05, 0.04, wood)
            bx("lock", 0.40, 0.52, 0.02, 0.05, 0.05, dk); bx("hammer", 0.44, 0.48, 0.06, 0.05, 0.015, met)
            cy("barrel", 0.36, 1.48, 0.02, 0.014, dk); cy("rod", 0.5, 1.42, -0.02, 0.004, wood, seg=4)
            for k, u in enumerate((0.7, 1.05)): cy("band%d" % k, u, u + 0.02, 0.0, 0.03, BRASS_M())
            muz, ikl, ej = 1.50, 0.80, 0.46
        elif pose == "shotgun":    # obrzyn: dwie lufy, ucieta kolba
            bx("grip", 0.10, 0.32, -0.04, 0.09, 0.04, wood, extra=math.radians(18)); bx("recv", 0.32, 0.46, 0.0, 0.07, 0.05, dk)
            cy("b1", 0.44, 0.84, 0.02, 0.016, met, w=0.012); cy("b2", 0.44, 0.84, 0.02, 0.016, met, w=-0.012)
            bx("fore", 0.46, 0.66, -0.02, 0.04, 0.045, wood)
            muz, ikl, ej = 0.86, 0.56, 0.40
        elif pose == "smg":        # pistolet maszynowy: drutowa kolba, magazynek z boku/dolu, oslona lufy
            cy("st1", 0.02, 0.28, 0.0, 0.007, dk, seg=4); cy("st2", 0.02, 0.28, -0.06, 0.007, dk, seg=4); bx("butt", 0.0, 0.03, -0.03, 0.08, 0.02, dk)
            bx("body", 0.28, 0.62, 0.0, 0.06, 0.05, dk); bx("grip", 0.30, 0.36, -0.07, 0.10, 0.035, wood, extra=math.radians(14))
            keep("mag", bx("mag", 0.44, 0.48, -0.13, 0.20, 0.03, met))
            bx("shroud", 0.62, 0.86, 0.0, 0.045, 0.045, met)
            for k in range(4): bx("hole%d" % k, 0.65 + 0.05 * k, 0.67 + 0.05 * k, 0.0, 0.02, 0.05, dk)
            muz, ikl, ej = 0.88, 0.46, 0.50
        elif pose == "mg":         # karabin maszynowy: beben, gruby plaszcz lufy, dwojnog
            bx("stock", 0.0, 0.30, -0.01, 0.10, 0.05, wood); bx("body", 0.30, 0.78, 0.0, 0.09, 0.07, dk)
            keep("mag", A(loft(name + "_drum", [(G(0.52, -0.05, 0.035), 0.09, 0.09), (G(0.52, -0.05, -0.035), 0.09, 0.09)], met, seg=12), W))
            cy("jacket", 0.78, 1.20, 0.0, 0.03, dk, seg=8)
            for k in range(5): cy("fin%d" % k, 0.82 + 0.08 * k, 0.84 + 0.08 * k, 0.0, 0.038, met, seg=8)
            cy("barrel", 1.20, 1.40, 0.0, 0.012, met); bx("handle", 0.48, 0.64, 0.08, 0.02, 0.02, met)
            for s in (1, -1): A(cyl(name + "_bip%d" % s, G(1.12, -0.02, 0.0), G(0.86, -0.06, s * 0.03), 0.007, dk, seg=4), W)
            muz, ikl, ej = 1.42, 0.62, 0.58
        elif pose == "crossbow":   # kusza: luczysko w poprzek, cieciwa do orzecha
            bx("stock", 0.0, 0.78, -0.01, 0.06, 0.045, wood)
            arc = [(G(0.74 - 0.10 * (1 - math.cos(a)), 0.0, 0.34 * math.sin(a)), 0.014, 0.014) for a in (-1.2, -0.6, 0.0, 0.6, 1.2)]
            A(loft(name + "_prod", arc, METAL_D(), seg=6), W)
            tipL = G(0.74 - 0.10 * (1 - math.cos(1.2)), 0.0, 0.34 * math.sin(1.2)); tipR = G(0.74 - 0.10 * (1 - math.cos(1.2)), 0.0, -0.34 * math.sin(1.2))
            nut = G(0.40, 0.03)
            A(cyl(name + "_s1", tipL, nut, 0.003, M("string", (200, 200, 190)), seg=4), W); A(cyl(name + "_s2", tipR, nut, 0.003, M("string", (200, 200, 190)), seg=4), W)
            cy("bolt", 0.40, 0.92, 0.035, 0.006, wood, seg=4); cy("boltp", 0.92, 0.97, 0.035, 0.009, met, seg=4)
            bx("stirrup", 0.80, 0.86, 0.0, 0.09, 0.02, met)
            muz, ikl, ej = 0.95, 0.55, 0.40
        else:                      # lanca latarniowa (Swiatlo): rura z cewkami i soczewka
            bx("butt", 0.0, 0.32, -0.01, 0.10, 0.05, dk); bx("cell", 0.18, 0.40, 0.08, 0.08, 0.08, METAL())
            cy("tube", 0.32, 1.20, 0.0, 0.03, METAL(), seg=8)
            for k in range(4): A(cyl(name + "_coil%d" % k, G(0.55 + 0.15 * k, 0.0), G(0.575 + 0.15 * k, 0.0), 0.036, M("coil", (150, 200, 230), emit=(150, 210, 255), strength=2.5), seg=8), W)
            A(ellipsoid(name + "_lens", G(1.22, 0.0), (0.03, 0.05, 0.05), LAMPGLOW()), W)
            muz, ikl, ej = 1.24, 0.70, 0.30
        fl = A(cyl(name + "_beam", G(muz, 0.0), G(muz + 9.0, 0.0), 0.022, LAMPGLOW(), seg=6), W) if pose == "lance" else None
        if fl is not None: keep("flash", fl); fl.hide_render = True
        fl = ellipsoid(name + "_flash", G(muz + 0.06, 0.0), (0.10 if pose != "shotgun" else 0.16, 0.05, 0.05),
                       M("flashl" if pose == "lance" else "flashm", (220, 240, 255) if pose == "lance" else (255, 240, 190),
                         emit=(200, 230, 255) if pose == "lance" else (255, 230, 170), strength=14))
        if pose != "lance": keep("flash", A(fl, W))
        else: A(fl, W); keep("flash2", fl)
        fl.hide_render = True
        if "mag" not in rig.objs:
            keep("mag", A(box(name + "_magdummy", G(0.4, -0.02), (0.001, 0.001, 0.001), dk), W))
        hm = box(name + "_maghand", (0.02, 0.20, 0.80), (0.05, 0.03, 0.09), dk); keep("maghand", A(hm, "hand.L")); hm.hide_render = True
        e1 = empty(name + "_eject", G(ej, 0.03, -0.03)); A(e1, W); e1.location = G(ej, 0.03, -0.03); keep("eject", e1)
        e2 = empty(name + "_muzzle", G(muz, 0.0)); A(e2, W); e2.location = G(muz, 0.0); keep("muzzle", e2)
        rig.ik("forearm.R", tgt("ikR", G(0.29, -0.03, -0.02), W))
        rig.ik("forearm.L", tgt("ikL", G(ikl, -0.03, 0.01), W))
        rig.props["muzzle"] = tuple(G(muz))
    elif pose == "pistol":         # rewolwer jednoręczny
        O = V((0.46, -0.13, 1.36))
        A(box(name + "_pgrip", O + V((-0.01, 0, -0.05)), (0.035, 0.03, 0.09), WOOD(), rot=(0, math.radians(-16), 0)), W)
        A(box(name + "_pframe", O + V((0.03, 0, 0.0)), (0.07, 0.03, 0.04), METAL_D()), W)
        A(loft(name + "_pcyl", [(O + V((0.035, 0.0, 0.015)), 0.022, 0.022), (O + V((0.035, 0.0, 0.015)), 0.022, 0.022)], METAL(), seg=8), W)
        A(cyl(name + "_pcyl2", O + V((0.015, 0, 0.012)), O + V((0.06, 0, 0.012)), 0.02, METAL(), seg=8), W)
        A(cyl(name + "_pbar", O + V((0.06, 0, 0.018)), O + V((0.18, 0, 0.018)), 0.009, METAL_D(), seg=6), W)
        fl = ellipsoid(name + "_flash", O + V((0.23, 0, 0.018)), (0.07, 0.04, 0.04), M("flashm", (255, 240, 190), emit=(255, 230, 170), strength=14))
        rig.objs["flash"] = A(fl, W); fl.hide_render = True
        e1 = empty(name + "_eject", O + V((0.03, 0.02, 0.02))); A(e1, W); e1.location = O + V((0.03, 0.02, 0.02)); rig.objs["eject"] = e1
        e2 = empty(name + "_muzzle", O + V((0.18, 0, 0.018))); A(e2, W); e2.location = O + V((0.18, 0, 0.018)); rig.objs["muzzle"] = e2
        rig.ik("forearm.R", tgt("ikR", O, W))
    else:                          # bron jednoręczna wrecz: noz, rura, maczeta
        O = V((0.16, -0.26, 0.86)); d = (V((0.30, -0.26, 1.02)) - O).normalized()
        L = {"knife": 0.20, "club": 0.62, "machete": 0.50}[pose]
        A(cyl(name + "_hilt", O - d * 0.06, O + d * 0.06, 0.016, STRAP() if pose != "club" else METAL_D(), seg=6), W)
        if pose == "knife":
            A(loft(name + "_blade", [(O + d * 0.06, 0.006, 0.02), (O + d * L, 0.002, 0.003)], METAL(), seg=4), W)
        elif pose == "club":
            A(cyl(name + "_pipe", O + d * 0.06, O + d * L, 0.02, RUST(), seg=6), W)
            A(cyl(name + "_joint", O + d * (L - 0.06), O + d * (L + 0.02), 0.032, METAL_D(), seg=6), W)
            for k in range(3): A(loft(name + "_nail%d" % k, [(O + d * (L - 0.04 * k), 0.004, 0.004), (O + d * (L - 0.04 * k) + V((0.0, 0.0, 0.0)) + V((0.05 * math.cos(2.1 * k), 0.05 * math.sin(2.1 * k), 0)), 0.001, 0.001)], METAL(), seg=4), W)
        else:
            A(loft(name + "_blade", [(O + d * 0.06, 0.006, 0.035), (O + d * (L - 0.08), 0.005, 0.045), (O + d * L, 0.002, 0.01)], METAL(), seg=4), W)
        rig.ik("forearm.R", tgt("ikR", O, W))

# =============================================================== narzedzia pracy w osadzie
WEAPON_BONES["axe"] = WEAPON_BONES["hammer"]
WEAPON_BONES["shovel"] = [("weapon", (0.24, -0.16, 1.00), (0.40, -0.14, 0.70))]
WEAPON_BONES["carry"] = [("weapon", (0.30, 0.0, 1.05), (0.30, 0.0, 1.30))]
WEAPON_BONES["smith"] = [("weapon", (0.30, -0.20, 1.05), (0.50, -0.20, 1.05))]
_build2 = build_weapon
def build_weapon(rig, name, pose):
    if pose not in ("axe", "shovel", "carry", "smith"): return _build2(rig, name, pose)
    A = rig.attach; W = "weapon"
    def tgt(n, loc, bone):
        e = empty(name + "_" + n, loc); A(e, bone); e.location = V(loc); rig.tg[n] = e; rig.tg_base[n] = V(loc); return e
    if pose == "axe":
        A(cyl(name + "_haft", (0.26, -0.12, 1.02), (-0.24, -0.16, 1.72), 0.018, WOOD(), seg=6), W)
        A(loft(name + "_axeh", [((-0.22, -0.16, 1.70), 0.012, 0.05), ((-0.33, -0.16, 1.66), 0.006, 0.08)], METAL(), seg=4), W)
        rig.ik("forearm.R", tgt("ikR", (0.20, -0.125, 1.10), W)); rig.ik("forearm.L", tgt("ikL", (0.06, -0.14, 1.30), W))
    elif pose == "shovel":
        d = (V((0.40, -0.14, 0.70)) - V((0.24, -0.16, 1.00))).normalized()
        top = V((0.24, -0.16, 1.00)) - d * 0.35; blade = V((0.24, -0.16, 1.00)) + d * 0.80
        A(cyl(name + "_shaft", top, blade, 0.017, WOOD(), seg=6), W)
        A(box(name + "_grip", top, (0.03, 0.12, 0.03), WOOD()), W)
        A(box(name + "_blade", blade + d * 0.11, (0.20, 0.18, 0.02), METAL_D(), rot=(0, math.atan2(d.x, d.z) + math.pi / 2, 0)), W)
        rig.ik("forearm.L", tgt("ikL", top + d * 0.03, W)); rig.ik("forearm.R", tgt("ikR", V((0.24, -0.16, 1.00)) + d * 0.25, W))
    elif pose == "carry":
        A(box(name + "_crate", (0.34, 0.0, 1.06), (0.36, 0.44, 0.30), WOOD()), W)
        for z in (0.95, 1.17): A(box(name + "_slat%.2f" % z, (0.525, 0.0, z), (0.01, 0.44, 0.04), M("wood_d", (80, 56, 36))), W)
        rig.ik("forearm.L", tgt("ikL", (0.30, 0.23, 1.02), W)); rig.ik("forearm.R", tgt("ikR", (0.30, -0.23, 1.02), W))
    else:   # kowal: mlotek w prawej, szczypce z pretem w lewej
        A(cyl(name + "_hh", (0.30, -0.20, 1.05), (0.56, -0.20, 1.08), 0.014, WOOD(), seg=6), W)
        A(box(name + "_hhead", (0.58, -0.20, 1.08), (0.05, 0.05, 0.12), METAL()), W)
        A(cyl(name + "_tong", (0.32, 0.20, 0.98), (0.66, 0.06, 0.86), 0.01, METAL_D(), seg=4), "hand.L")
        A(cyl(name + "_bar", (0.64, 0.07, 0.86), (0.80, 0.0, 0.85), 0.014, M("hotiron", (255, 140, 60), emit=(255, 110, 40), strength=5), seg=5), "hand.L")
        rig.ik("forearm.R", tgt("ikR", (0.30, -0.20, 1.05), W))

# Ogar to zwykly pies lekko zmieniony przez Mgle (decyzja z 6 listopada); stary chitynowy model zostaje jako ogar_chityna.
ogar_chityna = ogar
def ogar(name):
    import mutants2
    return mutants2.quadruped(name, "pies")
