"""Test modelowania: wszystkie postacie w rzedzie, swiatlo kluczowe + chlodne wypelnienie."""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *

CX, CY, ORT, OUTP = [float(a) if i < 3 else a for i, a in enumerate(sys.argv[sys.argv.index("--") + 1:])] if "--" in sys.argv else (0, -1.2, 21, "/home/claude/latarnia3d/out/test_chars.exr")
reset()
setup_render(samples=24)
world((40, 34, 60), 0.35)
g = mat("ground", (60, 56, 66), pass_index=1)
box("ground", (0, 0, -0.05), (40, 20, 0.1), g, pass_index=1)
sun("key", (math.radians(50), 0, math.radians(-35)), (1.0, 0.86, 0.66), 2.6)
sun("fill", (math.radians(60), 0, math.radians(150)), (0.55, 0.65, 1.0), 0.7)

outfits = [
    ("cywil", dict(jacket="brown", pants="brown", beard=True, strap=False), "idle"),
    ("dzidnik", dict(jacket="leather", pants="brown", helmet="pot"), "spear"),
    ("tarcz", dict(jacket="grey", pants="darkgrey", armor="plate", helmet="pot"), "spear"),
    ("lucznik", dict(jacket="olive", pants="brown", hair="hair_l"), "bow"),
    ("lamacz", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True), "hammer"),
    ("strzelec", dict(jacket="olive", pants="olive", helmet="mil"), "rifle"),
    ("zwiad", dict(jacket="teal", pants="darkgrey", mask="gas"), "rifle"),
    ("chorazy", dict(jacket="blue", pants="blue", helmet="mil"), "banner"),
    ("mutant", dict(skin="pale", jacket="brown", pants="brown", third_arm=True, glow_eyes=True, strap=False), "idle"),
]
for i, (n, o, pose) in enumerate(outfits):
    r = human(n, o, pose)
    stand_pose(r, arms=(pose in ("idle", "banner")))
    r.place((-8 + i * 2.0, 0, 0), -28)
og = ogar("ogar"); ogar_pose(og, 1); og.place((-6, -3.2, 0), -25)
kz = krzykacz("krz"); krzykacz_pose(kz, 0); kz.place((-2.5, -3.2, 0), -25)
ns = nosiciel("nos"); stand_pose(ns); ns.place((0.5, -3.2, 0), -25)
rozrost("roz", (4.2, -3.4, 0.5))
for k in range(5): rat("rat%d" % k, (7 + 0.4 * k, -3.3 + 0.2 * (k % 2), 0), math.radians(160))
camera((CX, CY, 0.9), 52, ORT, (480, 220))
render(OUTP)
