import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import ogar
import anim as A, mutanim as MA
reset(); setup_render(samples=6)
world((60, 56, 70), 0.6)
box("ground", (0, 0, -0.05), (60, 60, 0.1), mat("ground", (70, 66, 72), pass_index=1), pass_index=1)
sun("key", (math.radians(46), 0, math.radians(-60)), (1.0, 0.9, 0.8), 3.0)
CAMYAW = -25; cy = math.radians(CAMYAW); YAW = CAMYAW
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
rows = [("gal", MA.ogar_gallop, [0, 1, 2, 3, 4, 5]), ("pou", MA.clip_ogar_pounce().sample, [0, 5, 8, 10, 13, 16])]
for r, (nm, fn, frs) in enumerate(rows):
    for c, f in enumerate(frs):
        rig = ogar("%s%d" % (nm, c))
        loc = RIGHT * ((c - 2.5) * 2.2) + FWD * ((0.5 - r) * 2.2)
        p = fn(f)
        if nm == "pou": p["root"] = (0,) + tuple(p["root"][1:])
        A.apply(rig, p, tuple(loc), YAW)
camera((0, 0, 0.5), 60, 14, (1120, 400), yaw_deg=CAMYAW)
render("/home/claude/latarnia3d/out/mutsheet.exr")
