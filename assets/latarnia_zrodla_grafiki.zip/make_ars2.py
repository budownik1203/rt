import sys; sys.path.insert(0, '/home/claude/latarnia3d')
from make_seq import build
R = [["Rura z gwoździami", "Maczeta", "Nóż", "Dzida i tarcza", "Łuk", "Kusza", "Młot"],
     ["Muszkiet", "Obrzyn", "Rewolwer", "Karabin", "Pistolet masz.", "Karabin masz.", "Lanca latarniowa"]]
E = [["Złom", "Złom", "Złom", "Kuźnia", "Kuźnia", "Kuźnia", "Kuźnia"], ["Czarny proch", "Czarny proch", "Nabój", "Nabój", "Silnik", "Silnik", "Światło"]]
labs = []
for ri in range(2):
    for ci in range(7):
        labs.append((R[ri][ci], (ci - 3) * 1.75 - 0.75, (0.5 - ri) * 3.3, 26))
        labs.append((E[ri][ci], (ci - 3) * 1.75 - 0.75, (0.5 - ri) * 3.3, 44))
fr = build("ars", 16, 640, 360, 13.0, 0.8, labs, "out/latarnia3d_arsenal.gif", dur=100, S=3)
fr[6].save("out/latarnia3d_arsenal.png")
