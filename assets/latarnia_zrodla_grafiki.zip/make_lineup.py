import sys, math, json
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
W, H, ORT, T = 960, 640, 8.6, math.radians(50)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 15)
fb = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 19)
for S in [int(a) for a in sys.argv[1:]]:
    im = stylize('out/lineup_%d.exr' % S).resize((W * 2, H * 2), Image.NEAREST); d = ImageDraw.Draw(im)
    done = set()
    for fname, uname, x, y in json.load(open('out/lineup_%d.json' % S)):
        px = (W / 2 + x * W / ORT) * 2; py = (H / 2 - (y * math.cos(T) - 0.9 * math.sin(T)) * W / ORT) * 2 + 30
        w = d.textlength(uname, font=font)
        d.rectangle((px - w / 2 - 4, py - 2, px + w / 2 + 4, py + 18), fill=(20, 17, 28)); d.text((px - w / 2, py - 1), uname, font=font, fill=(226, 200, 150))
        if fname not in done:
            done.add(fname); fy = py - 150
            d.text((40, fy), fname, font=fb, fill=(240, 220, 180))
    im.save('out/latarnia3d_frakcje_%d.png' % (S + 1))
