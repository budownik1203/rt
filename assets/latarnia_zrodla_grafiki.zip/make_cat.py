import sys, math, json
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
W, H, ORT, T = 960, 620, 31, math.radians(52)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 13)
for S in [int(a) for a in sys.argv[1:]]:
    im = stylize('out/cat_%d.exr' % S)
    im = im.resize((W * 2, H * 2), Image.NEAREST); d = ImageDraw.Draw(im)
    for name, x, y in json.load(open('out/cat_%d.json' % S)):
        px = (W / 2 + x * W / ORT) * 2; py = (H / 2 - (y * math.cos(T) - 2.0 * math.sin(T)) * W / ORT) * 2 + 70
        w = d.textlength(name, font=font)
        d.rectangle((px - w / 2 - 4, py - 2, px + w / 2 + 4, py + 15), fill=(20, 17, 28)); d.text((px - w / 2, py - 1), name, font=font, fill=(226, 200, 150))
    im.save('out/latarnia3d_budynki_%d.png' % (S + 1))
