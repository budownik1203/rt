import sys, math
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
W, H, ORT, T = 640, 320, 16.5, math.radians(50)
NAMES = [["Ogar: galop", "Ogar: skok i ugryzienie", "Ogar: śmierć", "Szczury: rój", "Krzykacz: śmierć"],
         ["Krzykacz: chód", "Krzykacz: krzyk", "Krzykacz: cięcie", "Nosiciel: chód", "Nosiciel: wybuch"]]
COLS = [-5.6, -2.8, 0.0, 2.8, 5.6]; ROWS = [1.9, -1.9]
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 13)
def label(im):
    d = ImageDraw.Draw(im)
    for ri, row in enumerate(NAMES):
        for ci, n in enumerate(row):
            x = (W / 2 + COLS[ci] * W / ORT) * 2; y = (H / 2 - (ROWS[ri] * math.cos(T) - 0.7 * math.sin(T)) * W / ORT) * 2 + 22
            w = d.textlength(n, font=font)
            d.rectangle((x - w / 2 - 4, y - 2, x + w / 2 + 4, y + 15), fill=(20, 17, 28)); d.text((x - w / 2, y - 1), n, font=font, fill=(226, 200, 150))
    return im
fr = [label(stylize('out/mut_%02d.exr' % f).resize((W * 2, H * 2), Image.NEAREST)) for f in range(24)]
fr[0].save('out/latarnia3d_mutanty.gif', save_all=True, append_images=fr[1:], duration=83, loop=0)
for k in (5, 10, 14, 20): fr[k].save('out/mutchk_%02d.png' % k)
