"""11 frakcji ludzkich w docelowych barwach i ze znakami: po 7-8 jednostek (w tym chorazy ze sztandarem).
python3 factions2.py -- KLUCZ_FRAKCJI [SAMPLES]   ->  out/frakcja_<klucz>.exr"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
import bpy, bmesh
from mathutils import Vector as V
from lat3d import *
import lat3d
import chars
from chars import human, M, METAL, METAL_D, WOOD, STRAP
import factions as FC
import anim as A
from emblems import PAL

TEX = "/home/claude/latarnia3d/tex"
chars.CLOTH.update({
    "f_rust": (112, 66, 44), "f_yellow": (150, 128, 62), "f_white": (196, 190, 176), "f_red": (132, 36, 36), "f_violet": (92, 80, 112),
    "f_bone": (198, 176, 162), "f_soot": (44, 42, 46), "f_brass": (138, 110, 62), "f_swamp": (62, 74, 48), "f_navy": (46, 56, 94),
    "f_ochre": (148, 116, 62), "f_moss": (66, 80, 50), "f_steel": (90, 96, 106), "f_turq": (52, 128, 122), "f_warn": (176, 92, 36),
    "f_salt": (204, 200, 190), "f_sblue": (62, 90, 134), "f_oliveb": (80, 88, 56), "f_flesh": (150, 100, 96),
})

def tex_mat(key):
    name = "emb_" + key
    if name in lat3d.MATS: return lat3d.MATS[name]
    m = bpy.data.materials.new(name); m.use_nodes = True; nt = m.node_tree
    b = nt.nodes["Principled BSDF"]; b.inputs["Roughness"].default_value = 1.0
    t = nt.nodes.new("ShaderNodeTexImage"); t.image = bpy.data.images.load(TEX + "/emblem_%s.png" % key); t.interpolation = "Closest"
    nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
    m.pass_index = 3; lat3d.MATS[name] = m
    return m

def quad(name, c, u, v, w, h, mt, flip=False):
    """Prostokat z UV (u - os pozioma obrazka, v - pionowa)."""
    c, u, v = V(c), V(u).normalized(), V(v).normalized()
    bm = bmesh.new(); uv = bm.loops.layers.uv.new()
    ps = [c - u * w / 2 - v * h / 2, c + u * w / 2 - v * h / 2, c + u * w / 2 + v * h / 2, c - u * w / 2 + v * h / 2]
    vs = [bm.verts.new(p) for p in ps]
    f = bm.faces.new(vs if not flip else vs[::-1])
    uvs = [(0, 0), (1, 0), (1, 1), (0, 1)]
    for lp, (vv, uvv) in zip(f.loops, zip(vs if not flip else vs[::-1], uvs if not flip else uvs[::-1])): lp[uv].uv = uvv
    return lat3d.bm_obj(name, bm, mt, False, 3)

# ------------------------------------------------------------------ oznaczenia na postaci
def chest_patch(r, n, key, s=0.16, x=0.18):
    r.attach(quad(n + "_patch", (x, 0.065, 1.32), (0, 1, 0), (0, 0, 1), s, s, tex_mat(key)), "chest")
def tabard(r, n, key, col, x=0.2):
    r.attach(quad(n + "_tabard", (x, 0.0, 1.20), (0, 1, 0), (0, 0, 1), 0.26, 0.38, M("tab_" + key, col)), "chest")
    r.attach(quad(n + "_tabemb", (x + 0.004, 0.0, 1.24), (0, 1, 0), (0, 0, 1), 0.2, 0.2, tex_mat(key)), "chest")
    r.attach(quad(n + "_tablo", (x - 0.02, 0.0, 0.88), (0, 1, 0), (0.25, 0, 1), 0.24, 0.30, M("tab_" + key, col)), "spine")
def flag(r, n, key, flip_upside=False):
    for k in ("_flag", "_emblem"):
        if n + k in bpy.data.objects: bpy.data.objects[n + k].hide_render = True
    vv = (0, 0, -1) if flip_upside else (0, 0, 1)
    r.attach(quad(n + "_fl1", (0.52, -0.232, 2.48), (1, 0, 0), vv, 0.56, 0.44, tex_mat(key), flip=True), "weapon")
    r.attach(quad(n + "_fl2", (0.52, -0.248, 2.48), (1, 0, 0), vv, 0.56, 0.44, tex_mat(key)), "weapon")
def shield_emb(r, n, key):
    if n + "_boss" in bpy.data.objects: bpy.data.objects[n + "_boss"].hide_render = True
    r.attach(quad(n + "_shemb", (0.36, 0.10, 1.15), (0, 1, 0), (0, 0, 1), 0.40, 0.40, tex_mat(key)), "shield")
def no_shield(r, n):
    for k in ("_shield", "_boss", "_shrim"):
        if n + k in bpy.data.objects: bpy.data.objects[n + k].hide_render = True
def bell(r, n):
    FC.hand_prop(r, [loft(n + "_bell", [((0, 0, -0.04), 0.03, 0.03), ((0, 0, -0.12), 0.06, 0.06), ((0, 0, -0.16), 0.075, 0.075)], M("bronze", (150, 110, 60)), seg=10)], rot=(0, 0, 0))
def whip(r, n):
    FC.hand_prop(r, [loft(n + "_whip", [((0, 0, 0), 0.02, 0.02), ((0, 0, -0.35), 0.015, 0.015), ((0.15, 0, -0.75), 0.006, 0.006), ((0.35, 0.1, -0.85), 0.004, 0.004)], M("whip", (70, 50, 36)), seg=4)], rot=(0, 0, 0))
def spore_sac(r, n):
    r.attach(ellipsoid(n + "_sac", (-0.22, 0, 1.25), (0.15, 0.2, 0.22), M("sac", (150, 160, 80), emit=(140, 170, 50), strength=1.5)), "chest")
    for k in range(5):
        a = k * 1.25
        r.attach(ellipsoid(n + "_pus%d" % k, (-0.30 + 0.06 * math.cos(a), 0.13 * math.sin(a), 1.25 + 0.1 * math.cos(a * 2)), (0.03, 0.03, 0.03), M("pus", (230, 240, 120), emit=(200, 230, 80), strength=4)), "chest")
def glow_tip(r, n, col):
    for o in list(r.parts):
        if o.name.endswith("_joint") or o.name.endswith("_pipe"): o.data.materials.clear(); o.data.materials.append(M("glowtip_" + str(col), col, emit=col, strength=4))
def big_lamp(r, n):
    FC.lantern_pole(r, n)
    r.attach(loft(n + "_refl", [((-0.04, 0.06, 2.04), 0.06, 0.06), ((0.06, 0.06, 2.04), 0.11, 0.11)], METAL_D(), seg=10, cap=False), "chest")
    r.attach(quad(n + "_lens", (0.065, 0.06, 2.04), (0, 1, 0), (0, 0, 1), 0.17, 0.17, M("lens_b", (230, 245, 255), emit=(210, 240, 255), strength=10)), "chest")
def redcross(r, n):
    r.attach(loft(n + "_armw", [((-0.02, 0.2, 1.30), 0.057, 0.057), ((-0.022, 0.2, 1.25), 0.057, 0.057)], M("white_b", (210, 206, 196))), "upperarm.L")
    r.attach(box(n + "_rc1", (0.035, 0.257, 1.275), (0.012, 0.004, 0.04), M("red_x", (170, 30, 30))), "upperarm.L")
    r.attach(box(n + "_rc2", (0.035, 0.257, 1.275), (0.04, 0.004, 0.012), M("red_x", (170, 30, 30))), "upperarm.L")

# ------------------------------------------------------------------ jednostki: (etykieta, poza, ubior, dodatki)
def O(j, p, **kw): d = dict(jacket=j, pants=p); d.update(kw); return d
H = FC
UNITS = {
 "szabrownicy": [("Obdartus", "club", O("f_rust", "brown", strap=False), [lambda r, n: H.scarf_mask(r, n, M("rag_y", (150, 128, 62)))]),
                 ("Nożownik", "knife", O("leather", "darkgrey", hair="hair"), [lambda r, n: H.skulls_belt(r, n)]),
                 ("Obrzyn", "shotgun", O("f_rust", "darkgrey", beard=True), [lambda r, n: H.hat_wide(r, n, M("hat_b", (70, 56, 46))), H.bandolier]),
                 ("Butelkarz", "grenade", O("brown", "f_rust"), [lambda r, n: H.cap(r, n, M("cap_y", (150, 128, 62)))]),
                 ("Rozbijacz", "hammer", O("f_rust", "darkgrey", armor="plate", beard=True), [H.shoulder_spikes]),
                 ("Psiarz", "machete", O("leather", "brown"), [H.chains]),
                 ("Herszt", "rifle", O("leather", "darkgrey", armor="plate", beard=True), [lambda r, n: H.cape(r, n, M("cape_r", (112, 66, 44)), fur=M("fur", (120, 100, 80))), H.shoulder_spikes]),
                 ("Chorąży", "banner", O("f_rust", "brown"), [])],
 "synowie": [("Pokutnik", "hammer", O("grey", "darkgrey", strap=False, pouches=False), [H.pale_chest, lambda r, n: H.hood(r, n, M("hood_w", (196, 190, 176))), H.chains]),
             ("Akolita", "spear", O("f_white", "darkgrey", helmet="pot"), ["shield"]),
             ("Strzelec Czystości", "musket", O("f_white", "darkgrey"), [lambda r, n: H.hood(r, n, M("hood_w", (196, 190, 176)))]),
             ("Płomieniarz", "rifle", O("f_white", "grey", mask="gas", armor="vest"), [H.tanks, "flamer"]),
             ("Kat", "axe", O("f_red", "darkgrey", strap=False), [lambda r, n: H.hood(r, n, M("hood_r", (132, 36, 36)))]),
             ("Templariusz", "machete", O("f_white", "darkgrey", armor="plate"), [H.iron_mask, lambda r, n: H.cape(r, n, M("cape_w", (196, 190, 176))), "tabard"]),
             ("Egzorcysta", "idle", O("f_white", "darkgrey"), [lambda r, n: H.robe(r, n, M("robe_w", (196, 190, 176))), bell]),
             ("Inkwizytor", "banner", O("grey", "darkgrey"), [lambda r, n: H.robe(r, n, M("robe_w", (196, 190, 176))), H.iron_mask, lambda r, n: H.cape(r, n, M("cape_r", (132, 36, 36)))])],
 "chor": [("Wierny", "knife", O("f_violet", "brown", skin="pale", glow_eyes=True, strap=False), []),
          ("Odmieniony Wierny", "club", O("f_violet", "brown", skin="pale", third_arm=True, glow_eyes=True, strap=False), []),
          ("Śpiewak", "idle", O("f_violet", "darkgrey", skin="pale"), [lambda r, n: H.robe(r, n, M("robe_v", (92, 80, 112))), lambda r, n: H.hood(r, n, M("hood_b", (198, 176, 162)))]),
          ("Niosący Zarodnik", "idle", O("f_violet", "brown", skin="pale", glow_eyes=True), [spore_sac]),
          ("Sługa w tkance", "machete", O("f_flesh", "f_flesh", skin="pale", glow_eyes=True, strap=False), []),
          ("Kapłan", "spear", O("f_violet", "darkgrey"), [lambda r, n: H.robe(r, n, M("robe_v", (92, 80, 112))), lambda r, n: H.hood(r, n, M("hood_v", (80, 68, 98))), lambda r, n: H.staff(r, n, M("orb_g", (150, 230, 160), emit=(120, 230, 140), strength=5))]),
          ("Pasterz Chóru", "spear", O("darkgrey", "darkgrey", skin="pale", glow_eyes=True), [lambda r, n: H.robe(r, n, M("robe_b", (198, 176, 162)), 0.1), lambda r, n: H.horns(r, n, M("horn", (190, 180, 150))), lambda r, n: H.staff(r, n, M("orb_r", (255, 90, 70), emit=(255, 60, 40), strength=5))]),
          ("Chorąży Chóru", "banner", O("f_violet", "brown", skin="pale"), [lambda r, n: H.hood(r, n, M("hood_b", (198, 176, 162)))])],
 "tor": [("Konwojent", "rifle", O("f_soot", "brown"), [lambda r, n: H.cap(r, n, M("cap_s", (44, 42, 46))), H.goggles, lambda r, n: H.backpack(r, n, M("pack", (90, 80, 56)))]),
         ("Hamulcowy", "shotgun", O("f_soot", "darkgrey", beard=True), [lambda r, n: H.cap(r, n, M("cap_br", (138, 110, 62)))]),
         ("Palacz", "shovel", O("f_soot", "f_soot", strap=False), [H.goggles]),
         ("Kaemista z wagonu", "mg", O("f_soot", "brown", armor="vest"), [H.bandolier]),
         ("Zwiadowca drezyny", "smg", O("leather", "f_soot"), [H.goggles, lambda r, n: H.scarf_mask(r, n, M("rag_s", (60, 56, 52)))]),
         ("Najemnik Toru", "rifle", O("f_brass", "darkgrey", armor="vest", helmet="mil"), []),
         ("Maszynista", "idle", O("f_soot", "f_soot", beard=True), [lambda r, n: H.cap(r, n, M("cap_k", (40, 40, 48))), H.goggles, "tabard"]),
         ("Chorąży", "banner", O("f_soot", "brown"), [])],
 "lowcy": [("Sieciarz", "spear", O("f_swamp", "brown", strap=False), ["noshield", H.net_bundle, lambda r, n: H.scarf_mask(r, n, M("rag_d", (70, 64, 60)))]),
           ("Łowca", "crossbow", O("leather", "f_swamp"), [H.skull_mask, lambda r, n: H.cape(r, n, M("cape_l", (90, 70, 50)), fur=M("fur_d", (90, 76, 62)))]),
           ("Ogłuszacz", "club", O("f_swamp", "darkgrey", beard=True), []),
           ("Tropiciel", "bow", O("f_swamp", "brown"), [lambda r, n: H.hood(r, n, M("hood_s", (62, 74, 48)))]),
           ("Poganiacz", "idle", O("brown", "darkgrey", armor="plate"), [H.skull_mask, H.chains, whip]),
           ("Herszt Łowców", "machete", O("f_swamp", "darkgrey", armor="plate"), [H.skull_mask, lambda r, n: H.cape(r, n, M("cape_rr", (132, 36, 36)), fur=M("fur", (120, 100, 80)))]),
           ("Chorąży", "banner", O("f_swamp", "brown"), [])],
 "zakon": [("Kadet", "rifle", O("f_navy", "darkgrey"), []),
           ("Strzelec Zakonu", "rifle", O("f_navy", "darkgrey", helmet="mil", armor="plate"), []),
           ("Tarczownik Zakonu", "spear", O("f_navy", "darkgrey", helmet="mil", armor="plate"), ["shield"]),
           ("Sygnalista", "pistol", O("f_navy", "darkgrey", helmet="mil"), [H.lantern_pole]),
           ("Inżynier", "smg", O("f_navy", "darkgrey", mask="gas"), [lambda r, n: H.backpack(r, n, M("pack_n", (60, 66, 80)))]),
           ("Latarnik bojowy", "lance", O("f_navy", "darkgrey", helmet="mil", mask="gas", armor="plate"), [H.lantern_pole]),
           ("Oficer", "banner", O("f_navy", "darkgrey", helmet="mil", armor="plate"), [lambda r, n: H.cape(r, n, M("cape_n", (40, 50, 92)))])],
 "dezerterzy": [("Strzelec", "rifle", O("olive", "brown", beard=True), [lambda r, n: H.scarf_mask(r, n, M("rag_o", (80, 86, 60)))]),
                ("Tarczownik", "spear", O("olive", "brown", helmet="pot"), ["shield"]),
                ("Szturmowiec", "smg", O("f_oliveb", "brown", helmet="mil"), [lambda r, n: H.backpack(r, n, M("pack_r", (80, 70, 54)))]),
                ("Sanitariusz", "pistol", O("olive", "brown"), [redcross, lambda r, n: H.backpack(r, n, M("pack_r", (80, 70, 54)))]),
                ("Snajper", "rifle", O("f_oliveb", "brown"), [lambda r, n: H.hood(r, n, M("hood_o", (80, 88, 56)))]),
                ("Chorąży", "banner", O("olive", "brown", beard=True), ["upside"])],
 "bunkier": [("Szeregowiec w masce", "rifle", O("f_oliveb", "f_oliveb", helmet="mil", mask="gas"), []),
             ("Kaemista", "mg", O("f_oliveb", "f_oliveb", helmet="mil", mask="gas", armor="vest"), [H.bandolier]),
             ("Snajper", "rifle", O("f_oliveb", "f_oliveb", mask="gas"), [lambda r, n: H.hood(r, n, M("hood_ob", (80, 88, 56)))]),
             ("Saper", "grenade", O("f_oliveb", "f_oliveb", helmet="mil"), [lambda r, n: H.backpack(r, n, M("pack_w", (176, 92, 36)))]),
             ("Medyk", "pistol", O("f_oliveb", "f_oliveb", mask="gas"), [redcross]),
             ("Pancerny", "smg", O("f_warn", "f_oliveb", helmet="mil", mask="gas", armor="plate"), [H.tanks]),
             ("Sierżant", "pistol", O("f_oliveb", "f_oliveb", armor="vest"), [lambda r, n: H.cap(r, n, M("cap_ob", (70, 78, 50))), "tabard"]),
             ("Chorąży", "banner", O("f_oliveb", "f_oliveb", helmet="mil", mask="gas"), [])],
 "gildia": [("Strażnik karawany", "spear", O("f_salt", "f_sblue", helmet="pot"), ["shield"]),
            ("Pikinier karawany", "spear", O("f_sblue", "brown", helmet="pot"), ["noshield"]),
            ("Kusznik Gildii", "crossbow", O("f_salt", "f_sblue"), [lambda r, n: H.hat_wide(r, n, M("hat_s", (62, 90, 134)))]),
            ("Najemnik", "rifle", O("leather", "darkgrey", armor="vest", beard=True), [H.bandolier]),
            ("Zabójca", "knife", O("darkgrey", "darkgrey"), [lambda r, n: H.hood(r, n, M("hood_d", (50, 50, 58))), lambda r, n: H.scarf_mask(r, n, M("rag_b", (62, 90, 134)))]),
            ("Poganiacz wołów", "club", O("f_salt", "brown", strap=False), [lambda r, n: H.hat_wide(r, n, M("hat_b", (70, 56, 46)))]),
            ("Faktor", "pistol", O("f_sblue", "darkgrey", beard=True), [lambda r, n: H.hat_wide(r, n, M("hat_s", (62, 90, 134))), lambda r, n: H.cape(r, n, M("cape_s", (204, 200, 190))), "tabard"]),
            ("Chorąży", "banner", O("f_salt", "f_sblue"), [])],
 "las": [("Łucznik", "bow", O("f_moss", "brown"), [lambda r, n: H.hood(r, n, M("hood_m", (66, 80, 50)))]),
         ("Traper", "axe", O("leather", "f_moss", beard=True), [lambda r, n: H.hat_wide(r, n, M("hat_m", (90, 80, 56))), lambda r, n: H.backpack(r, n, M("pack_m", (90, 80, 56)))]),
         ("Oszczepnik", "spear", O("f_moss", "f_ochre"), ["noshield"]),
         ("Zwiadowca z psem", "knife", O("f_moss", "brown", hair="hair_l"), []),
         ("Strzelec z muszkietem", "musket", O("f_ochre", "brown"), [lambda r, n: H.hood(r, n, M("hood_m", (66, 80, 50)))]),
         ("Strażnik Gaju", "axe", O("f_moss", "f_moss", armor="plate", beard=True), [lambda r, n: H.horns(r, n, M("antler", (150, 116, 62)))]),
         ("Szaman", "spear", O("f_ochre", "brown", beard=True), [lambda r, n: H.robe(r, n, M("robe_m", (66, 80, 50))), lambda r, n: H.horns(r, n, M("antler", (150, 116, 62))), lambda r, n: H.staff(r, n, M("orb_a", (230, 190, 100), emit=(230, 170, 60), strength=4))]),
         ("Chorąży", "banner", O("f_moss", "brown"), [])],
 "tama": [("Milicjant", "rifle", O("f_steel", "darkgrey"), [lambda r, n: H.cap(r, n, M("cap_t", (52, 128, 122)))]),
          ("Elektryk", "club", O("f_steel", "darkgrey", mask="gas"), [H.goggles, lambda r, n: glow_tip(r, n, (90, 230, 220))]),
          ("Strzelec", "rifle", O("f_steel", "darkgrey", helmet="mil"), []),
          ("Operator reflektora", "pistol", O("f_steel", "darkgrey", helmet="mil"), [big_lamp]),
          ("Inżynier", "smg", O("f_turq", "darkgrey"), [H.goggles, lambda r, n: H.backpack(r, n, M("pack_t", (70, 76, 86)))]),
          ("Gwardzista Tamy", "mg", O("f_steel", "f_steel", helmet="mil", armor="plate", mask="gas"), []),
          ("Komisarz", "pistol", O("f_turq", "darkgrey"), [lambda r, n: H.cap(r, n, M("cap_c", (40, 44, 52))), lambda r, n: H.cape(r, n, M("cape_c", (40, 44, 52))), "tabard"]),
          ("Chorąży", "banner", O("f_steel", "darkgrey", helmet="mil"), [])],
}
TITLES = {"szabrownicy": "Szabrownicy", "synowie": "Synowie Czystości", "chor": "Chór Mgły", "tor": "Ludzie Toru", "lowcy": "Łowcy Głów",
          "zakon": "Zakon Latarników", "dezerterzy": "Dezerterzy", "bunkier": "Bractwo Bunkra", "gildia": "Gildia Solna", "las": "Dzieci Lasu", "tama": "Republika Tamy"}

def build_unit(key, i, label, pose, outfit, acc):
    n = "%s%d" % (key, i)
    r = human(n, outfit, pose)
    for a in acc:
        if a == "shield": shield_emb(r, n, key)
        elif a == "noshield": no_shield(r, n)
        elif a == "tabard": tabard(r, n, key, PAL[key][0], x=0.25 if outfit.get("armor") else 0.22)
        elif a == "flamer":
            objs = FC.WP.miotacz()
            for o in objs[:6]: bpy.data.objects.remove(o, do_unlink=True)
            FC.swap_rifle(r, n, objs[6:])
        elif a == "upside": pass
        else: a(r, n)
    HELM = {"zakon": (46, 56, 94), "synowie": (190, 184, 170), "tor": (50, 48, 52), "tama": (90, 96, 106), "gildia": (62, 90, 134), "chor": (92, 80, 112)}
    for o in list(r.parts):
        if key in HELM and (o.name.startswith(n + "_helm")):
            o.data.materials.clear(); o.data.materials.append(M("helm_" + key, HELM[key]))
        if o.name in (n + "_shield", n + "_shrim"):
            o.data.materials.clear(); o.data.materials.append(M("shield_" + key, PAL[key][0]))
    if pose == "banner": flag(r, n, key, flip_upside="upside" in acc)
    elif "tabard" not in acc: chest_patch(r, n, key, x=0.25 if outfit.get("armor") else 0.22)
    return r

def pose_for(pose, i):
    if pose in ("rifle", "musket", "smg", "mg", "crossbow", "lance", "shotgun"):
        return A.merge(A.wide(), A.aim() if i % 2 == 0 else A.low_ready())
    if pose == "pistol": return A.merge(A.wide(), A.pistol_aim())
    if pose in ("knife", "club", "machete"): return A.merge(A.wide(), A.guard1())
    if pose == "spear": return A.merge(A.stance(), A.P(rot={"weapon": (0, 82, 0)}, loc={"weapon": (0, 0, 0.22), "shield": (0.02, 0, 0.08)}))
    if pose == "grenade": return A.clip_grenade().sample(6)
    if pose == "idle": return A.merge(A.stance(), A.arms_down())
    return A.stance()

if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:]
    key = args[0]; SAMP = int(args[1]) if len(args) > 1 else 20
    reset(); setup_render(samples=SAMP)
    world((40, 36, 58), 0.5)
    box("ground", (0, 0, -0.05), (40, 20, 0.1), mat("ground", (62, 58, 66), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
        (0.0, (58, 55, 62)), (0.45, (62, 58, 66)), (0.66, (66, 62, 66)), (0.82, (60, 62, 58))])), pass_index=1)
    CAMYAW = -25; YAW = CAMYAW - 52
    cy = math.radians(CAMYAW); RIGHT = V((math.cos(cy), math.sin(cy), 0))
    us = UNITS[key]; N = len(us); SP = 1.55
    for i, (label, pose, outfit, acc) in enumerate(us):
        r = build_unit(key, i, label, pose, outfit, acc)
        A.apply(r, pose_for(pose, i), tuple(RIGHT * ((i - (N - 1) / 2) * SP)), YAW if pose != "banner" else YAW + 40)
    sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.88, 0.72), 3.2)
    fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.72, 0.78, 1.0), 1.4)
    rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
    for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
    camera(V((0, 0, 1.0)), 50, N * SP + 0.6, (int((N * SP + 0.6) * 84), 290), yaw_deg=CAMYAW)
    render("/home/claude/latarnia3d/out/frakcja_%s.exr" % key)
