"""Znaki 11 frakcji jako pikselowe emblematy 48x48 (tekstury na sztandary, tarcze, tuniki) + plansza zbiorcza."""
import math, os
from PIL import Image, ImageDraw

OUT = "/home/claude/latarnia3d/tex"
os.makedirs(OUT, exist_ok=True)
S = 48

# barwy docelowe frakcji: (tlo, znak, akcent)
PAL = {
    "szabrownicy": ((122, 66, 40), (214, 178, 62), (60, 36, 26)),
    "synowie":     ((216, 210, 196), (170, 34, 34), (60, 20, 20)),
    "chor":        ((112, 96, 132), (222, 210, 186), (60, 50, 74)),
    "tor":         ((34, 32, 36), (186, 148, 74), (90, 80, 70)),
    "lowcy":       ((62, 78, 48), (176, 44, 38), (34, 40, 28)),
    "zakon":       ((40, 50, 92), (226, 190, 70), (20, 26, 52)),
    "dezerterzy":  ((70, 74, 62), (200, 190, 160), (160, 40, 36)),
    "bunkier":     ((84, 92, 58), (222, 116, 34), (30, 30, 30)),
    "gildia":      ((222, 220, 210), (60, 96, 150), (150, 170, 190)),
    "las":         ((70, 86, 52), (196, 150, 70), (40, 50, 30)),
    "tama":        ((96, 102, 112), (64, 180, 172), (40, 44, 52)),
}

def ring(d, c, r, col, w=3):
    d.ellipse((c - r, c - r, c + r, c + r), outline=col, width=w)

def draw(key):
    bg, fg, ac = PAL[key]
    im = Image.new("RGB", (S, S), bg); d = ImageDraw.Draw(im); c = S // 2
    if key == "szabrownicy":       # strzala w dol, malowana farba, z zaciekami
        d.rectangle((c - 4, 8, c + 4, 28), fill=fg)
        d.polygon([(c - 13, 26), (c + 13, 26), (c, 41)], fill=fg)
        for x, l in ((c - 3, 4), (c + 2, 7), (c - 9, 3), (c + 9, 5)):
            d.line((x, 28 if abs(x - c) < 5 else 30, x, 30 + l), fill=fg, width=1)
    elif key == "synowie":         # zamkniete oko w plomieniu
        d.polygon([(c, 5), (c + 9, 18), (c + 13, 30), (c + 8, 40), (c, 43), (c - 8, 40), (c - 13, 30), (c - 9, 18)], fill=fg)
        d.polygon([(c, 15), (c + 5, 25), (c + 6, 33), (c, 38), (c - 6, 33), (c - 5, 25)], fill=(220, 90, 50))
        d.arc((c - 8, 22, c + 8, 36), 20, 160, fill=bg, width=2)
        for x in (-5, 0, 5): d.line((c + x, 35, c + x * 1.3, 38), fill=bg, width=1)
    elif key == "chor":            # otwarte usta w spirali
        pts = [(c + (2 + 0.55 * a) * math.cos(a), c + (2 + 0.55 * a) * math.sin(a)) for a in [i * 0.2 for i in range(0, 110)]]
        d.line(pts, fill=fg, width=2)
        d.ellipse((c - 6, c - 4, c + 6, c + 4), fill=ac); d.line((c - 6, c, c + 6, c), fill=fg)
        for x in (-3, 0, 3): d.line((c + x, c - 4, c + x, c - 2), fill=fg)
    elif key == "tor":             # dwie szyny przeciete kolem
        for x in (c - 7, c + 7): d.rectangle((x - 2, 4, x + 2, S - 5), fill=fg)
        for y in range(8, S - 6, 7): d.rectangle((c - 13, y, c + 13, y + 2), fill=ac)
        ring(d, c, 15, fg, 3); d.ellipse((c - 3, c - 3, c + 3, c + 3), fill=fg)
        for a in range(0, 360, 60):
            d.line((c, c, c + 14 * math.cos(math.radians(a)), c + 14 * math.sin(math.radians(a))), fill=fg, width=2)
    elif key == "lowcy":           # siec z hakiem
        for k in range(-3, 4):
            d.line((c + k * 6 - 14, 6, c + k * 6 + 14, 34), fill=fg, width=1)
            d.line((c + k * 6 + 14, 6, c + k * 6 - 14, 34), fill=fg, width=1)
        d.rectangle((0, 0, S, 4), fill=bg); d.rectangle((0, 35, S, S), fill=bg)
        d.line((c, 32, c, 40), fill=(200, 196, 180), width=2)
        d.arc((c - 7, 34, c + 5, 46), 0, 200, fill=(200, 196, 180), width=2)
        d.polygon([(c - 7, 40), (c - 10, 37), (c - 5, 38)], fill=(200, 196, 180))
    elif key == "zakon":           # latarnia w kole z osmioma promieniami
        for k in range(8):
            a = k * math.pi / 4
            d.line((c + 14 * math.cos(a), c + 14 * math.sin(a), c + 22 * math.cos(a), c + 22 * math.sin(a)), fill=fg, width=3)
        ring(d, c, 13, fg, 2)
        d.rectangle((c - 4, c - 4, c + 4, c + 6), fill=fg); d.rectangle((c - 2, c - 2, c + 2, c + 4), fill=(255, 240, 180))
        d.polygon([(c - 6, c - 4), (c + 6, c - 4), (c, c - 10)], fill=fg); d.rectangle((c - 5, c + 6, c + 5, c + 8), fill=fg)
    elif key == "dezerterzy":      # twoja latarnia do gory nogami, przekreslona
        d.rectangle((c - 4, c - 6, c + 4, c + 4), fill=fg); d.polygon([(c - 6, c + 4), (c + 6, c + 4), (c, c + 11)], fill=fg)
        d.rectangle((c - 5, c - 9, c + 5, c - 6), fill=fg)
        d.line((8, 8, S - 8, S - 8), fill=ac, width=4); d.line((S - 8, 8, 8, S - 8), fill=ac, width=4)
    elif key == "bunkier":         # maska gazowa w trojkacie ostrzegawczym
        d.polygon([(c, 4), (S - 4, S - 6), (4, S - 6)], fill=fg); d.polygon([(c, 11), (S - 11, S - 10), (11, S - 10)], fill=bg)
        d.ellipse((c - 9, 20, c + 9, 37), fill=ac)
        for x in (-4, 4): d.ellipse((c + x - 3, 23, c + x + 3, 29), fill=fg)
        d.ellipse((c - 3, 31, c + 3, 37), fill=(110, 110, 110))
    elif key == "gildia":          # waga z krysztalem soli
        d.line((c, 8, c, 38), fill=fg, width=3); d.line((c - 15, 14, c + 15, 14), fill=fg, width=2)
        d.rectangle((c - 8, 38, c + 8, 41), fill=fg)
        for x in (c - 15, c + 15):
            d.line((x, 14, x - 5, 26), fill=fg); d.line((x, 14, x + 5, 26), fill=fg); d.arc((x - 7, 20, x + 7, 32), 0, 180, fill=fg, width=2)
        d.polygon([(c + 15, 15), (c + 19, 21), (c + 15, 26), (c + 11, 21)], fill=ac)
    elif key == "las":             # poroze z galezi
        d.line((c, 42, c, 30), fill=fg, width=3)
        for s in (1, -1):
            d.line((c, 32, c + s * 12, 18), fill=fg, width=3); d.line((c + s * 12, 18, c + s * 14, 6), fill=fg, width=2)
            d.line((c + s * 6, 25, c + s * 4, 14), fill=fg, width=2); d.line((c + s * 12, 18, c + s * 20, 14), fill=fg, width=2)
            d.line((c + s * 13, 11, c + s * 19, 7), fill=fg, width=1)
        d.ellipse((c - 4, 40, c + 4, 45), fill=ac)
    elif key == "tama":            # blyskawica nad lukiem tamy
        d.chord((6, 26, S - 6, S + 14), 180, 360, fill=ac); d.arc((6, 26, S - 6, S + 14), 180, 360, fill=fg, width=3)
        for x in range(10, S - 8, 6): d.line((x, 34, x, S), fill=(70, 76, 86))
        d.polygon([(c + 2, 4), (c - 7, 20), (c - 1, 20), (c - 5, 32), (c + 8, 14), (c + 2, 14), (c + 6, 4)], fill=fg)
    return im

NAMES = {"szabrownicy": "Szabrownicy", "synowie": "Synowie Czystości", "chor": "Chór Mgły", "tor": "Ludzie Toru", "lowcy": "Łowcy Głów",
         "zakon": "Zakon Latarników", "dezerterzy": "Dezerterzy", "bunkier": "Bractwo Bunkra", "gildia": "Gildia Solna", "las": "Dzieci Lasu", "tama": "Republika Tamy"}

if __name__ == "__main__":
    from PIL import ImageFont
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 15)
    sheet = Image.new("RGB", (6 * 200, 2 * 230), (24, 20, 30)); dd = ImageDraw.Draw(sheet)
    for i, k in enumerate(PAL):
        im = draw(k); im.save(OUT + "/emblem_%s.png" % k)
        x, y = (i % 6) * 200 + 28, (i // 6) * 230 + 20
        sheet.paste(im.resize((144, 144), Image.NEAREST), (x, y))
        w = dd.textlength(NAMES[k], font=font); dd.text((x + 72 - w / 2, y + 152), NAMES[k], font=font, fill=(226, 200, 150))
        for j, col in enumerate(PAL[k]): dd.rectangle((x + 24 + j * 34, y + 176, x + 54 + j * 34, y + 190), fill=col)
    sheet.save("/home/claude/latarnia3d/out/latarnia_znaki_frakcji.png")
