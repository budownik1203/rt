"""Nowi wrogowie: zwierzeta lekko zmienione przez Mgle (pies, wilk, dzik, jelen na tym samym szkielecie czworonoga),
Stworzenia Mgly (mocne objawy infekcji) i ludzie zmienieni przez Mgle."""
import math
from mathutils import Vector as V
from lat3d import *
import chars
from chars import Rig, bone_pts, human, M, METAL, METAL_D, WOOD, FLESH, SKIN_PALE

def F(n, c, e, s): return M("m2_" + n, c, emit=e, strength=s)
TISSUE = lambda: M("m2_tissue", (128, 64, 92))
TISSUE_D = lambda: M("m2_tissue_d", (80, 40, 70))
GLAND = lambda: F("gland", (230, 236, 150), (200, 230, 90), 5)
VEIN = lambda: F("vein", (200, 230, 210), (150, 230, 190), 3)
BONE = lambda: M("m2_bone", (200, 190, 168))
MIST = lambda: M("m2_mist", (150, 156, 170))
MIST_L = lambda: F("mist_l", (176, 180, 196), (120, 130, 160), 0.4)

# ------------------------------------------------------------------ czworonog (szkielet zgodny z Ogarem, wiec dzialaja jego animacje)
KINDS = {
    #          fur,             fur2 (laty),     leg, body_r, len, head, tail, eyes
    "pies":  ((112, 98, 82),  (84, 72, 62),    1.00, 1.18, 0.86, 1.15, "pies"),
    "wilk":  ((122, 108, 88), (86, 76, 64),   1.06, 1.28, 0.92, 1.22, "wilk"),
    "dzik":  ((70, 56, 46),   (52, 42, 36),    0.70, 1.70, 0.86, 1.30, "dzik"),
    "jelen": ((128, 96, 66),  (156, 134, 104), 1.45, 1.20, 0.95, 1.05, "jelen"),
}
def quadruped(name, kind="pies"):
    fur_c, fur2_c, LEG, BR, LN, HD, TL = KINDS[kind]
    lift = (LEG - 1.0) * 0.34
    def p(x, y, z): return (x * LN, y, z + lift if z > 0.2 else z * (LEG if z <= 0.2 else 1))
    def lz(z): return z * LEG
    B = [("pelvis", p(-0.50, 0, 0.62), p(-0.20, 0, 0.66), None), ("spine", p(-0.20, 0, 0.66), p(0.25, 0, 0.72), "pelvis"),
         ("chest", p(0.25, 0, 0.72), p(0.45, 0, 0.74), "spine"), ("neck", p(0.45, 0, 0.76), p(0.68, 0, 0.84), "chest"),
         ("head", p(0.68, 0, 0.84), p(0.96, 0, 0.80), "neck"), ("jaw", p(0.70, 0, 0.76), p(0.95, 0, 0.70), "head"),
         ("tail1", p(-0.50, 0, 0.62), p(-0.85, 0, 0.74), "pelvis"), ("tail2", p(-0.85, 0, 0.74), p(-1.12, 0, 0.92), "tail1")]
    for s, n in ((1, "L"), (-1, "R")):
        B += [("fup." + n, p(0.38, s * 0.14, 0.64), (0.42 * LN, s * 0.15, lz(0.38)), "chest"), ("flo." + n, (0.42 * LN, s * 0.15, lz(0.38)), (0.36 * LN, s * 0.15, lz(0.10)), "fup." + n),
              ("fpaw." + n, (0.36 * LN, s * 0.15, lz(0.10)), (0.47 * LN, s * 0.15, 0.04), "flo." + n),
              ("hup." + n, p(-0.42, s * 0.15, 0.60), (-0.26 * LN, s * 0.16, lz(0.36)), "pelvis"), ("hlo." + n, (-0.26 * LN, s * 0.16, lz(0.36)), (-0.44 * LN, s * 0.16, lz(0.14)), "hup." + n),
              ("hpaw." + n, (-0.44 * LN, s * 0.16, lz(0.14)), (-0.33 * LN, s * 0.16, 0.04), "hlo." + n)]
    rig = Rig(name, B); A = rig.attach
    FUR = M("fur_" + kind, fur_c); FUR2 = M("fur2_" + kind, fur2_c); SKIN = M("bald_skin", (150, 116, 112)); SORE = M("sore", (140, 40, 44))
    EYE = F("white_eye", (226, 230, 236), (180, 190, 210), 1.2)
    b = BR
    A(loft(name + "_body", [(p(-0.60, 0, 0.64), 0.07 * b, 0.07 * b), (p(-0.45, 0, 0.66), 0.12 * b, 0.105 * b), (p(-0.15, 0, 0.64), 0.10 * b, 0.09 * b),
                            (p(0.12, 0, 0.68), 0.14 * b, 0.115 * b), (p(0.36, 0, 0.72), 0.16 * b, 0.13 * b), (p(0.52, 0, 0.78), 0.11 * b, 0.10 * b)], FUR), "spine")
    # chude boki: zebra przebijaja przez skore, laty siersci i wylysiale placki
    for k in range(4):
        x = 0.06 + 0.07 * k
        for s in (1, -1):
            A(ellipsoid(name + "_rib%d%d" % (k, s), p(x, s * 0.105 * b, 0.68), (0.012, 0.02, 0.07 * b), FUR2), "spine" if x < 0.25 else "chest")
    for k, (x, s, rr) in enumerate(((-0.30, 1, 0.07), (0.20, -1, 0.06), (-0.05, -1, 0.05), (0.40, 1, 0.045))):
        A(ellipsoid(name + "_bald%d" % k, p(x, s * 0.09 * b, 0.70), (rr, 0.04, rr * 0.8), SKIN), "spine" if x < 0.25 else "chest")
    for k, (x, s) in enumerate(((-0.28, 1), (0.22, -1), (0.42, 1))):
        A(ellipsoid(name + "_sore%d" % k, p(x, s * 0.12 * b, 0.70), (0.022, 0.02, 0.018), SORE), "spine" if x < 0.25 else "chest")
    A(ellipsoid(name + "_saddle", p(0.0, 0, 0.73), (0.30, 0.085 * b, 0.05), FUR2), "spine")
    A(loft(name + "_neckm", [(p(0.45, 0, 0.78), 0.11 * b, 0.09 * b), (p(0.68, 0, 0.86), 0.075, 0.07)], FUR), "neck")
    h = HD
    if kind == "dzik":
        A(loft(name + "_skull", [(p(0.60, 0, 0.84), 0.14, 0.12), (p(0.82, 0, 0.78), 0.09, 0.08), (p(1.02, 0, 0.70), 0.05, 0.06)], FUR), "head")
        A(cyl(name + "_snout", p(1.00, 0, 0.70), p(1.05, 0, 0.69), 0.05, SKIN, seg=8), "head")
        for s in (1, -1):
            A(loft(name + "_tusk%d" % s, [(p(0.94, s * 0.045, 0.70), 0.012, 0.012), (p(1.00, s * 0.07, 0.76), 0.008, 0.008), (p(0.96, s * 0.08, 0.84), 0.002, 0.002)], BONE(), seg=5), "head")
        for k in range(6):
            A(loft(name + "_bristle%d" % k, [(p(-0.2 + 0.12 * k, 0, 0.74 + lift * 0), 0.02, 0.02), (p(-0.24 + 0.12 * k, 0, 0.84), 0.004, 0.004)], FUR2, seg=4), "spine" if k < 4 else "chest")
    else:
        A(loft(name + "_skull", [(p(0.62, 0, 0.88), 0.09 * h, 0.085 * h), (p(0.74, 0, 0.89), 0.085 * h, 0.08 * h), (p(0.80, 0, 0.86), 0.06 * h, 0.06 * h), (p(0.97, 0, 0.83), 0.038 * h, 0.04 * h)], FUR), "head")
        A(ellipsoid(name + "_nose", p(0.985, 0, 0.83), (0.02, 0.022, 0.018), M("nose", (30, 26, 28))), "head")
        A(loft(name + "_jawm", [(p(0.70, 0, 0.79), 0.04, 0.05), (p(0.95, 0, 0.75), 0.016, 0.025)], FUR), "jaw")
        A(loft(name + "_gums", [(p(0.74, 0, 0.805), 0.025, 0.045), (p(0.94, 0, 0.78), 0.01, 0.024)], M("gums", (170, 60, 66))), "head")
        for s in (1, -1):
            for k in range(3):
                A(loft(name + "_tooth%d%d" % (s, k), [(p(0.84 + 0.04 * k, s * 0.026, 0.79), 0.007, 0.007), (p(0.84 + 0.04 * k, s * 0.026, 0.765), 0.001, 0.001)], BONE(), seg=4), "jaw")
            if kind != "jelen":
                A(loft(name + "_ear%d" % s, [(p(0.66, s * 0.055, 0.94), 0.045, 0.025), (p(0.62, s * 0.08, 1.07 if kind == "wilk" else 1.03), 0.004, 0.004)], FUR2, seg=4), "head")
    if kind == "jelen":   # przerosniete, rozgalezione poroze z naroslami
        for s in (1, -1):
            pts = [p(0.66, s * 0.05, 0.94), p(0.60, s * 0.16, 1.18), p(0.52, s * 0.30, 1.40), p(0.58, s * 0.42, 1.62)]
            A(loft(name + "_ant%d" % s, [(pts[0], 0.025, 0.025), (pts[1], 0.022, 0.022), (pts[2], 0.016, 0.016), (pts[3], 0.004, 0.004)], BONE(), seg=5), "head")
            for k, (a, bb) in enumerate(((1, (0.72, 0.20, 1.30)), (2, (0.44, 0.40, 1.52)), (2, (0.70, 0.36, 1.55)))):
                A(loft(name + "_tine%d%d" % (s, k), [(pts[a], 0.014, 0.014), (p(bb[0], s * bb[1], bb[2]), 0.003, 0.003)], BONE(), seg=4), "head")
            A(ellipsoid(name + "_knot%d" % s, pts[2], (0.045, 0.04, 0.04), TISSUE()), "head")
    for s in (1, -1):
        A(ellipsoid(name + "_eye%d" % s, p(0.80 if kind != "dzik" else 0.78, s * 0.052, 0.905 if kind != "dzik" else 0.86), (0.018, 0.014, 0.016), EYE), "head")
    tr = 0.05 if kind == "wilk" else 0.03
    if kind != "jelen":
        A(loft(name + "_tail_a", [(p(-0.50, 0, 0.64), 0.04, 0.04), (p(-0.85, 0, 0.75), tr, tr)], FUR), "tail1")
        A(loft(name + "_tail_b", [(p(-0.85, 0, 0.75), tr, tr), (p(-1.12, 0, 0.92), 0.006, 0.006)], FUR2 if kind == "wilk" else FUR), "tail2")
    for s, n in ((1, "L"), (-1, "R")):
        for seg_, r0, r1 in (("fup", 0.06, 0.04), ("flo", 0.032, 0.024), ("hup", 0.085, 0.045), ("hlo", 0.036, 0.026)):
            hh, tt = bone_pts(rig, seg_ + "." + n)
            A(loft(name + "_%s%s" % (seg_, n), [(hh, 1.35 * r0 * b ** 0.5, 1.35 * r0 * b ** 0.5), (tt, 1.3 * r1, 1.3 * r1)], FUR), seg_ + "." + n)
        for seg_ in ("fpaw", "hpaw"):
            hh, tt = bone_pts(rig, seg_ + "." + n)
            A(loft(name + "_%s%s" % (seg_, n), [(hh, 0.024, 0.024), (tt, 0.018, 0.028)], M("hoof", (40, 34, 32)) if kind in ("dzik", "jelen") else FUR2), seg_ + "." + n)
    return rig

# ------------------------------------------------------------------ Stworzenia Mgly (bez szkieletu: statyczne bryly, animowane transformacjami)
def _parts(name, objs):
    for o in objs: o.pass_index = 3; char_collection().objects.link(o)
    return objs

def zwiewnik(n, c):
    """Ksztalt z gestej mgly, widac go tylko w swietle: wysoki calun z postrzepionym dolem, kaptur, dlugie rece, swiecace oczy."""
    c = V(c); o = []
    o.append(loft(n + "_shroud", [(c + V((0, 0, 0.15)), 0.42, 0.40), (c + V((0.02, 0, 0.8)), 0.30, 0.28), (c + V((0.04, 0, 1.5)), 0.22, 0.24), (c + V((0.06, 0, 1.9)), 0.16, 0.2)], MIST(), seg=12))
    for k in range(10):
        a = k * 0.63
        b0 = c + V((0.40 * math.cos(a), 0.38 * math.sin(a), 0.25))
        o.append(loft(n + "_tat%d" % k, [(b0, 0.05, 0.02), (b0 + V((0.08 * math.cos(a), 0.08 * math.sin(a), -0.22 - 0.05 * (k % 3))), 0.006, 0.006)], MIST_L() if k % 2 else MIST(), seg=4))
    o.append(ellipsoid(n + "_hood", c + V((0.06, 0, 2.08)), (0.15, 0.14, 0.2), MIST_L()))
    o.append(ellipsoid(n + "_face", c + V((0.16, 0, 2.05)), (0.06, 0.09, 0.12), M("m2_void", (24, 14, 22))))
    for s_ in (1, -1):
        o.append(loft(n + "_arm%d" % s_, [(c + V((0.04, s_ * 0.2, 1.78)), 0.06, 0.06), (c + V((0.3, s_ * 0.36, 1.25)), 0.04, 0.04), (c + V((0.42, s_ * 0.32, 0.6)), 0.02, 0.02), (c + V((0.46, s_ * 0.30, 0.42)), 0.003, 0.003)], MIST_L(), seg=6))
        o.append(ellipsoid(n + "_eye%d" % s_, c + V((0.2, s_ * 0.035, 2.09)), (0.012, 0.02, 0.01), F("zw_eye", (220, 240, 255), (200, 230, 255), 8)))
    for k in range(6):
        a = k * 1.05 + 0.3
        o.append(ellipsoid(n + "_wisp%d" % k, c + V((0.42 * math.cos(a), 0.4 * math.sin(a), 0.04)), (0.14, 0.1, 0.03), MIST()))
    return _parts(n, o)

def nici(n, c):
    """Macki z mgly wychodzace z ziemi: kilkanascie wijacych sie nici z przyssawkami."""
    c = V(c); o = []
    o.append(ellipsoid(n + "_pool", c + V((0, 0, 0.0)), (0.6, 0.6, 0.06), TISSUE_D()))
    for k in range(9):
        a = k * 2.4; r0 = 0.15 + 0.35 * (k % 3) / 2
        b0 = c + V((r0 * math.cos(a), r0 * math.sin(a), 0.02))
        h = 0.8 + 0.5 * ((k * 7) % 5) / 4
        pts = [b0, b0 + V((0.1 * math.cos(a + 1), 0.1 * math.sin(a + 1), h * 0.35)), b0 + V((0.22 * math.cos(a - 0.5), 0.22 * math.sin(a - 0.5), h * 0.7)), b0 + V((0.12 * math.cos(a + 2), 0.12 * math.sin(a + 2), h))]
        o.append(loft(n + "_t%d" % k, [(pts[0], 0.05, 0.05), (pts[1], 0.035, 0.035), (pts[2], 0.022, 0.022), (pts[3], 0.004, 0.004)], TISSUE() if k % 2 else M("m2_tendril", (120, 110, 140)), seg=6))
        o.append(ellipsoid(n + "_s%d" % k, pts[2], (0.03, 0.03, 0.03), GLAND()))
    return _parts(n, o)

def klebowisko(n, c):
    """Toczaca sie masa tkanki, wchlonela trupy: wystaja konczyny, kosci i strzepy ubran."""
    c = V(c); o = [ellipsoid(n + "_core", c + V((0, 0, 0.62)), (0.7, 0.62, 0.6), TISSUE())]
    for k in range(10):
        a = k * 2.2; e = k * 1.3
        p = c + V((0.6 * math.cos(a) * math.cos(e * 0.3), 0.55 * math.sin(a), 0.62 + 0.45 * math.sin(e)))
        o.append(ellipsoid(n + "_lump%d" % k, p, (0.2, 0.18, 0.16), TISSUE_D() if k % 2 else TISSUE()))
    for k in range(5):   # wystajace rece i kosci
        a = k * 1.3 + 0.4
        b0 = c + V((0.6 * math.cos(a), 0.55 * math.sin(a), 0.75 + 0.15 * (k % 2)))
        o.append(loft(n + "_limb%d" % k, [(b0, 0.045, 0.045), (b0 + V((0.3 * math.cos(a), 0.3 * math.sin(a), 0.15)), 0.035, 0.035), (b0 + V((0.42 * math.cos(a), 0.42 * math.sin(a), 0.0)), 0.03, 0.03)], SKIN_PALE() if k % 2 else BONE(), seg=6))
    o.append(ellipsoid(n + "_rag", c + V((0.3, -0.45, 0.9)), (0.2, 0.08, 0.14), M("rag_ol", (86, 96, 60))))
    o.append(ellipsoid(n + "_helm", c + V((-0.2, 0.5, 1.05)), (0.13, 0.13, 0.08), METAL_D()))
    for k in range(6):
        a = k * 1.05
        o.append(ellipsoid(n + "_gl%d" % k, c + V((0.66 * math.cos(a), 0.6 * math.sin(a), 0.45 + 0.1 * k)), (0.05, 0.05, 0.05), GLAND()))
    return _parts(n, o)

def oddech(n, c):
    """Chmura dusiaca: klab zielonkawej mgly z zarzacym sie sercem w srodku."""
    c = V(c); o = [ellipsoid(n + "_heart", c + V((0, 0, 1.0)), (0.14, 0.14, 0.16), F("od_heart", (220, 240, 140), (190, 230, 80), 7))]
    for k in range(16):
        a = k * 2.4; r = 0.35 + 0.45 * ((k * 5) % 7) / 6
        o.append(ellipsoid(n + "_c%d" % k, c + V((r * math.cos(a), r * math.sin(a), 0.5 + 0.9 * ((k * 3) % 5) / 4)), (0.32, 0.32, 0.26),
                           M("m2_gas", (126, 146, 92)) if k % 3 else F("gas_l", (150, 170, 100), (100, 130, 50), 0.5)))
    return _parts(n, o)

def gasiciel(n, c):
    """Gasi zrodla swiatla: chude, wydluzone stworzenie z blony i tkanki, z ogromna plaska paszcza-lejem."""
    c = V(c); o = []
    o.append(loft(n + "_body", [(c + V((-0.3, 0, 1.0)), 0.12, 0.1), (c + V((0.1, 0, 1.2)), 0.16, 0.13), (c + V((0.45, 0, 1.45)), 0.1, 0.09)], TISSUE_D()))
    o.append(loft(n + "_funnel", [(c + V((0.45, 0, 1.45)), 0.08, 0.08), (c + V((0.7, 0, 1.55)), 0.24, 0.24), (c + V((0.74, 0, 1.56)), 0.26, 0.26)], M("m2_maw", (40, 20, 30)), seg=12, cap=False))
    o.append(loft(n + "_rim", [(c + V((0.72, 0, 1.555)), 0.27, 0.27), (c + V((0.75, 0, 1.565)), 0.27, 0.27)], TISSUE(), seg=14))
    for s in (1, -1):
        for k, (x, L) in enumerate(((0.2, 1.0), (-0.2, 0.95))):
            b0 = c + V((x, s * 0.1, 1.1))
            o.append(loft(n + "_leg%d%d" % (k, s), [(b0, 0.035, 0.035), (b0 + V((0.15, s * 0.35, 0.25)), 0.025, 0.025), (b0 + V((0.3 - 0.5 * k, s * 0.55, -1.1)), 0.008, 0.008)], TISSUE_D(), seg=5))
        o.append(loft(n + "_memb%d" % s, [(c + V((0.0, s * 0.12, 1.15)), 0.18, 0.01), (c + V((-0.1, s * 0.4, 1.35)), 0.15, 0.005)], M("m2_memb", (110, 80, 96)), seg=4))
    for k in range(5):
        o.append(ellipsoid(n + "_eye%d" % k, c + V((0.40, -0.1 + 0.05 * k, 1.5 + 0.03 * (k % 2))), (0.015, 0.015, 0.015), F("gas_eye", (255, 120, 90), (255, 90, 60), 6)))
    return _parts(n, o)

def siewca(n, c):
    """Nieruchoma wieza tkanki: zebrowany pien, worki zarodnikow, swiecace pory, korzenie w ziemi."""
    c = V(c); o = []
    o.append(loft(n + "_trunk", [(c, 0.55, 0.55), (c + V((0, 0, 0.8)), 0.4, 0.42), (c + V((0.05, 0, 1.8)), 0.3, 0.28), (c + V((0, 0.05, 2.6)), 0.2, 0.2), (c + V((0, 0, 3.0)), 0.05, 0.05)], TISSUE(), seg=12))
    for k in range(6):
        a = k * 1.05
        o.append(loft(n + "_root%d" % k, [(c + V((0.3 * math.cos(a), 0.3 * math.sin(a), 0.2)), 0.12, 0.12), (c + V((1.0 * math.cos(a), 1.0 * math.sin(a), 0.02)), 0.03, 0.03)], TISSUE_D(), seg=6))
        o.append(loft(n + "_rib%d" % k, [(c + V((0.42 * math.cos(a), 0.42 * math.sin(a), 0.2)), 0.04, 0.04), (c + V((0.24 * math.cos(a), 0.24 * math.sin(a), 2.4)), 0.02, 0.02)], TISSUE_D(), seg=5))
    for k in range(7):
        a = k * 2.0; z = 0.9 + 0.28 * k
        o.append(ellipsoid(n + "_sac%d" % k, c + V((0.36 * math.cos(a), 0.36 * math.sin(a), z)), (0.16, 0.15, 0.2), M("m2_sac", (176, 170, 96))))
        o.append(ellipsoid(n + "_pore%d" % k, c + V((0.30 * math.cos(a + 1), 0.30 * math.sin(a + 1), z + 0.12)), (0.04, 0.04, 0.04), GLAND()))
    for k in range(10):
        a = k * 0.9
        o.append(ellipsoid(n + "_spore%d" % k, c + V((0.6 * math.cos(a), 0.6 * math.sin(a), 2.8 + 0.25 * math.sin(k))), (0.025, 0.025, 0.025), F("spore", (230, 240, 160), (200, 230, 100), 3)))
    return _parts(n, o)

# ------------------------------------------------------------------ ludzie zmienieni przez Mgle (na szkielecie czlowieka)
def veins(r, n, k=8):
    for i in range(k):
        b = ("upperarm.L", "upperarm.R", "forearm.L", "forearm.R", "chest", "head")[i % 6]
        hh, tt = bone_pts(r, b)
        mid = hh.lerp(tt, 0.3 + 0.1 * (i % 3)) + V((0.06, 0.03 * ((i % 2) * 2 - 1), 0))
        r.attach(loft(n + "_vein%d" % i, [(mid, 0.008, 0.008), (mid + V((0.02, 0.01, -0.12)), 0.004, 0.004)], VEIN(), seg=4), b)
def biegacz(n):
    r = human(n, dict(skin="pale", jacket="grey", pants="darkgrey", glow_eyes=True, strap=False, pouches=False), "idle")
    veins(r, n, 10)
    for k, b in enumerate(("chest", "upperarm.R", "thigh.L")):
        hh, tt = bone_pts(r, b); r.attach(ellipsoid(n + "_tear%d" % k, hh.lerp(tt, 0.5) + V((0.08, 0, 0)), (0.05, 0.06, 0.08), TISSUE()), b)
    return r
def wydrazony(n):
    r = human(n, dict(skin="pale", jacket="olive", pants="olive", helmet="mil", armor="plate", glow_eyes=True), "rifle")
    import bpy
    for o in list(r.parts):
        if any(o.name.startswith(n + k) for k in ("_head", "_nose", "_jaw", "_chin", "_eye", "_ear")): o.hide_render = True
    hc = V((0.012, 0, 1.635))
    r.attach(ellipsoid(n + "_void", hc + V((0.04, 0, 0)), (0.085, 0.09, 0.11), M("m2_void", (24, 14, 22))), "head")
    for k in range(6):
        r.attach(loft(n + "_strand%d" % k, [(hc + V((0.08, -0.05 + 0.02 * k, 0.04)), 0.012, 0.012), (hc + V((0.12, -0.06 + 0.025 * k, -0.12 - 0.03 * (k % 3))), 0.004, 0.004)], TISSUE(), seg=4), "head")
    for b in ("chest", "spine", "thigh.L", "thigh.R"):
        hh, tt = bone_pts(r, b)
        r.attach(ellipsoid(n + "_gap" + b, hh.lerp(tt, 0.6) + V((0.12, 0, 0)), (0.04, 0.12, 0.05), GLAND() if b == "chest" else TISSUE()), b)
    return r
def falszywy_latarnik(n):
    import factions as FC
    r = human(n, dict(skin="pale", jacket="blue", pants="darkgrey", helmet="mil", glow_eyes=True), "idle")
    FC.lantern_pole(r, n)
    hc = V((0.012, 0, 1.635))
    r.attach(ellipsoid(n + "_mawface", hc + V((0.1, 0, -0.03)), (0.04, 0.07, 0.08), TISSUE()), "head")
    for s, b in ((1, "forearm.L"), (-1, "forearm.R")):
        hh, tt = bone_pts(r, b)
        r.attach(loft(n + "_claw%d" % s, [(tt, 0.03, 0.03), (tt + V((0.02, 0, -0.30)), 0.02, 0.02), (tt + V((0.06, 0, -0.52)), 0.003, 0.003)], TISSUE_D(), seg=5), b)
    veins(r, n, 6)
    return r
def kokon(n, c):
    """Czlowiek w trakcie przemiany, owiniety tkanka na ziemi; widac twarz i dlon."""
    c = V(c); o = [loft(n + "_shell", [(c + V((-0.85, 0, 0.18)), 0.12, 0.14), (c + V((-0.4, 0, 0.26)), 0.24, 0.26), (c + V((0.25, 0, 0.28)), 0.24, 0.26), (c + V((0.7, 0, 0.22)), 0.15, 0.16)], TISSUE(), seg=12)]
    for k in range(7):
        x = -0.7 + 0.22 * k
        o.append(loft(n + "_band%d" % k, [(c + V((x, -0.27, 0.15)), 0.02, 0.02), (c + V((x + 0.05, 0, 0.55)), 0.02, 0.02), (c + V((x + 0.1, 0.27, 0.15)), 0.02, 0.02)], TISSUE_D(), seg=5))
    o.append(ellipsoid(n + "_face", c + V((0.62, 0, 0.36)), (0.08, 0.09, 0.07), SKIN_PALE()))
    o.append(ellipsoid(n + "_mouth", c + V((0.67, 0, 0.42)), (0.03, 0.035, 0.012), M("m2_void", (24, 14, 22))))
    o.append(loft(n + "_hand", [(c + V((0.2, 0.25, 0.3)), 0.035, 0.035), (c + V((0.35, 0.42, 0.12)), 0.03, 0.03)], SKIN_PALE(), seg=6))
    for k in range(5):
        o.append(ellipsoid(n + "_gl%d" % k, c + V((-0.6 + 0.3 * k, 0.12 * ((k % 2) * 2 - 1), 0.48)), (0.035, 0.035, 0.035), GLAND()))
    return _parts(n, o)
