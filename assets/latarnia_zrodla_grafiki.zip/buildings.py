"""Zestaw budowlany osady Latarni: deski, blacha falista, cegla, beton, plandeka, rekwizyty.
Kazdy budynek to funkcja b_<nazwa>(x, y, rot) skladajaca bryly w swiecie (pass_index 2 = otoczenie)."""
import math, random
import bpy
from mathutils import Vector as V, Euler, Matrix
from lat3d import mat, box, cyl, loft, ellipsoid, point_light, MATS

def _lin(c): return tuple(((x / 255) ** 2.2) for x in c) + (1,)

def tex_mat(name, kind, c1, c2, c3=None, scale=1.0, axis="Z", emit=None, strength=0.0):
    """kind: 'bands' (deski/blacha, pasy wzdluz osi), 'brick' (cegla na scianach w dowolnym kierunku), 'noise'."""
    if name in MATS: return MATS[name]
    m = bpy.data.materials.new(name); m.use_nodes = True; nt = m.node_tree; b = nt.nodes["Principled BSDF"]
    b.inputs["Roughness"].default_value = 1.0
    if "Specular IOR Level" in b.inputs: b.inputs["Specular IOR Level"].default_value = 0.0
    tc = nt.nodes.new("ShaderNodeTexCoord")
    ramp = nt.nodes.new("ShaderNodeValToRGB"); ramp.color_ramp.interpolation = "CONSTANT"
    els = ramp.color_ramp.elements
    els[0].position = 0.0; els[0].color = _lin(c1); els[1].position = 0.55; els[1].color = _lin(c2)
    if c3: e = els.new(0.85); e.color = _lin(c3)
    if kind == "bands":
        w = nt.nodes.new("ShaderNodeTexWave"); w.wave_type = "BANDS"; w.bands_direction = axis
        w.inputs["Scale"].default_value = scale; w.inputs["Distortion"].default_value = 1.5
        w.inputs["Detail"].default_value = 1.0
        nt.links.new(tc.outputs["Object"], w.inputs["Vector"]); nt.links.new(w.outputs["Fac"], ramp.inputs["Fac"])
    elif kind == "brick":
        sep = nt.nodes.new("ShaderNodeSeparateXYZ"); add = nt.nodes.new("ShaderNodeMath"); add.operation = "ADD"
        comb = nt.nodes.new("ShaderNodeCombineXYZ")
        nt.links.new(tc.outputs["Object"], sep.inputs[0]); nt.links.new(sep.outputs[0], add.inputs[0]); nt.links.new(sep.outputs[1], add.inputs[1])
        nt.links.new(add.outputs[0], comb.inputs[0]); nt.links.new(sep.outputs[2], comb.inputs[1])
        t = nt.nodes.new("ShaderNodeTexBrick"); t.inputs["Scale"].default_value = scale
        t.inputs["Color1"].default_value = _lin(c1); t.inputs["Color2"].default_value = _lin(c2)
        t.inputs["Mortar"].default_value = _lin(c3 or (60, 56, 60)); t.inputs["Mortar Size"].default_value = 0.025
        nt.links.new(comb.outputs[0], t.inputs["Vector"]); nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
        m.pass_index = 2; MATS[name] = m; return m
    else:
        n = nt.nodes.new("ShaderNodeTexNoise"); n.inputs["Scale"].default_value = scale; n.inputs["Detail"].default_value = 3.0
        nt.links.new(tc.outputs["Object"], n.inputs["Vector"]); nt.links.new(n.outputs["Fac"], ramp.inputs["Fac"])
    nt.links.new(ramp.outputs["Color"], b.inputs["Base Color"])
    if emit is not None:
        b.inputs["Emission Color"].default_value = _lin(emit); b.inputs["Emission Strength"].default_value = strength
    m.pass_index = 2; MATS[name] = m
    return m

# ------------------------------------------------------------------ materialy
PLANK = lambda: tex_mat("plank", "bands", (84, 62, 44), (100, 74, 52), (70, 52, 38), scale=9.0)
PLANK_V = lambda: tex_mat("plankv", "bands", (88, 66, 46), (104, 78, 54), (72, 54, 40), scale=7.0, axis="DIAGONAL")
PLANK_OLD = lambda: tex_mat("plank_old", "bands", (84, 80, 76), (98, 92, 84), (70, 66, 64), scale=9.0)
CORR = lambda: tex_mat("corr", "bands", (96, 100, 106), (112, 116, 120), (130, 86, 60), scale=40.0, axis="DIAGONAL")
RUSTY = lambda: tex_mat("rusty", "noise", (124, 70, 44), (98, 80, 70), (146, 92, 54), scale=4.0)
BRICK = lambda: tex_mat("brickw", "brick", (124, 66, 52), (104, 58, 48), (66, 60, 62), scale=3.2)
CONCRETE = lambda: tex_mat("concrete", "noise", (116, 110, 102), (122, 116, 108), (110, 104, 98), scale=3.0)
TARP = lambda: tex_mat("tarp", "noise", (84, 96, 70), (96, 108, 78), (74, 84, 62), scale=2.0)
TARP_R = lambda: tex_mat("tarpr", "noise", (128, 56, 48), (144, 66, 54), (110, 48, 44), scale=2.0)
THATCH = lambda: tex_mat("thatch", "bands", (120, 100, 60), (136, 116, 70), (104, 86, 52), scale=24.0, axis="Z")
DIRT = lambda: tex_mat("soil", "noise", (66, 52, 42), (76, 60, 46), (58, 46, 40), scale=6.0)
STONE = lambda: tex_mat("stonew", "brick", (112, 110, 112), (98, 96, 100), (70, 66, 70), scale=1.6)
M = lambda n, c, **k: mat(n, c, **k)
WOOD_D = lambda: M("wood_dk", (70, 50, 36)); METAL = lambda: M("metal_b", (120, 120, 130)); METAL_D = lambda: M("metal_bd", (66, 66, 76))
ROPE = lambda: M("rope", (150, 130, 90)); CLOTHW = lambda: M("clothw", (170, 160, 140)); BLACK = lambda: M("blackb", (30, 28, 32))
WIN = lambda: M("window_lit", (255, 196, 110), emit=(255, 176, 90), strength=4.0)
WIN_D = lambda: M("window_dark", (34, 36, 46))
FIRE = lambda: M("fire_b", (255, 160, 60), emit=(255, 140, 40), strength=12.0)
GLOWG = lambda: M("glow_green", (150, 220, 120), emit=(120, 220, 90), strength=3.0)
RED = lambda: M("red_b", (150, 40, 40)); WHITE = lambda: M("white_b", (200, 196, 186)); GREEN = lambda: M("green_b", (70, 104, 54))
MUSH = lambda: M("mush", (196, 180, 150)); MUSH_G = lambda: M("mush_glow", (170, 230, 200), emit=(120, 220, 180), strength=2.0)
LEATHER = lambda: M("hide", (130, 92, 62)); BONE = lambda: M("bone_b", (206, 196, 170)); WATER = lambda: M("water_b", (44, 62, 76))

class B:
    """Budowniczy w lokalnym ukladzie budynku (x w prawo, y w glab, z w gore), przeksztalcany do swiata."""
    def __init__(self, name, x, y, rot=0.0):
        self.n, self.o, self.r, self.k = name, V((x, y, 0)), math.radians(rot), 0
        self.R = Matrix.Rotation(self.r, 3, "Z")
    def p(self, x, y, z): return self.o + self.R @ V((x, y, z))
    def nm(self): self.k += 1; return "%s_%d" % (self.n, self.k)
    def box(self, c, s, m, rot=(0, 0, 0)):
        m = m() if callable(m) else m
        return box(self.nm(), self.p(*c), s, m, rot=(rot[0], rot[1], rot[2] + self.r))
    def cyl(self, a, b, r, m, r1=None, seg=10):
        m = m() if callable(m) else m
        return cyl(self.nm(), self.p(*a), self.p(*b), r, m, r1=r1, seg=seg)
    def ell(self, c, s, m):
        m = m() if callable(m) else m
        o = ellipsoid(self.nm(), self.p(*c), s, m); o.rotation_euler = (0, 0, 0); return o
    # ---- elementy
    def walls(self, w, d, h, m, t=0.12, door=None, wins=(), lit=True):
        """Prostokatne sciany; door=(sciana, pozycja, szer) 'f' = przod (y=-d/2)."""
        self.box((0, -d / 2, h / 2), (w, t, h), m); self.box((0, d / 2, h / 2), (w, t, h), m)
        self.box((-w / 2, 0, h / 2), (t, d, h), m); self.box((w / 2, 0, h / 2), (t, d, h), m)
        self.box((0, 0, 0.04), (w + 0.1, d + 0.1, 0.08), WOOD_D())                         # podwalina
        if door:
            side, pos, dw = door
            self.door(side, pos, dw, min(1.9, h - 0.2), w, d)
        for side, pos, zz in wins:
            self.window(side, pos, zz, w, d, lit)
    def door(self, side, pos, dw, dh, w, d):
        if side == "f": c, s = (pos, -d / 2 - 0.07, dh / 2), (dw, 0.05, dh)
        elif side == "r": c, s = (w / 2 + 0.07, pos, dh / 2), (0.05, dw, dh)
        else: c, s = (-w / 2 - 0.07, pos, dh / 2), (0.05, dw, dh)
        self.box(c, s, PLANK_V())
        fr = (s[0] + 0.12 if s[0] > 0.1 else 0.06, s[1] + 0.12 if s[1] > 0.1 else 0.06, 0.1)
        self.box((c[0], c[1], dh + 0.05), fr, WOOD_D())
    def window(self, side, pos, z, w, d, lit=True):
        m = WIN() if lit else WIN_D()
        if side == "f": c, s, sh = (pos, -d / 2 - 0.065, z), (0.5, 0.04, 0.42), (0.62, 0.05, 0.06)
        elif side == "r": c, s, sh = (w / 2 + 0.065, pos, z), (0.04, 0.5, 0.42), (0.05, 0.62, 0.06)
        elif side == "l": c, s, sh = (-w / 2 - 0.065, pos, z), (0.04, 0.5, 0.42), (0.05, 0.62, 0.06)
        else: c, s, sh = (pos, d / 2 + 0.065, z), (0.5, 0.04, 0.42), (0.62, 0.05, 0.06)
        self.box(c, s, m); self.box((c[0], c[1], z - 0.24), sh, WOOD_D()); self.box((c[0], c[1], z + 0.24), sh, WOOD_D())
    def gable(self, w, d, h0, rise, m, over=0.25, ridge=True):
        """Dach dwuspadowy wzdluz osi x."""
        half = d / 2 + over; L = math.hypot(half, rise); a = math.atan2(rise, half)
        for s in (1, -1):
            self.box((0, s * half / 2 - s * over * 0.0, h0 + rise / 2), (w + 2 * over, L, 0.07), m, rot=(-s * a, 0, 0))
        # szczyty
        for sx in (1, -1):
            pts = [self.p(sx * w / 2, -d / 2, h0), self.p(sx * w / 2, d / 2, h0), self.p(sx * w / 2, 0, h0 + rise * 0.97)]
            me = bpy.data.meshes.new(self.nm()); me.from_pydata([tuple(q) for q in pts], [], [(0, 1, 2)])
            ob = bpy.data.objects.new(me.name, me); bpy.context.scene.collection.objects.link(ob); me.materials.append(PLANK()); ob.pass_index = 2
            sol = ob.modifiers.new("s", "SOLIDIFY"); sol.thickness = 0.1
        if ridge: self.box((0, 0, h0 + rise + 0.02), (w + 2 * over, 0.12, 0.08), WOOD_D())
    def shed(self, w, d, h_front, h_back, m, over=0.25):
        """Dach jednospadowy: przod nizej (y=-d/2)."""
        L = math.hypot(d + 2 * over, h_back - h_front); a = math.atan2(h_back - h_front, d)
        self.box((0, 0, (h_front + h_back) / 2 + 0.04), (w + 2 * over, L, 0.07), m, rot=(a, 0, 0))
    def chimney(self, x, y, z0, h, m=None, smoke=False):
        self.box((x, y, z0 + h / 2), (0.32, 0.32, h), m or BRICK())
        self.box((x, y, z0 + h + 0.03), (0.38, 0.38, 0.06), METAL_D())
    # ---- rekwizyty
    def barrel(self, x, y, m=None, h=0.9, lying=False):
        if lying: self.cyl((x - h / 2, y, 0.3), (x + h / 2, y, 0.3), 0.3, m or RUSTY(), seg=12)
        else:
            self.cyl((x, y, 0), (x, y, h), 0.3, m or RUSTY(), seg=12)
            for z in (0.2, h - 0.2): self.cyl((x, y, z - 0.02), (x, y, z + 0.02), 0.31, METAL_D(), seg=12)
    def crate(self, x, y, z=0, s=0.6, rz=0):
        self.box((x, y, z + s / 2), (s, s, s), PLANK(), rot=(0, 0, rz))
        for dx in (-1, 1): self.box((x + dx * s * 0.42, y, z + s / 2), (0.06, s + 0.02, s + 0.02), WOOD_D(), rot=(0, 0, rz))
    def sack(self, x, y, z=0): self.ell((x, y, z + 0.18), (0.26, 0.2, 0.2), CLOTHW())
    def post(self, x, y, h, r=0.08, m=None): self.cyl((x, y, 0), (x, y, h), r, m or WOOD_D(), seg=6)
    def fence(self, x0, y0, x1, y1, h=1.0, step=0.5):
        n = max(1, int(math.hypot(x1 - x0, y1 - y0) / step))
        for i in range(n + 1):
            t = i / n; self.post(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, h + 0.08 * ((i * 7) % 3 - 1), 0.05)
        for z in (0.35, h - 0.15): self.cyl((x0, y0, z), (x1, y1, z), 0.03, WOOD_D(), seg=5)
    def lamp(self, x, y, h=2.4, energy=60):
        self.post(x, y, h, 0.05, METAL_D()); self.cyl((x, y, h), (x + 0.3, y, h), 0.025, METAL_D(), seg=5)
        self.ell((x + 0.3, y, h - 0.1), (0.07, 0.07, 0.09), WIN())
        point_light(self.nm(), self.p(x + 0.3, y, h - 0.25), (1.0, 0.72, 0.42), energy * 0.4, radius=0.05)
    def light(self, x, y, z, energy=40, col=(1.0, 0.72, 0.42)):
        point_light(self.nm(), self.p(x, y, z), col, energy * 0.4, radius=0.05)
    def pipe(self, a, b, r=0.06): self.cyl(a, b, r, METAL_D(), seg=8)
    def tank(self, x, y, r, h, m=None):
        self.cyl((x, y, 0.3), (x, y, 0.3 + h), r, m or METAL(), seg=14)
        self.ell((x, y, 0.3 + h), (r, r, r * 0.35), m or METAL())
        for dx, dy in ((1, 1), (1, -1), (-1, 1), (-1, -1)): self.post(x + dx * r * 0.6, y + dy * r * 0.6, 0.35, 0.04, METAL_D())
    def anvil(self, x, y):
        self.cyl((x, y, 0), (x, y, 0.55), 0.18, WOOD_D(), seg=8)
        self.box((x, y, 0.65), (0.5, 0.18, 0.18), METAL_D()); self.box((x + 0.3, y, 0.69), (0.16, 0.1, 0.08), METAL_D())
    def bench(self, x, y, w=1.4, d=0.6, h=0.85, rz=0):
        self.box((x, y, h), (w, d, 0.07), PLANK(), rot=(0, 0, rz))
        for dx in (-1, 1):
            for dy in (-1, 1): self.box((x + dx * (w / 2 - 0.08), y + dy * (d / 2 - 0.08), h / 2), (0.07, 0.07, h), WOOD_D())
    def rack(self, x, y, w=1.6, h=1.6, items=None):
        for dx in (-1, 1): self.post(x + dx * w / 2, y, h, 0.04)
        for z in (h * 0.55, h - 0.05): self.cyl((x - w / 2, y, z), (x + w / 2, y, z), 0.025, WOOD_D(), seg=5)
        if items:
            for i in range(items[1]):
                xx = x - w / 2 + 0.2 + i * (w - 0.4) / max(1, items[1] - 1)
                self.box((xx, y, h - 0.35), (0.12, 0.04, 0.55), items[0]())
    def antenna(self, x, y, z0, h):
        self.cyl((x, y, z0), (x, y, z0 + h), 0.03, METAL(), seg=5)
        for k in range(3): self.cyl((x - 0.3 + 0.1 * k, y, z0 + h * (0.5 + 0.15 * k)), (x + 0.3 - 0.1 * k, y, z0 + h * (0.5 + 0.15 * k)), 0.012, METAL(), seg=4)
        self.ell((x, y, z0 + h), (0.04, 0.04, 0.04), M("redlight", (255, 60, 50), emit=(255, 40, 30), strength=6))
    def cross(self, x, y, h=1.0, m=None):
        self.box((x, y, h / 2), (0.08, 0.08, h), m or WOOD_D()); self.box((x, y, h * 0.72), (0.5, 0.07, 0.07), m or WOOD_D())
    def scrap_pile(self, x, y, s=1.0, seed=1):
        r = random.Random(seed)
        for k in range(int(9 * s)):
            mm = r.choice((RUSTY, METAL_D, CORR, PLANK_OLD))()
            self.box((x + r.uniform(-0.8, 0.8) * s, y + r.uniform(-0.6, 0.6) * s, r.uniform(0.05, 0.4) * s),
                     (r.uniform(0.3, 0.9) * s, r.uniform(0.2, 0.6) * s, r.uniform(0.05, 0.25)), mm, rot=(r.uniform(-0.5, 0.5), r.uniform(-0.5, 0.5), r.uniform(0, 3)))
        self.cyl((x - 0.3 * s, y, 0.2), (x + 0.6 * s, y + 0.3, 0.5 * s), 0.05, RUSTY(), seg=6)
    def tarp_roof(self, x, y, w, d, h, m=None):
        for dx in (-1, 1):
            for dy in (-1, 1): self.post(x + dx * w / 2, y + dy * d / 2, h - 0.15 * (dy > 0), 0.05)
        self.box((x, y, h - 0.07), (w + 0.2, d + 0.2, 0.04), m or TARP(), rot=(0.08, 0, 0))
    def smoke(self, x, y, z, n=3):
        return            # dym i ogien to osobne efekty (VFX), nie czesc modelu
        for k in range(n): self.ell((x + 0.1 * k, y + 0.05 * k, z + 0.35 * k), (0.18 + 0.08 * k, 0.18 + 0.08 * k, 0.14 + 0.06 * k), M("smoke_b", (110, 106, 112)))
    def sign(self, x, y, z, w, m=None):
        self.box((x, y, z), (w, 0.04, 0.32), m or PLANK_OLD())

# ================================================================== ŚWIATŁO
def b_latarnia_pomocnicza(x, y, r=0):
    b = B("lampa_p", x, y, r)
    for a in range(3):
        ang = a * 2.094
        b.cyl((math.cos(ang) * 0.6, math.sin(ang) * 0.6, 0), (0, 0, 3.6), 0.06, WOOD_D(), seg=6)
    b.box((0, 0, 3.6), (0.5, 0.5, 0.08), METAL_D())
    b.ell((0, 0, 3.9), (0.22, 0.22, 0.28), WIN()); b.cyl((0, 0, 4.15), (0, 0, 4.3), 0.25, METAL_D(), r1=0.05, seg=10)
    for a in range(4): b.cyl((0, 0, 3.64), (0.24 * math.cos(a * 1.57), 0.24 * math.sin(a * 1.57), 4.15), 0.015, METAL_D(), seg=4)
    b.light(0, 0, 3.6, 900)
    b.barrel(0.9, 0.4, h=0.8); b.crate(-0.9, 0.3, s=0.5)
    return b

def b_posterunek(x, y, r=0):
    b = B("posterunek", x, y, r)
    for dx in (-1, 1):
        for dy in (-1, 1): b.post(dx * 1.0, dy * 1.0, 3.0, 0.08)
    b.box((0, 0, 3.0), (2.4, 2.4, 0.1), PLANK())
    for s in (1, -1):
        b.box((0, s * 1.15, 3.45), (2.4, 0.06, 0.8), PLANK_OLD()); b.box((s * 1.15, 0, 3.45), (0.06, 2.4, 0.8), PLANK_OLD())
    b.shed(2.6, 2.6, 4.5, 4.9, CORR())
    for dx in (-1, 1): b.post(dx * 1.1, -1.1, 4.5, 0.05); b.post(dx * 1.1, 1.1, 4.9, 0.05)
    b.cyl((0.4, -1.1, 3.95), (1.0, -1.8, 3.6), 0.14, METAL_D(), r1=0.2, seg=10)     # reflektor
    b.ell((1.02, -1.82, 3.58), (0.12, 0.12, 0.12), WIN())
    b.light(1.2, -2.0, 3.5, 500)
    for k in range(10): b.box((0.9, 1.2, 0.3 * k + 0.15), (0.5, 0.04, 0.04), WOOD_D())        # drabina
    for dx in (0.65, 1.15): b.cyl((dx, 1.2, 0), (dx, 1.2, 3.0), 0.03, WOOD_D(), seg=4)
    return b

def b_sklad_paliwa(x, y, r=0):
    b = B("paliwo", x, y, r)
    b.box((0, 0, 0.1), (4.2, 3.0, 0.2), CONCRETE())
    b.tank(-0.9, 0.2, 0.75, 1.6, RUSTY()); b.tank(0.9, 0.3, 0.6, 1.3, METAL())
    for k in range(5): b.barrel(-1.6 + 0.65 * k, -1.1, h=0.85)
    b.barrel(1.5, -0.4, lying=True)
    b.pipe((-0.9, 0.2, 1.2), (0.9, 0.3, 1.2)); b.pipe((0.9, 0.3, 1.2), (1.8, 0.3, 0.3))
    b.fence(-2.1, 1.5, 2.1, 1.5, h=1.2); b.fence(-2.1, -1.5, -2.1, 1.5, h=1.2)
    b.sign(1.9, -1.5, 1.6, 0.8, RED())
    return b

# ================================================================== MIESZKANIE
def b_szalas(x, y, r=0):
    b = B("szalas", x, y, r)
    for k in range(9):
        a = k / 9 * math.pi * 2
        b.cyl((math.cos(a) * 1.3, math.sin(a) * 1.1, 0), (0.05, 0, 2.3), 0.05, WOOD_D(), seg=5)
    b.cyl((0, 0, 0.0), (0, 0, 2.15), 1.35, THATCH(), r1=0.12, seg=9)
    b.cyl((0, 0, 0.05), (0, 0, 1.0), 1.0, TARP(), r1=0.65, seg=9)
    b.box((0, -1.15, 0.6), (0.7, 0.1, 1.2), BLACK())
    b.ell((0, -1.7, 0.08), (0.35, 0.35, 0.08), M("stones", (90, 88, 92))); b.ell((0, -1.7, 0.14), (0.12, 0.12, 0.12), FIRE())
    b.light(0, -1.7, 0.4, 60, (1.0, 0.6, 0.3)); b.sack(0.9, -0.9); b.post(-1.3, -1.2, 1.5, 0.04)
    return b

def b_barak(x, y, r=0):
    b = B("barak", x, y, r)
    b.walls(6.0, 3.2, 2.4, PLANK(), door=("f", 0.0, 0.9), wins=[("f", -1.8, 1.4), ("f", 1.8, 1.4), ("r", 0, 1.4)])
    b.gable(6.0, 3.2, 2.4, 1.1, CORR())
    b.chimney(2.0, 0.6, 2.7, 1.0, METAL_D()); b.smoke(2.0, 0.6, 3.9)
    b.box((0, -2.0, 0.08), (1.4, 0.8, 0.16), PLANK())
    b.barrel(-2.6, -2.0, m=WATER, h=0.8); b.crate(2.6, -2.0); b.sack(2.0, -2.1)
    b.cyl((-3.0, -1.7, 1.8), (3.0, -1.7, 1.8), 0.008, ROPE(), seg=3)
    for k in range(4): b.box((-1.2 + 0.6 * k, -1.7, 1.55), (0.35, 0.02, 0.45), (CLOTHW, RED, GREEN, CLOTHW)[k]())
    return b

def b_dom(x, y, r=0):
    b = B("dom", x, y, r)
    b.walls(4.6, 4.0, 2.7, BRICK(), door=("f", -0.8, 0.95), wins=[("f", 1.0, 1.5), ("r", -0.6, 1.5), ("l", 0.6, 1.5)])
    b.box((0, 0, 2.75), (4.7, 4.1, 0.1), CONCRETE())
    b.gable(4.6, 4.0, 2.8, 1.6, tex_mat("roof_tile", "bands", (120, 60, 50), (138, 72, 58), (100, 52, 46), scale=12.0, axis="DIAGONAL"))
    b.chimney(1.2, 0.8, 3.0, 1.6); b.smoke(1.2, 0.8, 4.8)
    b.box((-0.8, -2.4, 0.1), (1.6, 0.8, 0.2), CONCRETE())
    b.fence(-2.6, -3.2, 2.6, -3.2, h=0.9); b.box((1.6, -2.5, 0.25), (1.2, 0.6, 0.5), DIRT())
    for k in range(4): b.ell((1.2 + 0.25 * k, -2.5, 0.55), (0.1, 0.1, 0.1), GREEN())
    return b

# ================================================================== ŻYWNOŚĆ I WODA
def b_piwnica_grzybowa(x, y, r=0):
    b = B("piwnica", x, y, r)
    b.ell((0, 0.4, 0.0), (2.0, 1.6, 0.9), DIRT())
    b.box((0, -1.2, 0.5), (1.4, 0.2, 1.0), STONE()); b.box((0, -1.26, 0.45), (0.8, 0.05, 0.85), PLANK_V())
    b.box((0, -1.7, 0.02), (1.0, 1.0, 0.04), STONE())
    for k in range(5): b.box((0, -1.5 - 0.15 * k, -0.05 - 0.12 * k), (0.8, 0.3, 0.1), STONE())
    for k, (px, py) in enumerate(((-1.2, 0.2), (1.1, 0.4), (0.6, 1.3), (-0.6, 1.2), (1.5, -0.4))):
        z = 0.55 if abs(px) < 1.3 else 0.2
        b.cyl((px, py, z), (px, py, z + 0.2), 0.03, MUSH(), seg=5); b.ell((px, py, z + 0.22), (0.12, 0.12, 0.05), MUSH_G() if k % 2 else MUSH())
    b.pipe((0.8, 0.6, 0.6), (0.8, 0.6, 1.5), 0.05); b.box((0.8, 0.6, 1.55), (0.18, 0.18, 0.06), METAL_D())
    b.light(0, -1.4, 0.4, 25, (0.5, 1.0, 0.8))
    return b

def b_pole(x, y, r=0):
    b = B("pole", x, y, r)
    b.box((0, 0, 0.06), (5.0, 3.4, 0.12), DIRT())
    rnd = random.Random(3)
    for row in range(5):
        for k in range(9):
            px = -2.1 + k * 0.52; py = -1.3 + row * 0.65
            h = rnd.uniform(0.25, 0.45)
            b.cyl((px, py, 0.12), (px, py, 0.12 + h), 0.02, GREEN(), seg=4)
            b.ell((px, py, 0.12 + h), (0.1, 0.1, 0.07), M("crop", (110, 130, 60)))
    b.fence(-2.6, -1.9, 2.6, -1.9, h=0.8); b.fence(-2.6, 1.9, 2.6, 1.9, h=0.8)
    b.fence(-2.6, -1.9, -2.6, 1.9, h=0.8)
    b.cross(2.9, 0.0, 1.8); b.ell((2.9, 0, 1.85), (0.12, 0.1, 0.13), THATCH())                     # strach na wroble
    b.box((2.9, 0, 1.3), (0.3, 0.2, 0.5), RED())
    b.barrel(2.4, -2.3, m=WATER)
    return b

def b_kuchnia(x, y, r=0):
    b = B("kuchnia", x, y, r)
    b.tarp_roof(0, 0, 4.0, 3.0, 2.6, TARP_R())
    b.box((-0.8, 0.6, 0.45), (1.6, 0.9, 0.9), BRICK()); b.box((-0.8, 0.6, 0.93), (1.7, 1.0, 0.06), METAL_D())
    b.cyl((-1.2, 0.6, 0.96), (-1.2, 0.6, 1.35), 0.28, METAL_D(), seg=10); b.ell((-1.2, 0.6, 1.3), (0.24, 0.24, 0.04), M("soup", (150, 110, 60)))
    b.ell((-0.8, 0.15, 0.3), (0.25, 0.05, 0.12), FIRE()); b.light(-0.8, 0.0, 0.5, 120, (1.0, 0.55, 0.25))
    b.chimney(-0.3, 0.9, 0.95, 2.4, METAL_D()); b.smoke(-0.3, 0.9, 3.5)
    b.bench(1.0, -0.4, 2.2, 0.7, 0.8)
    for k in range(3): b.cyl((0.3 + 0.6 * k, -0.4, 0.84), (0.3 + 0.6 * k, -0.4, 0.94), 0.07, METAL())
    for k in range(2): b.box((0.4 + 1.0 * k, -1.3, 0.25), (0.8, 0.35, 0.5), PLANK())
    b.sack(1.8, 1.1); b.sack(1.5, 1.2); b.barrel(1.8, 0.4, m=WATER, h=0.8)
    return b

def b_wedzarnia(x, y, r=0):
    b = B("wedzarnia", x, y, r)
    b.walls(2.2, 2.2, 2.2, PLANK_OLD(), door=("f", 0, 0.8))
    b.gable(2.2, 2.2, 2.2, 1.2, PLANK())
    b.smoke(0, 0, 3.4, 4)
    b.rack(-0.2, -2.0, 2.4, 1.8, (lambda: M("meat", (140, 60, 50)), 6))
    b.box((1.8, 0.4, 0.5), (0.7, 1.4, 1.0), M("wood_pile", (110, 80, 56)))
    for k in range(5): b.cyl((1.5, -0.2 + 0.3 * k, 1.02), (2.1, -0.2 + 0.3 * k, 1.02), 0.08, WOOD_D(), seg=6)
    b.ell((0, -1.25, 0.15), (0.3, 0.15, 0.1), FIRE()); b.light(0, -1.4, 0.4, 50, (1.0, 0.5, 0.2))
    return b

def b_studnia(x, y, r=0):
    b = B("studnia", x, y, r)
    b.cyl((0, 0, 0), (0, 0, 0.8), 0.7, STONE(), seg=12); b.cyl((0, 0, 0.78), (0, 0, 0.8), 0.55, WATER(), seg=12)
    for dx in (-1, 1): b.post(dx * 0.75, 0, 2.0, 0.07)
    b.cyl((-0.8, 0, 1.6), (0.8, 0, 1.6), 0.06, WOOD_D(), seg=6); b.cyl((0, 0, 1.6), (0, 0, 1.05), 0.008, ROPE(), seg=3)
    b.cyl((0, 0, 0.85), (0, 0, 1.05), 0.12, PLANK(), seg=8); b.cyl((0.8, 0, 1.6), (0.95, 0.15, 1.45), 0.02, METAL_D(), seg=4)
    b.gable(1.8, 1.4, 2.0, 0.6, PLANK(), over=0.1, ridge=False)
    b.barrel(1.2, -0.6, m=WATER, h=0.7); b.cyl((-1.0, -0.6, 0), (-1.0, -0.6, 0.35), 0.18, METAL_D(), seg=8)
    return b

def b_filtr_wody(x, y, r=0):
    b = B("filtr", x, y, r)
    b.box((0, 0, 0.1), (3.6, 2.8, 0.2), CONCRETE())
    b.tank(-0.9, 0.3, 0.7, 1.6, RUSTY()); b.tank(0.9, 0.3, 0.55, 1.0, METAL())
    for k in range(3): b.cyl((-0.6 + 0.6 * k, -0.9, 0.2), (-0.6 + 0.6 * k, -0.9, 0.9), 0.22, M("filter_sand", (160, 140, 100)), seg=8)
    b.pipe((-0.9, 0.3, 1.8), (0.9, 0.3, 1.8)); b.pipe((0.9, 0.3, 1.3), (0.9, -0.9, 1.0)); b.pipe((-0.6, -0.9, 0.9), (0.6, -0.9, 0.9), 0.04)
    b.cyl((1.6, -0.9, 0.2), (1.6, -0.9, 0.7), 0.3, WATER(), seg=10)
    b.box((-1.7, -1.1, 0.9), (0.5, 0.06, 0.6), METAL_D()); b.ell((-1.7, -1.15, 1.0), (0.04, 0.03, 0.04), GLOWG())
    return b

# ================================================================== PRODUKCJA
def b_zlomowisko(x, y, r=0):
    b = B("zlom", x, y, r)
    b.scrap_pile(-1.0, 0.4, 1.4, 2); b.scrap_pile(1.2, 0.8, 1.1, 5)
    b.box((1.4, -0.8, 0.45), (1.8, 0.9, 0.9), RUSTY(), rot=(0, 0.1, 0.3))                                   # wrak
    b.box((1.4, -0.8, 1.0), (1.0, 0.8, 0.3), RUSTY(), rot=(0, 0.1, 0.3))
    for k in range(3): b.post(-2.5, -1.5 + 1.2 * k, 3.2, 0.06)
    b.cyl((-2.5, 0.9, 3.1), (-0.5, 0.9, 2.3), 0.04, METAL_D(), seg=5); b.cyl((-0.5, 0.9, 2.3), (-0.5, 0.9, 1.2), 0.008, ROPE(), seg=3)
    b.box((-0.5, 0.9, 1.15), (0.2, 0.1, 0.1), METAL())
    b.tarp_roof(-1.8, -1.4, 1.6, 1.2, 1.8); b.bench(-1.8, -1.4, 1.2, 0.5, 0.8)
    b.fence(-2.8, -2.2, 2.8, -2.2, h=1.6, step=0.35)
    return b

def b_kuznia(x, y, r=0):
    b = B("kuznia", x, y, r)
    b.walls(4.0, 3.2, 2.5, STONE(), door=("f", -1.0, 1.2), wins=[("r", 0, 1.4)])
    b.gable(4.0, 3.2, 2.5, 1.3, CORR())
    b.chimney(1.3, 0.9, 1.0, 3.6); b.smoke(1.3, 0.9, 4.8, 4)
    b.tarp_roof(0.6, -2.4, 3.2, 1.6, 2.3, CORR())
    b.anvil(0.4, -2.3); b.box((1.6, -2.4, 0.4), (0.9, 0.7, 0.8), BRICK()); b.ell((1.6, -2.4, 0.82), (0.3, 0.25, 0.06), FIRE())
    b.light(1.6, -2.4, 1.1, 180, (1.0, 0.5, 0.2))
    b.cyl((-1.0, -2.4, 0), (-1.0, -2.4, 0.5), 0.3, WATER(), seg=10)
    b.rack(-1.6, -3.0, 1.2, 1.4, (METAL_D, 4))
    return b

def b_szwalnia(x, y, r=0):
    b = B("szwalnia", x, y, r)
    b.walls(4.4, 3.0, 2.4, PLANK(), door=("f", 1.3, 0.9), wins=[("f", -1.0, 1.4), ("l", 0, 1.4)])
    b.gable(4.4, 3.0, 2.4, 1.0, TARP())
    b.cyl((-2.2, -2.0, 2.0), (2.2, -2.0, 2.0), 0.008, ROPE(), seg=3)
    for k in range(6): b.box((-1.9 + 0.75 * k, -2.0, 1.7), (0.5, 0.02, 0.6), (CLOTHW, TARP, RED, lambda: M("blue_c", (60, 74, 110)), CLOTHW, GREEN)[k]())
    for dx in (-2.2, 2.2): b.post(dx, -2.0, 2.1, 0.04)
    b.bench(0.0, -1.0, 1.6, 0.5, 0.8); b.box((0.2, -1.0, 0.95), (0.35, 0.2, 0.25), METAL_D())                 # maszyna do szycia
    for k in range(3): b.cyl((-1.8 + 0.5 * k, -2.4, 0), (-1.8 + 0.5 * k, -2.4, 0.4), 0.2, CLOTHW(), seg=8)        # bele
    return b

def b_garbarnia(x, y, r=0):
    b = B("garbarnia", x, y, r)
    b.tarp_roof(0, 0.8, 3.4, 2.0, 2.3, PLANK_OLD())
    for k in range(3): b.cyl((-1.2 + 1.2 * k, -0.8, 0), (-1.2 + 1.2 * k, -0.8, 0.6), 0.45, WOOD_D(), seg=12); \
        b.cyl((-1.2 + 1.2 * k, -0.8, 0.58), (-1.2 + 1.2 * k, -0.8, 0.6), 0.4, M("tan_liq", (110, 90, 50)), seg=12)
    for k in range(3):
        b.box((-1.2 + 1.2 * k, 1.5, 1.1), (0.9, 0.04, 1.2), LEATHER())                                    # skory na ramach
        b.cyl((-1.65 + 1.2 * k, 1.5, 0), (-1.65 + 1.2 * k, 1.5, 1.8), 0.03, WOOD_D(), seg=4)
        b.cyl((-0.75 + 1.2 * k, 1.5, 0), (-0.75 + 1.2 * k, 1.5, 1.8), 0.03, WOOD_D(), seg=4)
    b.bench(1.3, 0.4, 1.0, 0.6, 0.8); b.box((1.3, 0.4, 0.88), (0.6, 0.4, 0.04), LEATHER())
    b.scrap_pile(2.0, -1.5, 0.4, 9)
    return b

def b_wytwornia_prochu(x, y, r=0):
    b = B("proch", x, y, r)
    b.walls(3.6, 3.0, 2.2, BRICK(), door=("f", 0, 1.0))
    b.box((0, 0, 2.3), (3.8, 3.2, 0.2), CONCRETE()); b.box((0, 0, 2.5), (3.4, 2.8, 0.2), DIRT())               # dach ziemny (wybuchy)
    for dx in (-1, 1): b.box((dx * 2.3, 0, 0.6), (0.6, 3.4, 1.2), DIRT())                                  # waly ochronne
    b.sign(0, -1.6, 2.0, 1.0, RED())
    for k in range(4): b.barrel(-1.4 + 0.9 * k, -2.3, m=lambda: M("powder_k", (64, 62, 70)), h=0.6)
    b.box((1.6, -1.9, 0.3), (0.6, 0.4, 0.6), M("saltpeter", (220, 216, 200)))
    b.cyl((-1.0, 1.9, 0), (-1.0, 1.9, 0.9), 0.4, WOOD_D(), seg=10); b.cyl((-1.0, 1.9, 0.9), (-1.0, 1.9, 1.3), 0.05, WOOD_D(), seg=5)  # mozdzierz
    return b

def b_rusznikarnia(x, y, r=0):
    b = B("rusznik", x, y, r)
    b.walls(4.2, 3.2, 2.6, BRICK(), door=("f", -1.2, 0.9), wins=[("f", 0.8, 1.5), ("r", 0, 1.5)])
    b.shed(4.2, 3.2, 2.6, 3.2, CORR())
    b.chimney(-1.4, 1.0, 2.8, 1.0, METAL_D())
    b.tarp_roof(0.6, -2.3, 2.6, 1.2, 2.2)
    b.bench(0.6, -2.3, 2.0, 0.6, 0.85)
    for k in range(3): b.box((0.0 + 0.5 * k, -2.3, 0.9), (0.6, 0.06, 0.05), METAL_D(), rot=(0, 0, 0.3 * k))
    b.box((-1.8, -2.4, 0.5), (0.5, 0.5, 1.0), METAL_D()); b.ell((-1.8, -2.66, 0.8), (0.05, 0.02, 0.05), GLOWG())   # tokarka
    b.box((1.9, -1.6, 1.3), (0.4, 0.4, 0.08), RED()); b.cross(1.9, -2.2, 1.2, METAL_D())                          # tarcza strzelnicza
    b.ell((1.9, -2.2, 0.9), (0.25, 0.05, 0.25), WHITE())
    return b

def b_topielnia(x, y, r=0):
    b = B("tluszcz", x, y, r)
    b.tarp_roof(0, 0, 3.6, 2.6, 2.4, CORR())
    b.box((-0.6, 0.2, 0.4), (1.4, 1.2, 0.8), BRICK())
    b.cyl((-0.6, 0.2, 0.8), (-0.6, 0.2, 1.4), 0.55, METAL_D(), seg=12); b.cyl((-0.6, 0.2, 1.38), (-0.6, 0.2, 1.4), 0.5, M("fat", (220, 200, 140)), seg=12)
    b.ell((-0.6, -0.4, 0.3), (0.3, 0.1, 0.12), FIRE()); b.light(-0.6, -0.7, 0.5, 90, (1.0, 0.5, 0.2))
    b.smoke(-0.6, 0.2, 2.6, 3)
    for k in range(6): b.cyl((0.9 + 0.3 * (k % 3), -0.6 + 0.35 * (k // 3), 0), (0.9 + 0.3 * (k % 3), -0.6 + 0.35 * (k // 3), 0.35), 0.12, M("candle", (230, 210, 160)), seg=8)
    b.rack(1.2, 0.9, 1.4, 1.6, (lambda: M("tallow", (220, 200, 150)), 5))
    return b

def b_warsztat_maszynowy(x, y, r=0):
    b = B("warsztat", x, y, r)
    b.walls(6.0, 4.2, 3.2, CONCRETE(), door=("f", -1.2, 2.4), wins=[("f", 1.8, 2.0), ("r", 0, 2.0), ("l", 0, 2.0)])
    b.box((0, 0, 3.3), (6.3, 4.5, 0.2), METAL_D())
    for k in range(4): b.box((-2.25 + 1.5 * k, 0, 3.55), (1.2, 4.2, 0.3), CORR(), rot=(0, -0.35, 0))          # dach szedowy
    b.chimney(2.4, 1.4, 3.4, 2.0); b.smoke(2.4, 1.4, 5.6, 4)
    b.box((-1.2, -2.15, 1.25), (2.4, 0.06, 2.5), CORR())
    b.cyl((1.0, -2.8, 0.35), (2.6, -2.8, 0.35), 0.35, METAL_D(), seg=10); b.cyl((1.0, -2.8, 0.35), (0.6, -2.8, 0.35), 0.15, METAL(), seg=8)  # silnik
    b.pipe((2.6, -2.8, 0.35), (2.9, -2.1, 2.5), 0.08)
    b.crate(-2.6, -2.9); b.crate(-2.0, -2.9, s=0.5); b.barrel(-2.9, -2.2, h=0.85)
    b.antenna(-2.5, 1.5, 3.4, 2.5)
    return b

# ================================================================== WOJSKO
def b_zbrojownia(x, y, r=0):
    b = B("zbrojownia", x, y, r)
    b.walls(4.4, 3.4, 2.6, STONE(), door=("f", 0, 1.3))
    b.box((0, -1.72, 1.0), (1.2, 0.05, 2.0), METAL_D()); b.box((0, -1.75, 1.0), (0.1, 0.03, 0.3), METAL())
    b.gable(4.4, 3.4, 2.6, 1.2, CORR())
    b.box((-1.6, -1.72, 2.0), (0.5, 0.04, 0.5), RED())
    b.rack(-1.5, -2.4, 1.6, 1.8, (WOOD_D, 6)); b.rack(1.6, -2.4, 1.4, 1.8, (METAL_D, 5))
    for k in range(3): b.box((0.9 + 0.3 * k, 1.0, 0.25), (0.25, 0.25, 0.5), M("ammo", (70, 80, 56)))
    b.crate(2.6, -1.0); b.crate(2.6, -0.3, s=0.5); b.crate(2.6, -0.7, z=0.6, s=0.45)
    b.lamp(-2.5, -1.6, 2.5)
    return b

def b_akademia(x, y, r=0):
    b = B("akademia", x, y, r)
    b.walls(6.0, 4.0, 3.4, BRICK(), door=("f", 0, 1.2), wins=[("f", -2.0, 1.9), ("f", 2.0, 1.9), ("r", -0.8, 1.9), ("r", 0.8, 1.9)])
    b.box((0, 0, 3.45), (6.2, 4.2, 0.1), CONCRETE())
    b.gable(6.0, 4.0, 3.5, 1.4, tex_mat("roof_tile", "bands", (120, 60, 50), (138, 72, 58), (100, 52, 46), scale=12.0, axis="DIAGONAL"))
    for dx in (-0.9, 0.9): b.cyl((dx, -2.4, 0), (dx, -2.4, 2.6), 0.14, WHITE(), seg=10)                           # kolumny
    b.box((0, -2.4, 2.7), (2.4, 1.0, 0.18), WHITE()); b.box((0, -2.6, 0.1), (2.6, 1.4, 0.2), CONCRETE())
    b.post(2.6, -2.8, 4.2, 0.05); b.box((3.0, -2.8, 3.8), (0.8, 0.02, 0.55), RED())                              # sztandar
    b.box((-2.2, -2.9, 0.5), (1.0, 0.05, 0.7), WHITE()); b.box((-2.2, -2.9, 0.2), (0.05, 0.05, 0.4), WOOD_D())      # tablica
    return b

def b_plac_cwiczen(x, y, r=0):
    b = B("plac", x, y, r)
    b.box((0, 0, 0.03), (6.0, 4.2, 0.06), DIRT())
    for k in range(3):
        b.post(-2.2 + 1.2 * k, 1.4, 1.5, 0.06); b.ell((-2.2 + 1.2 * k, 1.4, 1.1), (0.18, 0.16, 0.32), THATCH()); b.ell((-2.2 + 1.2 * k, 1.4, 1.55), (0.12, 0.12, 0.12), THATCH())
    for k in range(4): b.box((1.2 + 0.4 * k, -0.8, 0.2 + 0.2 * k), (0.4, 1.4, 0.06), PLANK())                       # rampa
    b.box((2.6, -0.8, 0.5), (0.4, 1.4, 1.0), PLANK())
    for k in range(5): b.ell((-2.0 + 0.7 * k, -1.4, 0.15), (0.3, 0.2, 0.15), M("sandbag", (104, 96, 74)))
    for dx in (-0.5, 0.5): b.post(dx - 1.0, -0.2, 2.2, 0.05)
    b.cyl((-1.5, -0.2, 2.1), (-0.5, -0.2, 2.1), 0.03, METAL_D(), seg=5)                                         # drazek
    b.rack(2.4, 1.6, 1.2, 1.4, (WOOD_D, 4))
    return b

def b_wieza(x, y, r=0):
    b = B("wieza", x, y, r)
    for dx in (-1, 1):
        for dy in (-1, 1): b.cyl((dx * 1.0, dy * 1.0, 0), (dx * 0.75, dy * 0.75, 5.0), 0.1, WOOD_D(), seg=6)
    for z in (1.6, 3.2):
        for s in (1, -1):
            b.cyl((-0.95, s * 0.95, z - 0.8), (0.95, s * 0.95, z + 0.6), 0.04, WOOD_D(), seg=4)
            b.cyl((s * 0.95, -0.95, z - 0.8), (s * 0.95, 0.95, z + 0.6), 0.04, WOOD_D(), seg=4)
    b.box((0, 0, 5.0), (2.2, 2.2, 0.12), PLANK())
    for s in (1, -1): b.box((0, s * 1.08, 5.45), (2.2, 0.06, 0.8), PLANK_OLD()); b.box((s * 1.08, 0, 5.45), (0.06, 2.2, 0.8), PLANK_OLD())
    for dx in (-1, 1):
        for dy in (-1, 1): b.post(dx * 1.0, dy * 1.0, 6.6, 0.05) if False else b.cyl((dx * 1.0, dy * 1.0, 5.0), (dx * 1.0, dy * 1.0, 6.6), 0.05, WOOD_D(), seg=5)
    b.gable(2.2, 2.2, 6.6, 0.8, THATCH(), over=0.3)
    for k in range(4): b.ell((0.8 - 0.5 * k, -1.15, 5.95), (0.22, 0.12, 0.12), M("sandbag", (104, 96, 74)))
    b.light(0, 0, 6.0, 120)
    return b

def b_palisada(x, y, r=0, n=12):
    b = B("palisada", x, y, r)
    for k in range(n):
        px = -n * 0.14 + k * 0.28; h = 2.6 + 0.2 * ((k * 5) % 3)
        b.cyl((px, 0, 0), (px, 0, h), 0.13, WOOD_D(), seg=7); b.cyl((px, 0, h), (px, 0, h + 0.3), 0.13, WOOD_D(), r1=0.01, seg=7)
    for z in (0.8, 1.9): b.cyl((-n * 0.14, 0.15, z), (n * 0.14, 0.15, z), 0.05, WOOD_D(), seg=5)
    b.box((0, 0.7, 1.5), (n * 0.28, 0.7, 0.08), PLANK())                                                 # chodnik
    for k in range(4): b.post(-n * 0.14 + 0.2 + k * n * 0.09, 1.0, 1.5, 0.06)
    # odcinek muru z cegly obok
    b.box((n * 0.14 + 1.6, 0, 1.3), (3.0, 0.5, 2.6), BRICK()); b.box((n * 0.14 + 1.6, 0, 2.7), (3.1, 0.6, 0.2), CONCRETE())
    for k in range(4): b.box((n * 0.14 + 0.5 + 0.75 * k, 0, 2.95), (0.4, 0.5, 0.3), BRICK())
    b.cyl((n * 0.14 + 1.6, -0.3, 2.9), (n * 0.14 + 1.6, -0.3, 3.2), 0.4, M("wire", (90, 90, 96)), seg=8)
    return b

def b_brama(x, y, r=0):
    b = B("brama", x, y, r)
    for dx in (-1, 1):
        b.box((dx * 2.0, 0, 2.0), (1.2, 1.2, 4.0), STONE()); b.box((dx * 2.0, 0, 4.1), (1.4, 1.4, 0.2), CONCRETE())
        for k in range(3): b.box((dx * 2.0 - 0.45 + 0.45 * k, -0.55, 4.4), (0.3, 0.3, 0.4), STONE())
        b.lamp(dx * 2.0, -0.7, 4.9, 80)
    b.box((0, 0, 3.6), (2.8, 0.8, 0.5), PLANK())
    for dx in (-1, 1): b.box((dx * 0.7, -0.05, 1.6), (1.35, 0.15, 3.2), PLANK_V(), rot=(0, 0, dx * 0.15))
    for dx in (-1, 1):
        for z in (0.6, 2.6): b.box((dx * 0.7, -0.15, z), (1.3, 0.05, 0.12), METAL_D(), rot=(0, 0, dx * 0.15))
    b.box((0, -0.45, 3.6), (1.2, 0.05, 0.4), RED()); b.ell((0, -0.48, 3.6), (0.12, 0.02, 0.12), M("emb", (255, 210, 110), emit=(255, 200, 100), strength=4))
    return b

# ================================================================== SPOŁECZEŃSTWO
def b_ratusz(x, y, r=0):
    b = B("ratusz", x, y, r)
    b.walls(6.6, 4.6, 3.6, BRICK(), door=("f", 0, 1.4), wins=[("f", -2.2, 2.0), ("f", 2.2, 2.0), ("r", -1.0, 2.0), ("r", 1.0, 2.0), ("l", 0, 2.0)])
    b.gable(6.6, 4.6, 3.6, 1.6, CORR())
    b.box((0, -0.6, 5.2), (1.4, 1.4, 1.4), PLANK()); b.gable(1.4, 1.4, 5.9, 0.9, CORR(), over=0.15)                    # wiezyczka
    b.ell((0, -1.32, 5.25), (0.35, 0.03, 0.35), WHITE()); b.box((0, -1.36, 5.3), (0.03, 0.02, 0.25), BLACK())          # zegar
    b.box((0, -2.6, 0.12), (3.0, 1.2, 0.24), CONCRETE()); b.box((0, -2.9, 0.36), (2.6, 0.6, 0.24), CONCRETE())
    b.post(-2.6, -2.8, 4.6, 0.05); b.box((-2.2, -2.8, 4.2), (0.8, 0.02, 0.6), RED())
    b.lamp(2.6, -2.6, 2.6)
    return b

def b_szpital(x, y, r=0):
    b = B("szpital", x, y, r)
    b.walls(5.6, 3.6, 2.8, PLANK_OLD(), door=("f", 1.6, 1.1), wins=[("f", -1.4, 1.5), ("f", 0.0, 1.5), ("r", 0, 1.5)])
    b.gable(5.6, 3.6, 2.8, 1.1, CORR())
    b.box((-0.7, -1.88, 2.25), (0.7, 0.03, 0.7), WHITE()); b.box((-0.7, -1.9, 2.25), (0.5, 0.02, 0.14), RED()); b.box((-0.7, -1.9, 2.25), (0.14, 0.02, 0.5), RED())
    b.tarp_roof(-1.0, -2.6, 3.4, 1.4, 2.2, CLOTHW())
    for k in range(2): b.box((-2.0 + 1.6 * k, -2.6, 0.5), (1.4, 0.6, 0.08), CLOTHW()); \
        [b.post(-2.6 + 1.6 * k + dx * 1.2, -2.6, 0.5, 0.03) for dx in (0, 1)]
    b.box((-2.0, -2.6, 0.62), (1.2, 0.5, 0.15), M("patient", (120, 100, 80)))
    b.cyl((2.4, -2.4, 0), (2.4, -2.4, 0.8), 0.25, WHITE(), seg=10); b.lamp(2.4, -2.0, 2.4)
    return b

def b_kwarantanna(x, y, r=0):
    b = B("kwarantanna", x, y, r)
    b.walls(3.6, 3.0, 2.4, CONCRETE(), door=("f", 0, 0.9), wins=[("r", 0, 1.8)], lit=False)
    b.box((0, 0, 2.5), (3.8, 3.2, 0.2), CONCRETE())
    for k in range(7): b.cyl((-1.3 + 0.42 * k, -1.62, 1.6), (-1.3 + 0.42 * k, -1.62, 2.1), 0.02, METAL_D(), seg=4)
    b.box((0, -1.6, 1.85), (3.0, 0.05, 0.08), METAL_D())
    for dx, dy in ((-2.6, -2.4), (2.6, -2.4), (2.6, 2.0), (-2.6, 2.0)): b.post(dx, dy, 2.0, 0.05, METAL_D())
    for a, c in (((-2.6, -2.4), (2.6, -2.4)), ((2.6, -2.4), (2.6, 2.0)), ((-2.6, -2.4), (-2.6, 2.0))):
        for z in (0.6, 1.2, 1.8): b.cyl((a[0], a[1], z), (c[0], c[1], z), 0.008, M("wire", (90, 90, 96)), seg=3)
    b.sign(1.6, -2.45, 1.4, 0.8, M("yellow_s", (200, 170, 50)))
    b.light(0, -2.0, 2.2, 60, (0.6, 1.0, 0.6)); b.ell((0, -1.66, 2.25), (0.08, 0.04, 0.08), GLOWG())
    b.barrel(-1.9, -2.0, m=lambda: M("chem", (180, 170, 60)), h=0.8)
    return b

def b_szkola(x, y, r=0):
    b = B("szkola", x, y, r)
    b.walls(5.4, 3.6, 2.8, PLANK(), door=("f", -1.8, 0.9), wins=[("f", 0.0, 1.5), ("f", 1.6, 1.5), ("r", 0, 1.5)])
    b.gable(5.4, 3.6, 2.8, 1.2, THATCH())
    b.box((0, 0, 4.3), (0.6, 0.6, 0.5), PLANK()); b.cyl((0, 0, 4.15), (0, 0, 4.4), 0.12, METAL(), r1=0.18, seg=8)       # dzwonek
    b.box((1.2, -2.6, 0.6), (1.4, 0.06, 0.9), M("board", (40, 60, 50))); [b.post(1.2 + dx * 0.65, -2.6, 1.0, 0.04) for dx in (-1, 1)]
    b.bench(-0.6, -2.4, 1.6, 0.35, 0.45); b.bench(-0.6, -3.1, 1.6, 0.35, 0.45)
    b.fence(-2.8, -3.6, 2.8, -3.6, h=0.7)
    return b

def b_kaplica(x, y, r=0):
    b = B("kaplica", x, y, r)
    b.walls(3.2, 5.0, 3.0, STONE(), door=("f", 0, 1.1), wins=[("r", -1.0, 2.0), ("r", 1.0, 2.0), ("l", -1.0, 2.0), ("l", 1.0, 2.0)])
    b.box((0, 0, 3.0), (3.4, 5.2, 0.1), STONE())
    b2 = b; L = math.hypot(1.9, 2.0); a = math.atan2(2.0, 1.9)
    for s in (1, -1): b.box((s * 0.95, 0, 3.0 + 1.0), (L, 5.6, 0.08), PLANK_OLD(), rot=(0, s * a, 0))
    b.box((0, -2.6, 3.6), (1.2, 0.3, 1.2), STONE()); b.cyl((0, -2.6, 4.2), (0, -2.6, 5.8), 0.4, STONE(), r1=0.05, seg=4)
    b.cross(0, -2.6, 0.0); b.box((0, -2.6, 6.1), (0.07, 0.07, 0.7), METAL()); b.box((0, -2.6, 6.2), (0.4, 0.07, 0.07), METAL())
    b.ell((0, -2.62, 2.3), (0.35, 0.03, 0.35), WIN())
    for k in range(5): b.cyl((-1.6 + 0.8 * k, -3.6, 0), (-1.6 + 0.8 * k, -3.6, 0.2), 0.05, M("candle", (230, 210, 160)), seg=5); \
        b.ell((-1.6 + 0.8 * k, -3.6, 0.25), (0.03, 0.03, 0.05), FIRE())
    b.light(0, -3.6, 0.5, 30, (1.0, 0.7, 0.4))
    return b

def b_radiowezel(x, y, r=0):
    b = B("radio", x, y, r)
    b.walls(3.0, 2.6, 2.4, CONCRETE(), door=("f", -0.6, 0.9), wins=[("f", 0.7, 1.5)])
    b.box((0, 0, 2.5), (3.2, 2.8, 0.2), CONCRETE())
    for dx in (-1, 1):
        for dy in (-1, 1): b.cyl((2.4 + dx * 0.5, dy * 0.5, 0), (2.4, 0, 7.0), 0.04, METAL(), seg=4)
    for z in (2.0, 3.5, 5.0): b.cyl((2.4 - 0.4 * (7 - z) / 7, 0, z), (2.4 + 0.4 * (7 - z) / 7, 0, z), 0.02, METAL(), seg=4)
    b.antenna(2.4, 0, 7.0, 1.0)
    b.cyl((-0.6, -0.6, 2.6), (-0.6, -0.6, 3.4), 0.03, METAL_D(), seg=4); b.cyl((-0.6, -0.6, 3.4), (-0.3, -0.9, 3.5), 0.12, METAL_D(), r1=0.22, seg=8)  # glosnik
    b.cyl((-1.5, 1.3, 2.3), (2.4, 0, 6.5), 0.006, METAL_D(), seg=3)
    return b

def b_pomnik(x, y, r=0):
    b = B("pomnik", x, y, r)
    b.box((0, 0, 0.15), (2.4, 2.4, 0.3), STONE()); b.box((0, 0, 0.9), (1.2, 1.2, 1.2), STONE())
    S = M("bronze", (90, 110, 96))
    b.cyl((-0.15, 0, 1.5), (-0.15, 0, 2.4), 0.09, S, seg=6); b.cyl((0.15, 0, 1.5), (0.12, 0, 2.4), 0.09, S, seg=6)
    b.ell((0, 0, 2.75), (0.22, 0.16, 0.42), S); b.ell((0, 0, 3.3), (0.12, 0.12, 0.14), S)
    b.cyl((0.18, 0, 3.0), (0.6, 0, 3.7), 0.06, S, seg=6); b.ell((0.62, 0, 3.78), (0.12, 0.12, 0.14), WIN())               # uniesiona latarnia
    b.cyl((-0.2, 0, 3.0), (-0.3, 0, 2.4), 0.06, S, seg=6)
    b.box((0, -0.62, 0.9), (0.8, 0.03, 0.4), M("plaque", (150, 130, 70)))
    for k in range(4): b.ell((-0.9 + 0.6 * k, -1.4, 0.06), (0.12, 0.1, 0.06), RED())                                   # kwiaty
    b.light(0.62, -0.4, 3.6, 40)
    return b

def b_sad_areszt(x, y, r=0):
    b = B("sad", x, y, r)
    b.walls(5.0, 3.6, 3.0, STONE(), door=("f", -1.2, 1.2), wins=[("f", 1.0, 1.8), ("l", 0, 1.8)])
    b.gable(5.0, 3.6, 3.0, 1.2, CORR())
    b.box((2.2, 0, 1.2), (2.2, 3.0, 2.4), CONCRETE(), rot=(0, 0, 0)) if False else None
    b.box((3.6, 0, 1.0), (2.0, 2.6, 2.0), CONCRETE()); b.box((3.6, 0, 2.05), (2.2, 2.8, 0.1), METAL_D())                 # cela
    for k in range(6): b.cyl((2.8 + 0.3 * k, -1.32, 0.1), (2.8 + 0.3 * k, -1.32, 1.9), 0.025, METAL_D(), seg=4)
    b.box((-1.2, -2.0, 2.4), (1.2, 0.04, 0.3), PLANK_OLD()); b.box((1.0, -2.0, 2.6), (0.4, 0.04, 0.4), M("scales", (150, 130, 70)))
    b.post(-2.7, -2.4, 2.4, 0.06); b.cyl((-2.7, -2.4, 2.3), (-2.0, -2.4, 2.3), 0.05, WOOD_D(), seg=5)                    # pregierz
    b.box((-2.4, -2.4, 1.4), (0.8, 0.12, 0.2), PLANK())
    return b

def b_cmentarz(x, y, r=0):
    b = B("cmentarz", x, y, r)
    b.box((0, 0, 0.03), (5.0, 4.0, 0.06), DIRT())
    rnd = random.Random(11)
    for row in range(3):
        for k in range(5):
            px = -2.0 + k * 1.0 + rnd.uniform(-0.1, 0.1); py = -1.2 + row * 1.2
            b.box((px, py + 0.35, 0.1), (0.5, 0.9, 0.16), DIRT())
            if (row + k) % 3 == 0: b.box((px, py - 0.15, 0.4), (0.4, 0.1, 0.6), STONE())
            else: b.cross(px, py - 0.15, 0.9 + rnd.uniform(-0.1, 0.1))
    b.fence(-2.6, -2.1, 2.6, -2.1, h=0.9); b.fence(-2.6, -2.1, -2.6, 2.1, h=0.9); b.fence(2.6, -2.1, 2.6, 2.1, h=0.9)
    b.lamp(2.2, -2.3, 2.0, 30)
    b.box((-1.5, 2.3, 0.4), (1.2, 0.6, 0.8), DIRT()); b.cyl((-0.7, 2.2, 0), (-0.6, 2.0, 1.2), 0.025, WOOD_D(), seg=4)  # rozkopany grob i lopata
    return b

# ================================================================== NAUKA I HANDEL
def b_pracownia(x, y, r=0):
    b = B("pracownia", x, y, r)
    b.walls(4.4, 3.4, 2.8, BRICK(), door=("f", -1.3, 0.9), wins=[("f", 0.6, 1.6), ("r", 0, 1.6)])
    b.shed(4.4, 3.4, 2.8, 3.3, CORR())
    for k in range(3): b.box((-1.0 + 1.0 * k, 0.4, 3.35), (0.7, 0.7, 0.05), M("glass_r", (120, 160, 170), emit=(80, 140, 150), strength=0.6))   # swietliki
    b.bench(0.8, -2.3, 2.0, 0.6, 0.85)
    for k in range(4): b.cyl((0.1 + 0.4 * k, -2.3, 0.88), (0.1 + 0.4 * k, -2.3, 1.1), 0.05, M("flask", (120, 200, 160), emit=(90, 200, 140), strength=1.5), seg=6)
    b.tank(-1.7, -2.3, 0.35, 0.9, M("copper", (170, 100, 60))); b.pipe((-1.7, -2.3, 1.4), (0.1, -2.3, 1.3), 0.03)
    b.antenna(1.6, 1.0, 3.3, 1.5)
    return b

def b_prosektorium(x, y, r=0):
    b = B("prosektorium", x, y, r)
    b.walls(4.0, 3.6, 2.6, CONCRETE(), door=("f", 1.2, 1.0), wins=[("l", 0, 1.8)])
    b.box((0, 0, 2.7), (4.2, 3.8, 0.2), CONCRETE())
    b.tarp_roof(-0.6, -2.5, 2.8, 1.4, 2.2, CLOTHW())
    b.box((-0.6, -2.5, 0.85), (1.8, 0.8, 0.08), METAL())
    for dx in (-1, 1): b.box((-0.6 + dx * 0.8, -2.5, 0.42), (0.08, 0.7, 0.84), METAL_D())
    b.ell((-0.6, -2.5, 1.0), (0.7, 0.28, 0.12), M("carcass", (120, 150, 136)))                                        # cialo mutanta
    b.ell((-0.1, -2.5, 1.02), (0.12, 0.08, 0.06), M("flesh_b", (130, 40, 40)))
    for k in range(4): b.cyl((1.4, -2.4 + 0.3 * k, 0), (1.4, -2.4 + 0.3 * k, 0.5), 0.12, M("jar", (150, 170, 120), emit=(110, 160, 80), strength=1.0), seg=8)
    b.light(-0.6, -2.5, 2.0, 80, (0.7, 1.0, 0.8))
    b.rack(-1.6, 2.0, 1.4, 1.6, (BONE, 4))
    return b

def b_targ(x, y, r=0):
    b = B("targ", x, y, r)
    cols = (TARP_R, TARP, lambda: M("tarp_y", (170, 140, 60)))
    for k in range(3):
        cx = -2.2 + 2.2 * k
        b.tarp_roof(cx, 0.4, 1.8, 1.4, 2.2, cols[k])
        b.bench(cx, -0.2, 1.6, 0.6, 0.9)
        for j in range(3): b.box((cx - 0.5 + 0.5 * j, -0.2, 1.0), (0.3, 0.3, 0.2), (PLANK, METAL_D, LEATHER)[(j + k) % 3]())
        b.sack(cx + 0.6, 0.8); b.crate(cx - 0.6, 0.8, s=0.5)
    b.lamp(3.6, -0.8, 2.4); b.barrel(-3.6, -0.6, h=0.8)
    b.sign(0, -1.3, 2.4, 1.6, PLANK_OLD()); [b.post(dx, -1.3, 2.5, 0.04) for dx in (-0.8, 0.8)]
    return b

def b_stacja_karawan(x, y, r=0):
    b = B("karawany", x, y, r)
    b.box((0, 0, 0.03), (7.0, 4.6, 0.06), DIRT())
    b.walls(3.0, 2.6, 2.4, PLANK(), door=("f", 0.6, 0.9), wins=[("f", -0.6, 1.4)])
    for g in [b]: pass
    b.gable(3.0, 2.6, 2.4, 1.0, CORR()) if False else b.shed(3.0, 2.6, 2.4, 2.9, CORR())
    b2 = B("woz", x, y, r)
    # woz na kolach z plandeka
    for dx in (-0.9, 0.9):
        for dy in (-0.7, 0.7): b2.cyl((2.6 + dx, -1.4 + dy - 0.05, 0.45), (2.6 + dx, -1.4 + dy + 0.05, 0.45), 0.45, WOOD_D(), seg=12)
    b2.box((2.6, -1.4, 0.95), (2.4, 1.2, 0.2), PLANK())
    for k in range(4): b2.cyl((1.6 + 0.65 * k, -2.0, 1.0), (1.6 + 0.65 * k, -0.8, 1.0), 0.04, WOOD_D(), seg=4) if False else None
    b2.cyl((1.5, -1.4, 1.05), (3.7, -1.4, 1.05), 0.65, CLOTHW(), seg=12) if False else b2.ell((2.6, -1.4, 1.35), (1.2, 0.62, 0.55), CLOTHW())
    b2.cyl((1.4, -1.4, 0.8), (0.4, -1.4, 0.5), 0.04, WOOD_D(), seg=4)
    b.fence(-3.4, 1.8, 3.4, 1.8, h=1.2); b.post(-3.2, -2.1, 2.2, 0.06); b.box((-3.2, -2.1, 2.2), (0.9, 0.08, 0.3), PLANK_OLD())
    b.crate(-2.4, -1.6); b.crate(-2.4, -1.0, s=0.5); b.sack(-1.8, -1.8); b.barrel(-2.9, 1.0, m=WATER, h=0.8)
    b.lamp(-1.6, -2.0, 2.4)
    return b

CATALOG = [
    ("Lampa pomocnicza", b_latarnia_pomocnicza), ("Posterunek świetlny", b_posterunek), ("Skład paliwa", b_sklad_paliwa),
    ("Szałas", b_szalas), ("Barak", b_barak), ("Dom", b_dom),
    ("Piwnica grzybowa", b_piwnica_grzybowa), ("Pole przy latarni", b_pole), ("Kuchnia", b_kuchnia),
    ("Wędzarnia", b_wedzarnia), ("Studnia", b_studnia), ("Filtr wody", b_filtr_wody),
    ("Złomowisko", b_zlomowisko), ("Kuźnia", b_kuznia), ("Szwalnia", b_szwalnia),
    ("Garbarnia", b_garbarnia), ("Wytwórnia prochu", b_wytwornia_prochu), ("Rusznikarnia", b_rusznikarnia),
    ("Topielnia tłuszczu", b_topielnia), ("Warsztat maszynowy", b_warsztat_maszynowy), ("Zbrojownia", b_zbrojownia),
    ("Akademia", b_akademia), ("Plac ćwiczeń", b_plac_cwiczen), ("Wieża strażnicza", b_wieza),
    ("Palisada i mur", b_palisada), ("Brama", b_brama), ("Ratusz", b_ratusz),
    ("Szpital", b_szpital), ("Kwarantanna", b_kwarantanna), ("Szkoła", b_szkola),
    ("Kaplica", b_kaplica), ("Radiowęzeł", b_radiowezel), ("Pomnik", b_pomnik),
    ("Sąd i areszt", b_sad_areszt), ("Cmentarz", b_cmentarz), ("Pracownia", b_pracownia),
    ("Prosektorium", b_prosektorium), ("Targ", b_targ), ("Stacja karawan", b_stacja_karawan),
]
