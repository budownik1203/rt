"""Szybki podglad klipow walki (Workbench): arkusz klatek do oceny poz.
python3 preview_combat.py -- jednostka klip1,klip2 [klatek_na_klip] [yaw]"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
import export_combat as E
import anim_combat as AC
from lat3d import *
import bpy
from PIL import Image, ImageDraw, ImageFont

args = sys.argv[sys.argv.index("--") + 1:]
unit = args[0]; clips = args[1].split(","); per = int(args[2]) if len(args) > 2 else 6; yaw = float(args[3]) if len(args) > 3 else -40
E.fresh()
if unit in E.U:
    kind, outfit, acc = E.U[unit]; r = E.build_human(unit, kind, outfit, acc)
else:
    kind, idx = E.BANDITS[unit]; r = E.build_bandit(unit, kind, idx)
S = AC.human_set(kind)
sc = bpy.context.scene
sc.render.engine = "BLENDER_WORKBENCH"
sc.display.shading.light = "STUDIO"; sc.display.shading.color_type = "MATERIAL"
sc.display.shading.show_shadows = False; sc.display.shading.show_cavity = True
sc.render.resolution_x = 260; sc.render.resolution_y = 300
sc.render.image_settings.file_format = "PNG"
box("ground", (0, 0, -0.02), (6, 6, 0.04), mat("g", (80, 80, 76)))
cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam")); bpy.context.collection.objects.link(cam)
cam.data.type = "ORTHO"; cam.data.ortho_scale = 2.9
yr = math.radians(yaw); tilt = math.radians(62)
target = V((0.0, 0, 0.85)); d = V((math.cos(yr) * math.sin(tilt), math.sin(yr) * math.sin(tilt), math.cos(tilt)))
cam.location = target + d * 10
cam.rotation_euler = (tilt, 0, yr + math.pi / 2)
sc.camera = cam
os.makedirs("/tmp/prev", exist_ok=True)
font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13)
rows = []
for cn in clips:
    n, fn = S[cn]
    frames = sorted(set(int(round(i * n / max(1, per - 1))) for i in range(per))) if n > 1 else [0]
    imgs = []
    for f in frames:
        for pb in r.ob.pose.bones: pb.scale = (1, 1, 1)
        E.apply_ext(r, fn(f)); bpy.context.view_layer.update()
        sc.render.filepath = "/tmp/prev/f.png"; bpy.ops.render.render(write_still=True)
        im = Image.open("/tmp/prev/f.png").convert("RGB"); ImageDraw.Draw(im).text((4, 4), "%s %d" % (cn, f), fill=(255, 255, 0), font=font)
        imgs.append(im)
    rows.append(imgs)
W = max(len(r_) for r_ in rows) * 260; H = len(rows) * 300
sheet = Image.new("RGB", (W, H), (30, 30, 30))
for y, row in enumerate(rows):
    for x, im in enumerate(row): sheet.paste(im, (x * 260, y * 300))
out = "/tmp/prev/%s_%s.png" % (unit, "_".join(clips))[:120]
sheet.save(out); print("SHEET", out)
