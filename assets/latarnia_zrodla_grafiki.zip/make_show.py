import sys, math
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont

W, H, ORT, TILT, CAMYAW = 640, 320, 16.5, 50, -25
S = 2
NAMES = [["Chód", "Bieg z bronią", "Strzał (odrzut)", "Przeładowanie", "Osłona i wychylenie"],
         ["Pchnięcie dzidą", "Cios młotem", "Rzut granatem", "Trafienie i śmierć", "Patrol"]]
COLS = [-5.6, -2.8, 0.0, 2.8, 5.6]; ROWS = [1.9, -1.9]
t = math.radians(TILT)
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 13)

def label(im):
    d = ImageDraw.Draw(im)
    for ri, row in enumerate(NAMES):
        for ci, n in enumerate(row):
            x = (W / 2 + COLS[ci] * W / ORT) * S
            y = (H / 2 - (ROWS[ri] * math.cos(t) - 0.8 * math.sin(t)) * W / ORT) * S + 22
            w = d.textlength(n, font=font)
            d.rectangle((x - w / 2 - 4, y - 2, x + w / 2 + 4, y + 15), fill=(20, 17, 28))
            d.text((x - w / 2, y - 1), n, font=font, fill=(226, 200, 150))
    return im

fr = [label(stylize('out/show_%02d.exr' % f).resize((W * S, H * S), Image.NEAREST)) for f in range(24)]
fr[0].save('out/latarnia3d_animacje.gif', save_all=True, append_images=fr[1:], duration=83, loop=0)
fr[9].save('out/latarnia3d_animacje_kl09.png')
# wolniejsze zblizenie srodkowego rzedu akcji (strzal, przeladowanie, oslona) x4
cr = [stylize('out/show_%02d.exr' % f).crop((300, 40, 620, 170)).resize((1280, 520), Image.NEAREST) for f in range(24)]
cr[0].save('out/latarnia3d_animacje_zblizenie.gif', save_all=True, append_images=cr[1:], duration=125, loop=0)
