"""Bestiariusz: reszta mutantow z dokumentu. Kazdy zwraca (rig, poza_spoczynkowa)."""
import math, random
from mathutils import Vector as V
from lat3d import Rig, mat, box, cyl, loft, ellipsoid
from chars import human_bones, bone_pts, M, PALE, FLESH, CHITIN, CHITIN_L, GLOW_RED, GLOW_YEL, EYE, TOOTH, METAL, METAL_D, RUST, STRAP, cloth, human
from anim import P, merge, stance

def F(n, c, e, s): return M("bx_" + n, c, emit=e, strength=s)
C = lambda n, c: M("bx_" + n, c)
SICK = lambda: C("sick", (150, 150, 128)); GREY = lambda: C("greyskin", (120, 122, 118)); BRUISE = lambda: C("bruise", (110, 84, 104))
VEIN = lambda: F("vein", (200, 90, 80), (220, 60, 50), 1.5); GHOST = lambda: F("ghost", (150, 180, 205), (110, 150, 200), 0.35)

def body(rig, n, m, k=1.0, head=True, hc=None, hr=(0.10, 0.09, 0.12)):
    A = rig.attach
    A(loft(n + "_tlo", [((0, 0, 0.90), 0.09 * k, 0.12 * k), ((0, 0, 1.12), 0.08 * k, 0.11 * k), ((0, 0, 1.26), 0.085 * k, 0.12 * k)], m), "spine")
    A(loft(n + "_tup", [((0, 0, 1.22), 0.085 * k, 0.12 * k), ((0, 0, 1.36), 0.10 * k, 0.15 * k), ((0, 0, 1.47), 0.08 * k, 0.13 * k), ((0, 0, 1.52), 0.04, 0.05)], m), "chest")
    for s, nn in ((1, "L"), (-1, "R")):
        for b, r0, r1 in (("upperarm", 0.045, 0.036), ("forearm", 0.035, 0.028), ("thigh", 0.065, 0.05), ("shin", 0.048, 0.036)):
            h, t = bone_pts(rig, b + "." + nn); A(loft(n + "_" + b + nn, [(h, r0 * k, r0 * k), (t, r1 * k, r1 * k)], m), b + "." + nn)
        h, t = bone_pts(rig, "upperarm." + nn); A(ellipsoid(n + "_sh" + nn, h, (0.05 * k, 0.05 * k, 0.05 * k), m), "upperarm." + nn)
        h, t = bone_pts(rig, "forearm." + nn); A(ellipsoid(n + "_el" + nn, h, (0.04 * k, 0.04 * k, 0.04 * k), m), "forearm." + nn)
        h, t = bone_pts(rig, "hand." + nn); A(ellipsoid(n + "_hd" + nn, (h + t) / 2, (0.035, 0.03, 0.05), m), "hand." + nn)
        h, t = bone_pts(rig, "shin." + nn); A(ellipsoid(n + "_kn" + nn, h, (0.055 * k, 0.05 * k, 0.05 * k), m), "shin." + nn)
        h, t = bone_pts(rig, "foot." + nn); A(loft(n + "_ft" + nn, [(h, 0.04, 0.035), (t, 0.025, 0.035)], m), "foot." + nn)
    hn, ht = bone_pts(rig, "neck")
    A(cyl(n + "_nk", hn, ht, 0.04, m), "neck")
    hc = hc or (V(bone_pts(rig, "head")[0]) + V((0.012, 0, 0.10)))
    if head: A(ellipsoid(n + "_hd", hc, hr, m), "head")
    return hc

# ------------------------------------------------------------------ Odmieniec: czlowiek w strzepach ubrania, jedno ramie przerosniete
def odmieniec(n):
    r = Rig(n, human_bones(arm=1.05)); r.objs = {}; A = r.attach
    hc = body(r, n, SICK())
    A(loft(n + "_rags", [((0, 0, 1.05), 0.11, 0.15), ((0, 0, 1.30), 0.11, 0.16), ((0, 0, 1.44), 0.1, 0.15)], cloth("brown")), "chest")
    h, t = bone_pts(r, "upperarm.R"); A(loft(n + "_bigU", [(h, 0.10, 0.10), ((h + t) / 2, 0.11, 0.10), (t, 0.08, 0.08)], FLESH()), "upperarm.R")
    h, t = bone_pts(r, "forearm.R"); A(loft(n + "_bigF", [(h, 0.09, 0.09), (t, 0.10, 0.10)], FLESH()), "forearm.R")
    h, t = bone_pts(r, "hand.R"); A(ellipsoid(n + "_claw", t, (0.09, 0.07, 0.12), CHITIN_L()), "hand.R")
    for k in range(4): A(loft(n + "_spk%d" % k, [(h + V((0.04 * (k - 1.5), -0.05, -0.1)), 0.015, 0.015), (h + V((0.05 * (k - 1.5), -0.07, -0.25)), 0.002, 0.002)], TOOTH(), seg=4), "hand.R")
    for k in range(5): A(ellipsoid(n + "_boil%d" % k, (0.06 + 0.02 * k, -0.08 + 0.04 * k, 1.2 + 0.05 * k), (0.03, 0.03, 0.03), VEIN()), "chest")
    for s in (1, -1): A(ellipsoid(n + "_e%d" % s, hc + V((0.09, s * 0.04, 0.02)), (0.016, 0.018, 0.016), GLOW_RED()), "head")
    A(ellipsoid(n + "_jaw", hc + V((0.06, 0, -0.07)), (0.06, 0.07, 0.05), FLESH()), "head")
    pose = P(rot={"spine": (0, 14, 0), "chest": (0, 6, -10), "neck": (0, 12, 0), "head": (0, -8, 10), "upperarm.R": (-16, -10, 0), "forearm.R": (0, -20, 0),
                  "upperarm.L": (10, 10, 0), "forearm.L": (0, -30, 0), "thigh.L": (0, -12, 0), "shin.L": (0, 16, 0), "thigh.R": (0, 10, 0), "shin.R": (0, 10, 0)}, loc={"hips": (0, 0, -0.04)})
    return r, pose

# ------------------------------------------------------------------ Nasladowca: dluga szyja, usta na gardle, twarz jak maska
def nasladowca(n):
    r = Rig(n, human_bones(arm=1.15, torso=1.1)); A = r.attach
    hn, ht = bone_pts(r, "neck")
    hc = body(r, n, GREY(), k=0.85, head=False)
    A(cyl(n + "_lneck", hn, hn + V((0.06, 0, 0.32)), 0.05, GREY(), r1=0.04), "neck")
    A(ellipsoid(n + "_mouthN", hn + V((0.05, 0, 0.14)), (0.03, 0.04, 0.07), C("maw", (40, 20, 24))), "neck")
    hcc = hn + V((0.09, 0, 0.42))
    A(ellipsoid(n + "_face", hcc, (0.07, 0.09, 0.11), C("mask_face", (200, 176, 150))), "head")
    for s in (1, -1): A(ellipsoid(n + "_eh%d" % s, hcc + V((0.06, s * 0.035, 0.02)), (0.01, 0.018, 0.008), EYE()), "head")
    A(box(n + "_smile", hcc + V((0.068, 0, -0.04)), (0.01, 0.07, 0.01), EYE()), "head")
    pose = P(rot={"spine": (0, 22, 0), "chest": (0, 10, 0), "neck": (0, -30, 0), "head": (0, 30, 20), "upperarm.L": (14, -20, 0), "upperarm.R": (-14, -24, 0),
                  "forearm.L": (0, -40, 0), "forearm.R": (0, -30, 0), "thigh.L": (0, -24, 0), "shin.L": (0, 40, 0), "thigh.R": (0, -10, 0), "shin.R": (0, 30, 0)}, loc={"hips": (0, 0, -0.12)})
    return r, pose

# ------------------------------------------------------------------ Spiacy: stoi nieruchomo, oblepiony bladym kokonem, glowa zwieszona
def spiacy(n):
    r = Rig(n, human_bones()); A = r.attach
    hc = body(r, n, PALE())
    A(loft(n + "_cocoon", [((0, 0, 0.35), 0.16, 0.2), ((0, 0, 0.95), 0.18, 0.22), ((0, 0, 1.40), 0.15, 0.22), ((0, 0, 1.70), 0.08, 0.1)], C("cocoon", (178, 182, 170)), seg=12), "spine")
    rnd = random.Random(2)
    for k in range(7): A(loft(n + "_strand%d" % k, [((rnd.uniform(-0.1, 0.1), rnd.uniform(-0.2, 0.2), 1.6), 0.012, 0.012), ((rnd.uniform(-0.3, 0.3), rnd.uniform(-0.4, 0.4), 0.0), 0.006, 0.006)], C("cocoon", (178, 182, 170)), seg=4), "spine")
    A(ellipsoid(n + "_pulse", (0.12, 0, 1.25), (0.05, 0.07, 0.07), F("pulse", (150, 200, 170), (120, 200, 150), 1.5)), "chest")
    pose = P(rot={"neck": (0, 40, 0), "head": (0, 20, 0), "spine": (0, 4, 0)})
    return r, pose

# ------------------------------------------------------------------ Zrosnieci: dwa tulowie zrosniete w pasie, cztery rece
def zrosnieci(n):
    r = Rig(n, human_bones(leg=0.95)); A = r.attach
    hc = body(r, n, BRUISE(), k=1.1)
    A(loft(n + "_twin", [((-0.05, 0.12, 1.1), 0.08, 0.1), ((-0.1, 0.22, 1.35), 0.09, 0.12), ((-0.12, 0.26, 1.5), 0.06, 0.08)], BRUISE()), "chest")
    A(ellipsoid(n + "_th", (-0.13, 0.28, 1.65), (0.09, 0.08, 0.1), BRUISE()), "chest")
    for s in (1, -1): A(ellipsoid(n + "_te%d" % s, (-0.06, 0.28 + s * 0.03, 1.67), (0.012, 0.014, 0.012), GLOW_RED()), "chest")
    for k, (p0, p1) in enumerate((((-0.08, 0.32, 1.45), (0.1, 0.42, 1.05)), ((-0.15, 0.3, 1.42), (-0.1, 0.45, 0.95)))):
        A(loft(n + "_xa%d" % k, [(p0, 0.035, 0.035), (p1, 0.028, 0.028)], BRUISE()), "chest"); A(ellipsoid(n + "_xh%d" % k, p1, (0.035, 0.03, 0.05), BRUISE()), "chest")
    A(loft(n + "_seam", [((0.05, 0.08, 0.95), 0.012, 0.012), ((-0.02, 0.15, 1.35), 0.012, 0.012)], VEIN()), "chest")
    for s in (1, -1): A(ellipsoid(n + "_e%d" % s, hc + V((0.09, s * 0.04, 0.02)), (0.016, 0.018, 0.016), GLOW_RED()), "head")
    pose = P(rot={"spine": (0, 8, 8), "chest": (0, 4, -6), "head": (0, -6, -8), "upperarm.L": (20, -10, 0), "upperarm.R": (-24, -16, 0), "forearm.L": (0, -30, 0), "forearm.R": (0, -40, 0),
                  "thigh.L": (0, -8, 6), "thigh.R": (0, 8, -6)})
    return r, pose

# ------------------------------------------------------------------ Dawny Zolnierz: zrosniety z maska i helmem, nadal z karabinem
def dawny_zolnierz(n):
    r = human(n, dict(skin="pale", jacket="olive", pants="olive", helmet="mil", mask="gas", glow_eyes=True, armor="vest"), "rifle")
    A = r.attach; hc = V((0.012, 0, 1.635))
    for k in range(6): A(ellipsoid(n + "_gr%d" % k, (0.1, -0.12 + 0.05 * k, 1.05 + 0.07 * k), (0.035, 0.03, 0.035), FLESH()), "chest")
    A(loft(n + "_tube", [(hc + V((0.2, 0, -0.09)), 0.014, 0.014), ((0.12, 0.08, 1.35), 0.014, 0.014), ((-0.05, 0.12, 1.2), 0.014, 0.014)], VEIN(), seg=5), "head")
    A(ellipsoid(n + "_helmgrow", hc + V((-0.05, 0.06, 0.12)), (0.06, 0.05, 0.05), FLESH()), "head")
    pose = merge(stance(), P(rot={"weapon": (0, 6, 0), "spine": (0, 10, 0), "head": (0, 8, 14)}, loc={"weapon": (0, 0, 0.02)}))
    return r, pose

# ------------------------------------------------------------------ Opiekunka: wysoka, chuda, dlugie rece z kolyska z kosci na plecach
def opiekunka(n):
    r = Rig(n, human_bones(arm=1.7, leg=1.25, torso=1.15)); A = r.attach
    hc = body(r, n, PALE(), k=0.8, hr=(0.085, 0.075, 0.13))
    hn, _ = bone_pts(r, "head")
    A(loft(n + "_veil", [(hc + V((-0.02, 0, 0.1)), 0.11, 0.1), (hc + V((-0.04, 0, -0.1)), 0.14, 0.14), (hc + V((-0.06, 0, -0.45)), 0.2, 0.22)], C("veil", (60, 58, 66)), seg=12), "head")
    for s in (1, -1): A(ellipsoid(n + "_e%d" % s, hc + V((0.075, s * 0.03, 0.03)), (0.01, 0.012, 0.012), F("eyeY", (255, 230, 150), (255, 220, 120), 4)), "head")
    for k in range(5):
        a = -0.7 + 0.35 * k
        A(loft(n + "_rib%d" % k, [((-0.12, 0, 1.75), 0.012, 0.012), ((-0.32, 0.25 * math.sin(a), 1.75 - 0.25 * math.cos(a) * 0.4), 0.01, 0.01), ((-0.3, 0.22 * math.sin(a), 1.35), 0.008, 0.008)], C("bone", (210, 200, 176)), seg=4), "chest")
    pose = P(rot={"spine": (0, 16, 0), "chest": (0, 12, 0), "neck": (0, 20, 0), "head": (0, -10, 0), "upperarm.L": (12, -30, 0), "upperarm.R": (-12, -40, 0),
                  "forearm.L": (0, -40, 0), "forearm.R": (0, -30, 0), "thigh.L": (0, -6, 0), "thigh.R": (0, 6, 0)})
    return r, pose

# ------------------------------------------------------------------ Pielgrzym: szata, worek, kostur bez swiatla, oczy zawiazane
def pielgrzym(n):
    r = human(n, dict(jacket="grey", pants="grey", strap=False), "spear"); A = r.attach
    import bpy
    for k in ("_shield", "_boss", "_shrim", "_spearhead"): bpy.data.objects[n + k].hide_render = True
    A(loft(n + "_robe", [((0, 0, 1.0), 0.14, 0.18), ((0, 0, 0.6), 0.19, 0.22), ((0, 0, 0.12), 0.24, 0.26)], C("pil_robe", (120, 110, 96)), seg=14), "hips")
    hc = V((0.012, 0, 1.635))
    A(ellipsoid(n + "_hood", hc + V((-0.02, 0, 0.03)), (0.16, 0.135, 0.165), C("pil_hood", (104, 96, 84)), clip_z=-0.12), "head")
    A(loft(n + "_blind", [(hc + V((0, 0, 0.03)), 0.125, 0.11), (hc + V((0, 0, 0.0)), 0.125, 0.11)], C("blindfold", (190, 180, 160))), "head")
    A(box(n + "_sack", (-0.2, 0, 1.15), (0.16, 0.26, 0.3), C("sack", (150, 130, 96))), "chest")
    pose = merge(stance(), P(rot={"spine": (0, 10, 0), "head": (0, 10, 0)}))
    return r, pose

# ------------------------------------------------------------------ Echo: widmo poleglego (swiecaca, pol-przezroczysta sylwetka)
def echo(n):
    r = human(n, dict(jacket="grey", pants="grey", helmet="mil"), "rifle")
    import bpy
    G = GHOST()
    for o in r.parts:
        if o.type == "MESH": o.data.materials.clear(); o.data.materials.append(G)
    pose = merge(stance(), P(rot={"weapon": (0, 30, 0), "head": (0, 20, 0), "spine": (0, 6, 0)}, root=(0, 0, 0.12, 0)))
    return r, pose

# ------------------------------------------------------------------ Pasterz: wysoki, z rogami i kosturem, dowodzi mutantami
def pasterz(n):
    r = Rig(n, human_bones(arm=1.3, leg=1.2, torso=1.15, pose="spear")); A = r.attach
    hc = body(r, n, CHITIN(), k=1.15, hr=(0.11, 0.1, 0.14))
    A(loft(n + "_mant", [((-0.1, 0, 1.6), 0.05, 0.25), ((-0.2, 0, 1.0), 0.05, 0.32), ((-0.24, 0, 0.3), 0.05, 0.36)], C("mantle", (50, 40, 56)), seg=8), "chest")
    for s in (1, -1):
        A(loft(n + "_horn%d" % s, [(hc + V((-0.02, s * 0.07, 0.08)), 0.035, 0.035), (hc + V((-0.1, s * 0.2, 0.2)), 0.02, 0.02), (hc + V((-0.05, s * 0.28, 0.42)), 0.002, 0.002)], CHITIN_L(), seg=6), "head")
        A(ellipsoid(n + "_e%d" % s, hc + V((0.1, s * 0.04, 0.02)), (0.018, 0.02, 0.018), F("eyeP", (220, 140, 255), (200, 120, 255), 5)), "head")
    A(ellipsoid(n + "_eye3", hc + V((0.105, 0, 0.07)), (0.02, 0.02, 0.02), F("eyeP", (220, 140, 255), (200, 120, 255), 5)), "head")
    wb = bone_pts(r, "weapon")
    A(cyl(n + "_staff", (0.29, -0.3, 0.05), (0.31, -0.3, 2.4), 0.025, C("bonest", (180, 170, 150)), seg=6), "weapon")
    A(ellipsoid(n + "_skullS", (0.31, -0.3, 2.45), (0.07, 0.06, 0.08), C("bone", (210, 200, 176))), "weapon")
    A(ellipsoid(n + "_orbS", (0.31, -0.3, 2.56), (0.04, 0.04, 0.04), F("eyeP", (220, 140, 255), (200, 120, 255), 5)), "weapon")
    for b in ("shield",):
        pass
    pose = P(rot={"spine": (0, 6, 0), "head": (0, -6, 0), "upperarm.R": (-10, -30, 0), "forearm.R": (0, -50, 0), "upperarm.L": (24, 10, 0), "forearm.L": (0, -40, 0)})
    return r, pose

# ------------------------------------------------------------------ Bezoki: na czworakach, bez oczu, wielkie uszy (sluch)
def bezoki(n):
    r = Rig(n, human_bones(arm=1.25, leg=0.9)); A = r.attach
    hc = body(r, n, GREY(), k=0.9, hr=(0.11, 0.1, 0.11))
    for s in (1, -1):
        A(loft(n + "_ear%d" % s, [(hc + V((-0.02, s * 0.08, 0.02)), 0.04, 0.02), (hc + V((-0.1, s * 0.22, 0.12)), 0.08, 0.01), (hc + V((-0.16, s * 0.3, 0.2)), 0.01, 0.005)], C("earpink", (170, 120, 120)), seg=6), "head")
    A(ellipsoid(n + "_maw", hc + V((0.09, 0, -0.04)), (0.03, 0.06, 0.03), C("maw", (40, 20, 24))), "head")
    for k in range(5): A(loft(n + "_t%d" % k, [(hc + V((0.1, -0.04 + 0.02 * k, -0.025)), 0.006, 0.006), (hc + V((0.1, -0.04 + 0.02 * k, -0.055)), 0.001, 0.001)], TOOTH(), seg=4), "head")
    pose = P(rot={"spine": (0, 50, 0), "chest": (0, 24, 0), "neck": (0, -40, 0), "head": (0, -30, 0), "upperarm.L": (6, -70, 0), "upperarm.R": (-6, -64, 0),
                  "forearm.L": (0, 30, 0), "forearm.R": (0, 26, 0), "thigh.L": (0, -60, 0), "shin.L": (0, 100, 0), "thigh.R": (0, -40, 0), "shin.R": (0, 110, 0), "foot.L": (0, -30, 0), "foot.R": (0, -50, 0)},
             loc={"hips": (-0.1, 0, -0.42)})
    return r, pose

# ------------------------------------------------------------------ Cma: wielka cma ciagnaca do swiatla
def cma(n):
    B = [("body", (0, 0, 1.4), (0.3, 0, 1.45), None)]
    for s, nn in ((1, "L"), (-1, "R")):
        B += [("wing." + nn, (0.05, s * 0.05, 1.45), (0.05, s * 0.6, 1.5), "body"), ("wing2." + nn, (-0.08, s * 0.05, 1.42), (-0.25, s * 0.5, 1.4), "body")]
    r = Rig(n, B); A = r.attach
    A(loft(n + "_abd", [((-0.32, 0, 1.36), 0.04, 0.04), ((-0.1, 0, 1.39), 0.11, 0.1), ((0.1, 0, 1.43), 0.09, 0.09), ((0.24, 0, 1.46), 0.07, 0.07)], C("mothfur", (130, 116, 96))), "body")
    for s in (1, -1):
        A(ellipsoid(n + "_eye%d" % s, (0.26, s * 0.04, 1.47), (0.03, 0.03, 0.03), F("motheye", (255, 120, 60), (255, 100, 40), 4)), "body")
        A(loft(n + "_ant%d" % s, [((0.27, s * 0.02, 1.5), 0.006, 0.006), ((0.4, s * 0.12, 1.65), 0.004, 0.004), ((0.45, s * 0.16, 1.66), 0.01, 0.01)], C("mothfur", (130, 116, 96)), seg=4), "body")
        nn = "L" if s > 0 else "R"
        W = C("wingm", (150, 138, 120)); Wd = C("wingd", (90, 80, 76))
        A(box(n + "_w1" + nn, (0.05, s * 0.33, 1.47), (0.34, 0.56, 0.01), W), "wing." + nn)
        A(ellipsoid(n + "_wspot" + nn, (0.06, s * 0.4, 1.48), (0.08, 0.08, 0.008), Wd), "wing." + nn)
        A(box(n + "_w2" + nn, (-0.16, s * 0.27, 1.43), (0.26, 0.42, 0.01), W), "wing2." + nn)
    pose = P(rot={"wing.L": (14, 0, 0), "wing.R": (-14, 0, 0), "wing2.L": (8, 0, 0), "wing2.R": (-8, 0, 0)}, root=(0, 0, 0.2, 0))
    return r, pose

# ------------------------------------------------------------------ Kopacz: ryjacy spod ziemi, pazury jak lopaty, pancerz plyt
def kopacz(n):
    r = Rig(n, human_bones(arm=1.1, leg=0.8, torso=0.9)); A = r.attach
    hc = body(r, n, CHITIN(), k=1.35, hr=(0.13, 0.12, 0.11))
    for k in range(4):
        A(ellipsoid(n + "_pl%d" % k, (-0.08, 0, 0.95 + 0.14 * k), (0.12, 0.2, 0.07), CHITIN_L()), "spine" if k < 2 else "chest")
    for s, nn in ((1, "L"), (-1, "R")):
        h, t = bone_pts(r, "hand." + nn)
        A(box(n + "_spade" + nn, t + V((0.04, 0, -0.06)), (0.06, 0.18, 0.22), C("claw", (70, 60, 56))), "hand." + nn)
        for k in range(3): A(loft(n + "_cl%s%d" % (nn, k), [(t + V((0.05, -0.06 + 0.06 * k, -0.15)), 0.02, 0.02), (t + V((0.09, -0.06 + 0.06 * k, -0.3)), 0.002, 0.002)], TOOTH(), seg=4), "hand." + nn)
    A(loft(n + "_snout", [(hc + V((0.05, 0, -0.02)), 0.06, 0.07), (hc + V((0.2, 0, -0.06)), 0.02, 0.03)], FLESH()), "head")
    pose = P(rot={"spine": (0, 34, 0), "chest": (0, 16, 0), "neck": (0, -24, 0), "head": (0, -10, 0), "upperarm.L": (30, -50, 0), "upperarm.R": (-30, -50, 0),
                  "forearm.L": (0, -40, 0), "forearm.R": (0, -40, 0), "thigh.L": (0, -30, 0), "shin.L": (0, 50, 0), "thigh.R": (0, -20, 0), "shin.R": (0, 46, 0)}, loc={"hips": (0, 0, -0.16)})
    return r, pose

BESTIARY = [("Odmieniec", odmieniec), ("Naśladowca", nasladowca), ("Śpiący", spiacy), ("Zrośnięci", zrosnieci),
            ("Dawny Żołnierz", dawny_zolnierz), ("Opiekunka", opiekunka), ("Pielgrzym", pielgrzym), ("Echo", echo),
            ("Pasterz", pasterz), ("Bezoki", bezoki), ("Ćma", cma), ("Kopacz", kopacz)]
