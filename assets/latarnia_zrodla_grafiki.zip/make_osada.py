import sys; sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image
FOG = ((0.5, 1.0, 0.8), 52, -25, 28.0, 30, 12.5, 19.0, (0.0, 0.0))
fr = [stylize('out/osada_%02d.exr' % f, fog=FOG, t=f).resize((1920, 1080), Image.NEAREST) for f in range(48)]
fr[0].save('out/latarnia3d_osada_noca.gif', save_all=True, append_images=fr[1:], duration=83, loop=0)
fr[20].save('out/latarnia3d_osada_noca.png')
# zblizenie na zycie osady (przycinka 2x)
cr = [f.crop((420, 200, 1380, 740)) for f in fr]
cr[0].save('out/latarnia3d_osada_zblizenie.gif', save_all=True, append_images=cr[1:], duration=83, loop=0)
