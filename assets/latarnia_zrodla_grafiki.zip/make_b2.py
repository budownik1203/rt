import sys, json; sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
fb = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 15)
ft = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf', 24)
TT = {"zwierzeta": "Zwierzęta zmienione przez Mgłę (lekkie objawy)", "stworzenia": "Stworzenia Mgły (najmocniejsze objawy)", "ludzie": "Ludzie zmienieni przez Mgłę"}
S = 2
for m in ("zwierzeta", "stworzenia", "ludzie"):
    meta = json.load(open('out/b2_%s.json' % m)); frames = []
    for f in range(meta["nf"]):
        im = stylize('out/b2_%s_%02d.exr' % (m, f)); W, H = im.size
        im = im.resize((W * S, H * S), Image.NEAREST)
        out = Image.new('RGB', (W * S, H * S + 56), (20, 17, 28)); out.paste(im, (0, 56)); d = ImageDraw.Draw(out)
        d.text((20, 14), TT[m], font=ft, fill=(236, 214, 170))
        for lab, c in meta["labels"]:
            x = (W / 2 + c * W / meta["W"]) * S; w = d.textlength(lab, font=fb)
            d.rectangle((x - w / 2 - 5, H * S + 56 - 34, x + w / 2 + 5, H * S + 56 - 14), fill=(20, 17, 28))
            d.text((x - w / 2, H * S + 56 - 34), lab, font=fb, fill=(226, 200, 150))
        frames.append(out)
    if len(frames) > 1: frames[0].save('out/latarnia_wrogowie_%s.gif' % m, save_all=True, append_images=frames[1:], duration=83, loop=0)
    frames[0].save('out/latarnia_wrogowie_%s.png' % m)
print("ok")
