"""Pokaz animacji: 10 postaci (2 rzedy x 5), kazda w innej akcji. Uzycie: python3 showcase.py -- F0 F1 SAMPLES"""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A
import random

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
F0, F1, SAMP = (int(args[0]), int(args[1]), int(args[2])) if args else (0, 24, 20)

reset()
setup_render(samples=SAMP)
world((34, 30, 52), 0.30)
ground = mat("ground", (58, 54, 62), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
    (0.0, (56, 53, 60)), (0.45, (60, 57, 64)), (0.66, (64, 60, 64)), (0.82, (58, 60, 56))]))
box("ground", (0, 0, -0.05), (40, 24, 0.1), ground, pass_index=1)

CAMYAW = -25
YAW = CAMYAW - 18          # postacie w 3/4, lekko przodem do kamery
RES = (640, 320) if len(args) < 4 else (1280, 640)
_cy = math.radians(CAMYAW)
RIGHT = V((math.cos(_cy), math.sin(_cy), 0)); FWD = V((-math.sin(_cy), math.cos(_cy), 0))
COLS = [-5.6, -2.8, 0.0, 2.8, 5.6]
ROWS = [1.9, -1.9]
cells = []   # (rig, clip_fn, base_loc)

def put(rig, ci, ri, fn, yaw=YAW):
    loc = tuple(RIGHT * COLS[ci] + FWD * ROWS[ri]); cells.append((rig, fn, loc, yaw)); return rig

# rzad 1: ruch i strzelanie
put(human("chod", dict(jacket="brown", pants="darkgrey", beard=True), "idle"), 0, 0,
    lambda f: A.walk(f, 12))
put(human("bieg", dict(jacket="olive", pants="olive", helmet="mil"), "rifle"), 1, 0,
    lambda f: A.run_rifle(f, 8))
put(human("strzal", dict(jacket="teal", pants="darkgrey", helmet="mil", armor="vest"), "rifle"), 2, 0,
    A.clip_shoot().sample)
put(human("przel", dict(jacket="olive", pants="brown", helmet="pot"), "rifle"), 3, 0,
    A.clip_reload().sample)
put(human("oslona", dict(jacket="blue", pants="darkgrey", mask="gas"), "rifle"), 4, 0,
    A.clip_cover().sample)
# rzad 2: walka wrecz, granat, smierc, patrol
put(human("dzida", dict(jacket="leather", pants="brown", armor="plate", helmet="pot"), "spear"), 0, 1,
    A.clip_spear().sample)
put(human("mlot", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True), "hammer"), 1, 1,
    A.clip_hammer().sample)
grn = put(human("granat", dict(jacket="grey", pants="darkgrey", helmet="mil"), "grenade"), 2, 1,
          A.clip_grenade().sample, yaw=YAW + 40)
put(human("smierc", dict(jacket="teal", pants="brown"), "idle"), 3, 1,
    A.clip_death().sample)
put(human("patrol", dict(jacket="olive", pants="olive", helmet="mil"), "rifle"), 4, 1,
    lambda f: A.merge(A.walk(f, 12, stride=24, arms=False), A.low_ready()))

# oslona: worki z piaskiem przed postacia
SAND = M("sand", (104, 96, 74)); SAND2 = M("sand2", (92, 86, 66))
cx, cy = cells[4][2][0], cells[4][2][1]
yw = math.radians(YAW)
fx, fy = math.cos(yw), math.sin(yw)
for k in range(5):
    for j in range(-2, 3):
        jj = j + (0.5 if k % 2 else 0)
        if k % 2 and j == 2: continue
        px = cx + fx * 0.72 - fy * jj * 0.36; py = cy + fy * 0.72 + fx * jj * 0.36
        b = box("sandbag%d%d" % (k, j), (px, py, 0.08 + 0.15 * k), (0.30, 0.38, 0.15), SAND if (j + k) % 2 else SAND2,
                rot=(0, 0, yw + math.radians(4 * ((j * 7 + k * 3) % 3 - 1))), smooth=False)
        bv = b.modifiers.new("bv", "BEVEL"); bv.width = 0.05; bv.segments = 2
# granat w locie + wybuch
gfly = ellipsoid("gfly", (0, 0, 0), (0.04, 0.035, 0.05), M("grenm", (70, 80, 56)))
boom = ellipsoid("boom", (0, 0, 0), (0.35, 0.35, 0.25), M("boomm", (255, 200, 120), emit=(255, 170, 80), strength=12))
gfly.pass_index = 3; boom.pass_index = 3
char_collection().objects.link(gfly)
# cel dla dzidy i mlota: slupy treningowe
POST = M("post", (90, 66, 44))
for ci in (0, 1):
    dd = (1.85, 1.2)[ci]
    bx, by = cells[5 + ci][2][0] + fx * dd, cells[5 + ci][2][1] + fy * dd
    cyl("pal%d" % ci, (bx, by, 0), (bx, by, 1.5), 0.09, POST)

# swiatlo: cieple latarnie + wypelnienie na postaciach + chlodny kontur od tylu
for i, c in enumerate((-4.2, 0.0, 4.2)):
    p = RIGHT * c + FWD * 0.0
    point_light("lamp%d" % i, (p.x, p.y, 3.4), (1.0, 0.72, 0.42), 380, radius=0.1)
sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.84, 0.64), 3.1)
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.70, 0.76, 1.0), 1.2)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (fill, rim):
    L.light_linking.receiver_collection = char_collection()

camera((0, 0, 0.8), 50, 16.5, RES, yaw_deg=CAMYAW)

# klatka wyrzutu granatu: zapamietaj polozenie dloni
REL = 9
gclip = A.clip_grenade()
A.apply(grn, gclip.sample(REL - 0.5), cells[7][2], YAW + 40)
bpy.context.view_layer.update()
g0 = grn.objs["gren"].matrix_world.translation.copy()
g1 = V(cells[7][2]) + V((math.cos(yw + 0.7), math.sin(yw + 0.7), 0)) * 1.7; g1.z = 0.05

import os
FR = [int(x) for x in os.environ['FRAMES'].split(',')] if 'FRAMES' in os.environ else range(F0, F1)

# ---------------------------------------------------------------- efekty: luski, magazynek, dym, iskry, odlamki
G = 9.81 / 144.0          # grawitacja na klatke^2 przy 12 kl/s
BRASS = M("brass", (214, 170, 80)); SMOKE = M("smoke", (150, 146, 150)); SPARK = M("spark", (255, 210, 140), emit=(255, 190, 110), strength=10)
DUST = M("dust", (120, 108, 90)); DEBRIS = M("debris", (60, 54, 50))
def mkobj(fn, n, *a, **k):
    o = fn(n, *a, **k); o.pass_index = 3; char_collection().objects.link(o); o.hide_render = True; return o
def world_pt(ob, rest):
    return ob.matrix_world @ V(rest)
def right_of(yaw): return V((math.sin(math.radians(yaw)), -math.cos(math.radians(yaw)), 0))
def fwd_of(yaw): return V((math.cos(math.radians(yaw)), math.sin(math.radians(yaw)), 0))
class Ballistic:
    def __init__(s, ob, f0, p0, v0, spin=0.0, life=99, rest=True):
        s.ob, s.f0, s.p0, s.v0, s.spin, s.life, s.rest = ob, f0, V(p0), V(v0), spin, life, rest
    def at(s, f):
        t = f - s.f0
        if t < 0 or t > s.life: s.ob.hide_render = True; return
        p = s.p0 + s.v0 * t; p.z -= 0.5 * G * t * t * 12
        if p.z < 0.02:
            if not s.rest: s.ob.hide_render = True; return
            # czas zderzenia z ziemia -> zostaje lezec
            a = 0.5 * G * 12; b = -s.v0.z; c = 0.02 - s.p0.z
            tg = (-b + math.sqrt(max(b * b - 4 * a * c, 0))) / (2 * a)
            p = s.p0 + s.v0 * tg; p.z = 0.02; t = tg
        s.ob.hide_render = False; s.ob.location = p; s.ob.rotation_euler = (s.spin * t, 0.7 * s.spin * t, 0)
class Puff:
    def __init__(s, ob, f0, p0, drift, r0, r1, life):
        s.ob, s.f0, s.p0, s.drift, s.r0, s.r1, s.life = ob, f0, V(p0), V(drift), r0, r1, life
    def at(s, f):
        t = f - s.f0
        if t < 0 or t > s.life: s.ob.hide_render = True; return
        k = t / s.life; r = s.r0 + (s.r1 - s.r0) * (1 - (1 - k) ** 2)
        if k > 0.7: r *= 1 - (k - 0.7) / 0.3 * 0.8          # zanika przez kurczenie
        s.ob.hide_render = False; s.ob.location = s.p0 + s.drift * t; s.ob.scale = (r, r, r * 0.8)
FX = []
SHOTS = [(2, 9), (2, 15), (4, 11), (4, 16)]         # (indeks postaci, klatka odrzutu)
REST_MUZ = V((1.02, -0.08, 1.19)); REST_PORT = V((0.36, -0.11, 1.29))
def prepare_fx():
    rnd = random.Random(7)
    for ci, fr in SHOTS:
        rig, fn, loc, yaw = cells[ci]
        A.apply(rig, fn(fr), loc, yaw); bpy.context.view_layer.update()
        fl = rig.objs["flash"]
        mz = world_pt(fl, REST_MUZ); port = world_pt(fl, REST_PORT)
        sh = mkobj(cyl, "shell%d_%d" % (ci, fr), (0, 0, -0.012), (0, 0, 0.012), 0.006, BRASS, seg=5)
        v = right_of(yaw) * 0.16 + fwd_of(yaw) * -0.03 + V((0, 0, 0.13))
        FX.append(Ballistic(sh, fr, port, v, spin=2.5))
        for k in range(2):
            pf = mkobj(ellipsoid, "smoke%d_%d_%d" % (ci, fr, k), (0, 0, 0), (1, 1, 1), SMOKE, u=8, v=6)
            FX.append(Puff(pf, fr + k, mz + fwd_of(yaw) * (0.1 * k), V((0, 0, 0.03)) + fwd_of(yaw) * 0.02, 0.05, 0.14 + 0.04 * k, 6))
    # magazynek wyrzucony przy przeladowaniu
    rig, fn, loc, yaw = cells[3]
    A.apply(rig, fn(8.9), loc, yaw); bpy.context.view_layer.update()
    mp = world_pt(rig.objs["maghand"], (0.02, 0.20, 0.80))
    mg = mkobj(box, "magdrop", (0, 0, 0), (0.05, 0.03, 0.09), METAL_D())
    FX.append(Ballistic(mg, 9, mp, right_of(yaw) * -0.04 + V((0, 0, 0.02)), spin=1.2))
    # iskry i drzazgi na palach przy ciosach
    for ci, fr, col in ((5, 9, SPARK), (6, 10, DUST)):
        rig, fn, loc, yaw = cells[ci]
        hit = V(loc) + fwd_of(yaw) * (1.78 if ci == 5 else 1.12) + V((0, 0, 1.05 if ci == 5 else 0.75))
        for k in range(7):
            o = mkobj(box, "spark%d_%d" % (ci, k), (0, 0, 0), (0.03, 0.03, 0.03), col)
            a = rnd.uniform(-1.2, 1.2); up = rnd.uniform(0.02, 0.12)
            v = fwd_of(yaw) * -0.08 * rnd.uniform(0.3, 1.0) + right_of(yaw) * 0.12 * a + V((0, 0, up))
            FX.append(Ballistic(o, fr, hit, v, spin=6, life=5 if ci == 5 else 9, rest=(ci == 6)))
        FX.append(Puff(mkobj(ellipsoid, "hitdust%d" % ci, (0, 0, 0), (1, 1, 1), DUST, u=8, v=6), fr, hit, V((0, 0, 0.02)), 0.05, 0.16, 5))
    # wybuch granatu: odlamki + chmura
    for k in range(10):
        o = mkobj(box, "deb%d" % k, (0, 0, 0), (0.05, 0.05, 0.04), DEBRIS)
        a = 2 * math.pi * k / 10 + rnd.uniform(-0.2, 0.2); sp = rnd.uniform(0.12, 0.28)
        FX.append(Ballistic(o, REL + 6, g1 + V((0, 0, 0.05)), V((math.cos(a) * sp, math.sin(a) * sp, rnd.uniform(0.12, 0.3))), spin=5))
    for k in range(4):
        off = V((rnd.uniform(-0.25, 0.25), rnd.uniform(-0.25, 0.25), 0.15 + 0.15 * k))
        FX.append(Puff(mkobj(ellipsoid, "gsmoke%d" % k, (0, 0, 0), (1, 1, 1), SMOKE if k % 2 else DUST, u=10, v=8),
                       REL + 7 + k, g1 + off, V((0.01, 0.005, 0.03)), 0.15, 0.45 + 0.08 * k, 14 - k))
import random
prepare_fx()
for f in FR:
    for rig, fn, loc, yaw in cells:
        A.apply(rig, fn(f), loc, yaw)
    # lot granatu (parabola), wybuch po 6 klatkach
    t = (f - REL) / 6.0
    if 0 <= t <= 1:
        p = g0.lerp(g1, t); p.z += 1.1 * 4 * t * (1 - t)
        gfly.location = p; gfly.hide_render = False
    else:
        gfly.hide_render = True
    bf = f - (REL + 6)
    boom.hide_render = not (0 <= bf <= 2)
    if 0 <= bf <= 2:
        s = (0.6, 1.0, 0.7)[bf]
        boom.location = g1 + V((0, 0, 0.2)); boom.scale = (s, s, s)
    for e in FX: e.at(f)
    render("/home/claude/latarnia3d/out/%s_%02d.exr" % ("show" if len(args) < 4 else "dbg", f))
