import sys
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image
FOG = ((4.6, 0.6, 1.0), 52, -32, 14, 30, 3.4, 9.0)
fr = [stylize('out/battle_%02d.exr' % f, fog=FOG, t=f).resize((1280, 720), Image.NEAREST) for f in range(36)]
fr[0].save('out/latarnia3d_bitwa.gif', save_all=True, append_images=fr[1:], duration=83, loop=0)
fr[15].save('out/latarnia3d_bitwa_kl15.png')
