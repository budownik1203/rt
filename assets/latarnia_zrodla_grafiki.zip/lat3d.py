"""Latarnia 3D -> pixel art: biblioteka modeli, szkieletow, materialow i swiatel (Blender bpy)."""
import bpy, bmesh, math, addon_utils
from mathutils import Vector, Matrix, Quaternion, Euler

addon_utils.enable("cycles", default_set=True)
V = Vector

# ------------------------------------------------------------------ scena / materialy
def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    addon_utils.enable("cycles", default_set=True)

MATS = {}
def mat(name, color, rough=1.0, emit=None, strength=0.0, brick=None, noise=None, pass_index=0):
    """Matowy material (bez polysku). color w sRGB 0-255."""
    key = name
    if key in MATS: return MATS[key]
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; b = nt.nodes["Principled BSDF"]
    lin = tuple(((c / 255) ** 2.2) for c in color) + (1,)
    b.inputs["Base Color"].default_value = lin
    b.inputs["Roughness"].default_value = rough
    if "Specular IOR Level" in b.inputs: b.inputs["Specular IOR Level"].default_value = 0.0
    if emit is not None:
        b.inputs["Emission Color"].default_value = tuple(((c / 255) ** 2.2) for c in emit) + (1,)
        b.inputs["Emission Strength"].default_value = strength
    if brick:
        t = nt.nodes.new("ShaderNodeTexBrick"); t.inputs["Scale"].default_value = brick["scale"]
        t.inputs["Color1"].default_value = tuple(((c / 255) ** 2.2) for c in brick["c1"]) + (1,)
        t.inputs["Color2"].default_value = tuple(((c / 255) ** 2.2) for c in brick["c2"]) + (1,)
        t.inputs["Mortar"].default_value = tuple(((c / 255) ** 2.2) for c in brick["mortar"]) + (1,)
        t.inputs["Mortar Size"].default_value = brick.get("mortar_size", 0.02)
        if "bw" in brick: t.inputs["Brick Width"].default_value = brick["bw"]
        if "rh" in brick: t.inputs["Row Height"].default_value = brick["rh"]
        if "offset" in brick: t.offset = brick["offset"]
        tc = nt.nodes.new("ShaderNodeTexCoord"); nt.links.new(tc.outputs["Object"], t.inputs["Vector"])
        nt.links.new(t.outputs["Color"], b.inputs["Base Color"])
    if noise:
        tc = nt.nodes.new("ShaderNodeTexCoord")
        n = nt.nodes.new("ShaderNodeTexNoise"); n.inputs["Scale"].default_value = noise["scale"]
        n.inputs["Detail"].default_value = noise.get("detail", 2.0)
        nt.links.new(tc.outputs["Object"], n.inputs["Vector"])
        r = nt.nodes.new("ShaderNodeValToRGB"); r.color_ramp.interpolation = "CONSTANT"
        els = r.color_ramp.elements
        stops = noise["stops"]   # [(pos, rgb), ...]
        els[0].position = stops[0][0]; els[0].color = tuple(((c / 255) ** 2.2) for c in stops[0][1]) + (1,)
        els[1].position = stops[1][0]; els[1].color = tuple(((c / 255) ** 2.2) for c in stops[1][1]) + (1,)
        for pos, c in stops[2:]:
            e = els.new(pos); e.color = tuple(((x / 255) ** 2.2) for x in c) + (1,)
        nt.links.new(n.outputs["Fac"], r.inputs["Fac"])
        nt.links.new(r.outputs["Color"], b.inputs["Base Color"])
    m.pass_index = pass_index
    MATS[key] = m
    return m

CHAR_COL = None
def char_collection():
    global CHAR_COL
    if CHAR_COL is None or CHAR_COL.name not in bpy.data.collections:
        CHAR_COL = bpy.data.collections.new("chars"); bpy.context.scene.collection.children.link(CHAR_COL)
    return CHAR_COL
def link(obj):
    bpy.context.scene.collection.objects.link(obj)
    if getattr(obj, "pass_index", 0) == 3:
        char_collection().objects.link(obj)
    return obj

def mesh_obj(name, verts, faces, material, smooth=True, pass_index=2):
    me = bpy.data.meshes.new(name); me.from_pydata([tuple(v) for v in verts], [], faces); me.update()
    if smooth: me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
    me.materials.append(material)
    ob = bpy.data.objects.new(name, me); ob.pass_index = pass_index
    return link(ob)

def bm_obj(name, bm, material, smooth=True, pass_index=2):
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    if smooth: me.polygons.foreach_set("use_smooth", [True] * len(me.polygons))
    me.materials.append(material)
    ob = bpy.data.objects.new(name, me); ob.pass_index = pass_index
    return link(ob)

# ------------------------------------------------------------------ prymitywy
def loft(name, rings, material, seg=10, cap=True, pass_index=2, smooth=True):
    """rings: lista (punkt, rx_przod_tyl, ry_bok[, obrot_rad]) wzdluz sciezki -> zwezana rura (konczyny, tulow)."""
    pts = [V(r[0]) for r in rings]
    verts, faces = [], []
    n = len(pts)
    for i, r in enumerate(rings):
        p = pts[i]
        t = (pts[min(i + 1, n - 1)] - pts[max(i - 1, 0)]).normalized()
        ref = V((0, 1, 0)) if abs(t.y) < 0.9 else V((1, 0, 0))
        u = (ref - t * ref.dot(t)).normalized(); v = t.cross(u)
        rx, ry = r[1], r[2]; rot = r[3] if len(r) > 3 else 0.0
        for k in range(seg):
            a = 2 * math.pi * k / seg + rot
            verts.append(p + u * (ry * math.cos(a)) + v * (rx * math.sin(a)))
    for i in range(n - 1):
        for k in range(seg):
            a = i * seg + k; b = i * seg + (k + 1) % seg
            faces.append((a, b, b + seg, a + seg))
    if cap:
        c0 = len(verts); verts.append(pts[0]); c1 = len(verts); verts.append(pts[-1])
        for k in range(seg):
            faces.append((c0, (k + 1) % seg, k))
            faces.append((c1, (n - 1) * seg + k, (n - 1) * seg + (k + 1) % seg))
    return mesh_obj(name, verts, faces, material, smooth, pass_index)

def ellipsoid(name, center, radii, material, u=12, v=8, pass_index=2, clip_z=None):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=u, v_segments=v, radius=1.0)
    for vert in bm.verts:
        vert.co = V((vert.co.x * radii[0], vert.co.y * radii[1], vert.co.z * radii[2]))
    if clip_z is not None:   # odciecie (np. helm = gorna czasza)
        kill = [vv for vv in bm.verts if vv.co.z < clip_z * radii[2]]
        bmesh.ops.delete(bm, geom=kill, context="VERTS")
    for vert in bm.verts: vert.co += V(center)
    return bm_obj(name, bm, material, True, pass_index)

def box(name, center, size, material, rot=(0, 0, 0), pass_index=2, smooth=False):
    bm = bmesh.new(); bmesh.ops.create_cube(bm, size=1.0)
    R = Euler(rot).to_matrix()
    for vert in bm.verts:
        vert.co = R @ V((vert.co.x * size[0], vert.co.y * size[1], vert.co.z * size[2])) + V(center)
    return bm_obj(name, bm, material, smooth, pass_index)

def cyl(name, p0, p1, r0, material, r1=None, seg=10, pass_index=2, smooth=True):
    r1 = r0 if r1 is None else r1
    return loft(name, [(p0, r0, r0), (p1, r1, r1)], material, seg=seg, pass_index=pass_index, smooth=smooth)

# ------------------------------------------------------------------ szkielet
class Rig:
    """Szkielet FK + opcjonalne IK. Czesci ciala/ubran sa sztywno przypiete do kosci (brak przenikania warstw)."""
    def __init__(self, name, bones):
        ad = bpy.data.armatures.new(name); self.ob = bpy.data.objects.new(name, ad); link(self.ob)
        bpy.context.view_layer.objects.active = self.ob; self.ob.select_set(True)
        bpy.ops.object.mode_set(mode="EDIT")
        eb = ad.edit_bones
        for bname, head, tail, parent in bones:
            b = eb.new(bname); b.head = V(head); b.tail = V(tail); b.roll = 0
            if parent: b.parent = eb[parent]; b.use_connect = False
        bpy.ops.object.mode_set(mode="OBJECT")
        self.parts = []
        for pb in self.ob.pose.bones: pb.rotation_mode = "QUATERNION"
    def attach(self, obj, bone):
        col = char_collection()
        if obj.name not in col.objects: col.objects.link(obj)
        obj.pass_index = 3
        bpy.context.view_layer.update()
        obj.parent = self.ob; obj.parent_type = "BONE"; obj.parent_bone = bone
        b = self.ob.data.bones[bone]
        M = self.ob.matrix_world @ b.matrix_local @ Matrix.Translation((0, b.length, 0))
        obj.matrix_parent_inverse = M.inverted()
        obj.matrix_basis = Matrix.Identity(4)
        self.parts.append(obj)
        return obj
    def rot(self, bone, axis, deg):
        """Obrot kosci wokol osi w ukladzie szkieletu (wzgledem rodzica)."""
        b = self.ob.data.bones[bone]
        R = b.matrix_local.to_3x3()
        q = Quaternion(V(axis), math.radians(deg))
        ql = (R.inverted() @ q.to_matrix() @ R).to_quaternion()
        pb = self.ob.pose.bones[bone]
        pb.rotation_quaternion = ql @ pb.rotation_quaternion
    def reset_pose(self):
        for pb in self.ob.pose.bones:
            pb.rotation_quaternion = Quaternion(); pb.location = V()
    def ik(self, bone, target, chain=2):
        c = self.ob.pose.bones[bone].constraints.new("IK"); c.target = target; c.chain_count = chain
        return c
    def place(self, loc, yaw_deg):
        self.ob.location = V(loc); self.ob.rotation_euler = (0, 0, math.radians(yaw_deg))

def empty(name, loc, parent=None, bone=None):
    e = bpy.data.objects.new(name, None); link(e); e.location = V(loc)
    return e

# ------------------------------------------------------------------ swiatla / kamera
def point_light(name, loc, color, energy, radius=0.05):
    ld = bpy.data.lights.new(name, "POINT"); ld.color = color; ld.energy = energy; ld.shadow_soft_size = radius
    ob = bpy.data.objects.new(name, ld); ob.location = V(loc); return link(ob)

def spot_light(name, loc, rot, color, energy, size_deg=30, blend=0.3):
    ld = bpy.data.lights.new(name, "SPOT"); ld.color = color; ld.energy = energy; ld.spot_size = math.radians(size_deg)
    ld.spot_blend = blend; ld.shadow_soft_size = 0.02
    ob = bpy.data.objects.new(name, ld); ob.location = V(loc); ob.rotation_euler = rot; return link(ob)

def sun(name, rot, color, energy):
    ld = bpy.data.lights.new(name, "SUN"); ld.color = color; ld.energy = energy; ld.angle = math.radians(2)
    ob = bpy.data.objects.new(name, ld); ob.rotation_euler = rot; return link(ob)

def camera(target, tilt_deg, ortho, res, dist=30, yaw_deg=0.0):
    cd = bpy.data.cameras.new("cam"); cd.type = "ORTHO"; cd.ortho_scale = ortho; cd.clip_end = 200
    cam = bpy.data.objects.new("cam", cd); link(cam)
    t = math.radians(tilt_deg); y = math.radians(yaw_deg)
    d = V((-math.sin(y) * math.sin(t), math.cos(y) * math.sin(t), -math.cos(t)))
    cam.location = V(target) - d * dist
    cam.rotation_euler = (t, 0, y)
    sc = bpy.context.scene; sc.camera = cam
    sc.render.resolution_x, sc.render.resolution_y = res; sc.render.resolution_percentage = 100
    return cam

def world(color, strength):
    w = bpy.data.worlds.new("w"); w.use_nodes = True
    bg = w.node_tree.nodes["Background"]; bg.inputs[0].default_value = tuple(((c / 255) ** 2.2) for c in color) + (1,)
    bg.inputs[1].default_value = strength; bpy.context.scene.world = w

def setup_render(samples=24):
    sc = bpy.context.scene
    sc.render.engine = "CYCLES"; sc.cycles.device = "CPU"; sc.cycles.samples = samples
    sc.cycles.use_denoising = True
    sc.cycles.filter_width = 0.01          # bez wygladzania krawedzi -> czyste piksele
    sc.cycles.max_bounces = 3; sc.cycles.diffuse_bounces = 2; sc.cycles.glossy_bounces = 0
    sc.cycles.transparent_max_bounces = 2; sc.cycles.transmission_bounces = 0
    sc.view_settings.view_transform = "Standard"; sc.view_settings.look = "None"
    vl = sc.view_layers[0]
    vl.use_pass_z = True; vl.use_pass_normal = True; vl.use_pass_diffuse_color = True
    vl.use_pass_emit = True; vl.use_pass_object_index = True
    sc.render.image_settings.media_type = "MULTI_LAYER_IMAGE"
    sc.render.image_settings.file_format = "OPEN_EXR_MULTILAYER"
    sc.render.image_settings.color_depth = "16"

def render(path):
    bpy.context.scene.render.filepath = path
    bpy.ops.render.render(write_still=True)
