"""Arsenal epok: 14 wojownikow z bronia od Zlomu do Swiatla, kazdy w swojej pozie. python3 arsenal.py -- NFRAMES SAMPLES"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A
from fx import FX, watch_events
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
NF, SAMP = (int(args[0]), int(args[1])) if args else (16, 16)
reset(); setup_render(samples=SAMP)
world((40, 36, 58), 0.45)
box("ground", (0, 0, -0.05), (40, 20, 0.1), mat("ground", (60, 57, 64), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
    (0.0, (56, 53, 60)), (0.45, (60, 57, 64)), (0.66, (64, 60, 64)), (0.82, (58, 60, 56))])), pass_index=1)
CAMYAW = -25; YAW = CAMYAW - 18
cy = math.radians(CAMYAW); RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
RAGS = dict(jacket="brown", pants="brown", strap=False)
ROSTER = [
    [("Rura z gwoździami", "Złom", "club", dict(RAGS, beard=True)),
     ("Maczeta", "Złom", "machete", dict(jacket="leather", pants="brown")),
     ("Nóż", "Złom", "knife", dict(jacket="grey", pants="brown", mask="gas")),
     ("Dzida i tarcza", "Kuźnia", "spear", dict(jacket="leather", pants="brown", armor="plate", helmet="pot")),
     ("Łuk", "Kuźnia", "bow", dict(jacket="olive", pants="brown", hair="hair_l")),
     ("Kusza", "Kuźnia", "crossbow", dict(jacket="brown", pants="darkgrey", helmet="pot")),
     ("Młot", "Kuźnia", "hammer", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True))],
    [("Muszkiet", "Czarny proch", "musket", dict(jacket="blue", pants="grey", helmet="pot")),
     ("Obrzyn", "Czarny proch", "shotgun", dict(jacket="leather", pants="darkgrey")),
     ("Rewolwer", "Nabój", "pistol", dict(jacket="teal", pants="darkgrey")),
     ("Karabin", "Nabój", "rifle", dict(jacket="olive", pants="olive", helmet="mil")),
     ("Pistolet masz.", "Silnik", "smg", dict(jacket="grey", pants="darkgrey", helmet="mil", armor="vest")),
     ("Karabin masz.", "Silnik", "mg", dict(jacket="olive", pants="olive", helmet="mil", armor="vest")),
     ("Lanca latarniowa", "Światło", "lance", dict(jacket="blue", pants="blue", helmet="mil", mask="gas", armor="plate"))],
]
SPX = 1.75; SPY = 3.3
cast = []
for ri, row in enumerate(ROSTER):
    for ci, (lab, era, kind, o) in enumerate(row):
        r = human("ars%d%d" % (ri, ci), o, kind)
        base = RIGHT * ((ci - 3) * SPX) + FWD * ((0.5 - ri) * SPY)
        cast.append((r, kind, tuple(base), ci + 7 * ri))
slash = A.clip_slash(); spear = A.clip_spear(); ham = A.clip_hammer()
def pose_for(kind, f, i):
    k = (f + 3 * i) % NF
    if kind in ("club", "machete", "knife"): return slash.sample(k % 16)
    if kind == "spear": return A.merge(A.stance(), A.P(rot={"weapon": (0, 82, 0)}, loc={"weapon": (0, 0, 0.22), "shield": (0.02, 0, 0.08)}))
    if kind == "hammer": return A.stance()
    if kind == "bow": return A.merge(A.stance(), A.P(rot={"head": (0, 0, 10)}))
    if kind == "pistol": return A.merge(A.wide(), A.pistol_recoil() if k == 4 else A.pistol_aim())
    if kind == "mg":
        hip = A.P(rot={"weapon": (0, 4, 0), "spine": (0, -6, 0)}, loc={"weapon": (0.0, 0.0, -0.10), "hips": (0, 0, -0.04)})
        return A.merge(A.wide(), hip, A.P(rot={"weapon": (0, -5, 0)}, loc={"weapon": (-0.05, 0, 0.02)}, vis={"flash": 1}) if k % 2 == 0 else A.P())
    if kind == "crossbow": return A.merge(A.wide(), A.aim())
    if kind == "smg": return A.merge(A.wide(), A.recoil() if k % 3 == 0 and k < 8 else A.aim())
    return A.merge(A.wide(), A.recoil() if k == 6 else A.aim())
sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.84, 0.64), 2.8)
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.70, 0.76, 1.0), 1.3)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
camera(V((0, 0, 0.8)), 50, 13.0, (640, 360), yaw_deg=CAMYAW)
fxs = FX(); st = {}
for f in range(NF):
    for r, kind, base, i in cast: A.apply(r, pose_for(kind, f, i), base, YAW)
    bpy.context.view_layer.update()
    for r, *_ in cast: watch_events(fxs, r, st.setdefault(r.ob.name, {}))
    fxs.step()
    render("/home/claude/latarnia3d/out/ars_%02d.exr" % f)
