"""Generator artboardow makiet interfejsu Latarni (.dc.html)."""
import json, os
ROOT = "/mnt/user-data/outputs/artifacts/e2249aec-f563-4171-a376-e72716288846/project"
CSS = open("/home/claude/latarnia3d/ui/common.css").read()
B = {"osada": "/_blob/a72846c264a97363142635b059f62391", "bitwa": "/_blob/481f817da999ad3a1dc89c3c6aa76172", "mapa": "/_blob/c1e5054b9c2c29c189159bc01d16483e",
     "mroz": "/_blob/1cbf6cc9ab1c41ecf0712760b6a16282", "wrona": "/_blob/f336ffa8a481bd80fe751cf7b9bbe0d9", "sitko": "/_blob/9690ed5218827629208a5dc473e8cd7c",
     "kruk": "/_blob/9e1e54d22ca9f4e8b505a5f8195f1e50", "zakon": "/_blob/47f3ae4b4bf4429350e6dd8543907cc9", "szab": "/_blob/9a95b396a3d80d714e43a9d5251005ad",
     "tor": "/_blob/61141d7e62352f88a2c325e8cb35c50b"}
SCREENS = [("Main.dc.html", "Osada", "F1"), ("Teczka.dc.html", "Ludzie", "F2"), ("Kompleks.dc.html", "Kompleks", "F3"), ("Walka.dc.html", "Walka", "F4"),
           ("Raport.dc.html", "Raport", "F5"), ("Mapa.dc.html", "Mapa", "F6"), ("Ratusz.dc.html", "Ratusz", "F7")]

def nav(active):
    out = ['<nav aria-label="Ekrany" style="position: absolute; top: 0; right: 24px; display: flex; gap: 4px; z-index: 20">']
    for f, t, k in SCREENS:
        cls = "tab on" if t == active else "tab"
        out.append('<a class="%s" href="%s">%s <span class="key">%s</span></a>' % (cls, f, t, k))
    out.append("</nav>")
    return "\n".join(out)

def page(title, body, script, props='{"$preview":{"width":1600,"height":900}}'):
    return """<!doctype html>
<html lang="pl">
<head>
<meta charset="utf-8">
<title>%s</title>
<script src="./support.js"></script>
</head>
<body>
<x-dc>
<helmet>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Special+Elite&amp;family=IBM+Plex+Sans+Condensed:wght@400;600;700&amp;display=swap" rel="stylesheet">
<style>
%s
</style>
</helmet>
%s
</x-dc>
<script type="text/x-dc" data-dc-script data-props='%s'>
%s
</script>
</body>
</html>
""" % (title, CSS, body, props, script)

def write(name, html):
    open(os.path.join(ROOT, name), "w").write(html)

# =====================================================================================  OSADA
osada_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #14111c; font-family: 'IBM Plex Sans Condensed', sans-serif">
<img src="%(osada)s" alt="Osada nocą: latarnia w środku, budynki w kręgu światła" style="position: absolute; inset: 0; width: 1600px; height: 900px; object-fit: cover; image-rendering: pixelated">
%(nav)s
<section class="paper" aria-label="Kartka zaopatrzenia" style="position: absolute; top: 20px; left: 20px; width: 300px; padding: 16px 18px; transform: rotate(-1.2deg)">
<h2 class="typed" style="margin: 0 0 8px; font-size: 20px; font-weight: 400">Kartka zaopatrzenia</h2>
<sc-for list="{{ stock }}" as="s" hint-placeholder-count="8">
<div style="display: flex; justify-content: space-between; align-items: baseline; padding: 4px 0; border-bottom: 1px dashed #b3a37f">
<span style="font-size: 15px">{{ s.name }}</span>
<span class="num" style="font-size: 17px; font-weight: 700">{{ s.val }} <span style="font-weight: 400; font-size: 13px; color: {{ s.tc }}">{{ s.trend }}</span></span>
</div>
</sc-for>
<p class="typed" style="margin: 10px 0 0; font-size: 14px; color: #9b2c22">Paliwa do latarni na 6 dni</p>
</section>
<section class="paper2" aria-label="Czas" style="position: absolute; top: 20px; left: 560px; height: 64px; padding: 0 12px 0 20px; display: flex; align-items: center; gap: 14px">
<span class="typed" style="font-size: 20px">Dzień 14 · jesień · 21:40</span>
<div style="display: flex; gap: 6px">
<sc-for list="{{ speeds }}" as="sp" hint-placeholder-count="4">
<button class="{{ sp.cls }}" onClick="{{ sp.pick }}" aria-label="{{ sp.label }}" style="min-width: 48px">{{ sp.text }}</button>
</sc-for>
</div>
</section>
<sc-if value="{{ paused }}" hint-placeholder-val="{{ false }}">
<div class="typed" style="position: absolute; top: 100px; left: 640px; padding: 6px 16px; background: rgba(20,17,28,.8); color: #e0a640; font-size: 18px; letter-spacing: 3px">PAUZA · można wydawać polecenia</div>
</sc-if>
<aside aria-label="Tablica alarmów" style="position: absolute; top: 100px; right: 24px; width: 290px; display: flex; flex-direction: column; gap: 14px">
<sc-for list="{{ alarms }}" as="a" hint-placeholder-count="3">
<div class="paper" style="padding: 12px 14px; transform: rotate({{ a.rot }}); border-top: 6px solid {{ a.col }}">
<button onClick="{{ a.toggle }}" style="all: unset; cursor: pointer; display: block; width: 100%%; min-height: 44px">
<span class="typed" style="font-size: 17px">{{ a.title }}</span><br>
<span style="font-size: 14px; color: #5a4a3a">{{ a.sub }}</span>
</button>
<sc-if value="{{ a.open }}" hint-placeholder-val="{{ false }}">
<p style="margin: 8px 0 0; font-size: 14px; line-height: 1.4">{{ a.detail }}</p>
</sc-if>
</div>
</sc-for>
</aside>
<section class="paper" aria-label="Wybrany budynek" style="position: absolute; left: 20px; bottom: 150px; width: 330px; padding: 16px 18px; transform: rotate(0.8deg)">
<div style="display: flex; justify-content: space-between; align-items: baseline">
<h2 class="typed" style="margin: 0; font-size: 22px; font-weight: 400">Kuźnia</h2><span class="num" style="font-size: 14px; color: #5a4a3a">poziom I</span>
</div>
<p style="margin: 6px 0 10px; font-size: 15px">Produkuje: groty, okucia, narzędzia</p>
<div style="display: flex; align-items: center; gap: 10px">
<span style="font-size: 15px">Pracownicy</span>
<button class="btn" onClick="{{ minus }}" aria-label="Zabierz pracownika" style="min-width: 44px; padding: 0">−</button>
<span class="num" style="font-size: 22px; font-weight: 700; min-width: 48px; text-align: center">{{ workers }}/4</span>
<button class="btn" onClick="{{ plus }}" aria-label="Dodaj pracownika" style="min-width: 44px; padding: 0">+</button>
</div>
<p class="num" style="margin: 10px 0 0; font-size: 15px">Wydajność: <b>{{ output }}</b> szt./dzień · zmiana 10 h</p>
</section>
<section aria-label="Budowa" style="position: absolute; left: 0; right: 0; bottom: 0; height: 132px">
<div style="display: flex; gap: 4px; padding-left: 24px">
<sc-for list="{{ cats }}" as="c" hint-placeholder-count="7">
<button class="{{ c.cls }}" onClick="{{ c.pick }}" style="border: 0; cursor: pointer">{{ c.name }}</button>
</sc-for>
</div>
<div class="paper" style="height: 88px; margin: 0 16px; padding: 10px 16px; display: flex; gap: 12px; align-items: center; border-radius: 0 4px 0 0; overflow-x: auto">
<sc-for list="{{ blds }}" as="b" hint-placeholder-count="5">
<button onClick="{{ b.pick }}" style="all: unset; cursor: pointer; min-width: 180px; height: 66px; padding: 6px 12px; border: 2px solid {{ b.border }}; border-radius: 3px; background: {{ b.bg }}">
<span class="typed" style="font-size: 16px; display: block">{{ b.name }}</span>
<span class="num" style="font-size: 13px; color: #5a4a3a">{{ b.cost }}</span>
</button>
</sc-for>
</div>
</section>
<sc-if value="{{ building }}" hint-placeholder-val="{{ false }}">
<div class="typed" style="position: absolute; left: 50%%; top: 430px; transform: translateX(-50%%); padding: 10px 20px; background: rgba(230,220,195,.95); color: #2b231c; font-size: 18px; box-shadow: 0 6px 18px rgba(0,0,0,.5)">Stawianie: {{ buildName }} — tylko w kręgu światła · prawy klik anuluje</div>
</sc-if>
</div>""" % dict(B, nav=nav("Osada"))

osada_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { speed: 1, open: 0, workers: 3, cat: 'Wojsko', bld: null }; }
  renderVals() {
    const s = this.state;
    const stock = [
      { name: 'Żywność', val: '412', trend: '+18/d', tc: '#2f6b3a' }, { name: 'Woda', val: '380', trend: '+6/d', tc: '#2f6b3a' },
      { name: 'Paliwo (latarnia)', val: '96', trend: '−16/d', tc: '#9b2c22' }, { name: 'Złom', val: '1 240', trend: '+40/d', tc: '#2f6b3a' },
      { name: 'Drewno', val: '530', trend: '+22/d', tc: '#2f6b3a' }, { name: 'Strzały', val: '140', trend: '+12/d', tc: '#2f6b3a' },
      { name: 'Leki', val: '22', trend: '−1/d', tc: '#9b2c22' }, { name: 'Ludzie', val: '64', trend: '18 wojowników', tc: '#5a4a3a' },
      { name: 'Legitymacja', val: '61', trend: 'stabilna', tc: '#5a4a3a' }];
    const sp = [[0, 'II', 'Pauza'], [1, '▶', 'Tempo 1'], [2, '▶▶', 'Tempo 2'], [3, '▶▶▶', 'Tempo 3']];
    const speeds = sp.map(([v, t, l]) => ({ text: t, label: l, cls: s.speed === v ? 'btn on' : 'btn', pick: () => this.setState({ speed: v }) }));
    const A = [
      { t: 'Przypływ za 2 dni', sub: 'Mgła podejdzie od wschodu', d: 'Budynki poza kręgiem światła mogą zarosnąć tkanką. Dolej paliwa do latarni pomocniczych albo cofnij ludzi z pól.', col: '#9b2c22', rot: '0.8deg' },
      { t: 'Wyprawa Kruka wraca jutro', sub: '5 ludzi, 1 ranny, łup z Apteki', d: 'Kruk meldował przez gońca: leki i dwa plany techniczne. Ranny Bronek Sitko, rana nogi.', col: '#2e3b63', rot: '-0.6deg' },
      { t: 'Kłótnia przy studni', sub: 'Racjonowanie wody', d: 'Rodziny z baraku zarzucają kuchni ukrywanie wody. Rozstrzygnij w Ratuszu albo poczekaj — Legitymacja spadnie o 2.', col: '#b07a1e', rot: '0.4deg' }];
    const alarms = A.map((a, i) => ({ title: a.t, sub: a.sub, detail: a.d, col: a.col, rot: a.rot, open: s.open === i, toggle: () => this.setState({ open: s.open === i ? -1 : i }) }));
    const CATS = { 'Światło': [['Latarnia pomocnicza', '60 złomu · 20 paliwa'], ['Lampy uliczne', '15 złomu'], ['Skład paliwa', '80 drewna · 40 złomu']],
      'Mieszkanie': [['Szałas', '30 drewna'], ['Dom', '120 drewna · 40 złomu'], ['Barak', '200 drewna · 60 złomu']],
      'Żywność': [['Pole', '20 drewna'], ['Studnia', '40 kamienia'], ['Kuchnia', '90 drewna · 30 złomu'], ['Wędzarnia', '60 drewna']],
      'Produkcja': [['Kuźnia', '150 złomu · 60 drewna'], ['Szwalnia', '80 drewna'], ['Warsztat', '120 złomu']],
      'Wojsko': [['Plac rekrutacyjny', '100 drewna · 40 złomu'], ['Szkoła walki wręcz', '140 drewna'], ['Szkoła zwiadu', '120 drewna'], ['Wieża strażnicza', '90 drewna · 30 złomu'], ['Palisada', '10 drewna / m']],
      'Społeczeństwo': [['Ratusz', '200 drewna · 80 złomu'], ['Szpital', '160 drewna · 20 leków'], ['Kaplica', '90 drewna']],
      'Nauka': [['Pracownia', '140 drewna · 60 złomu'], ['Sekcja zwłok', '60 drewna']] };
    const cats = Object.keys(CATS).map((c) => ({ name: c, cls: s.cat === c ? 'tab on' : 'tab', pick: () => this.setState({ cat: c, bld: null }) }));
    const blds = CATS[s.cat].map(([n, c]) => ({ name: n, cost: c, border: s.bld === n ? '#9b2c22' : '#8a7a62', bg: s.bld === n ? '#f2ead6' : 'transparent', pick: () => this.setState({ bld: s.bld === n ? null : n }) }));
    return { stock, speeds, paused: s.speed === 0, alarms, cats, blds, building: !!s.bld, buildName: s.bld || '',
      workers: s.workers, output: [0, 4, 7, 9, 10][s.workers],
      minus: () => this.setState({ workers: Math.max(0, s.workers - 1) }), plus: () => this.setState({ workers: Math.min(4, s.workers + 1) }) };
  }
}
"""
write("Main.dc.html", page("Osada — ekran główny", osada_body, osada_js))
print("osada ok")

# =====================================================================================  TECZKA
teczka_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #2a2219; font-family: 'IBM Plex Sans Condensed', sans-serif">
<div aria-hidden="true" style="position: absolute; inset: 0; background: repeating-linear-gradient(90deg, #2e251b 0 3px, #2a2219 3px 9px)"></div>
%(nav)s
<section aria-label="Rejestr ludzi" style="position: absolute; top: 70px; left: 24px; width: 300px; display: flex; flex-direction: column; gap: 10px">
<h2 class="typed" style="margin: 0 0 4px; color: #e6dcc3; font-size: 20px; font-weight: 400">Kartoteka · 18 wojowników</h2>
<sc-for list="{{ people }}" as="p" hint-placeholder-count="4">
<button onClick="{{ p.pick }}" class="paper" style="display: flex; gap: 12px; align-items: center; padding: 8px; border: 0; cursor: pointer; text-align: left; min-height: 84px; outline: {{ p.ring }}; transform: translateX({{ p.dx }})">
<img src="{{ p.img }}" alt="" style="width: 56px; height: 70px; object-fit: cover; object-position: top; image-rendering: pixelated; background: #14111c">
<span><span class="typed" style="font-size: 17px; display: block">{{ p.name }}</span><span style="font-size: 14px; color: #5a4a3a">{{ p.cls }} · {{ p.state }}</span></span>
</button>
</sc-for>
<p style="margin: 6px 0 0; color: #cbbd98; font-size: 14px">Przy większej osadzie kartoteka zamienia się w rejestr z filtrami (klasa, stopień, rany, Wzór).</p>
</section>
<article class="paper" aria-label="Akta osobowe" style="position: absolute; top: 70px; left: 350px; width: 1226px; height: 806px; display: flex; transform: rotate(-0.4deg)">
<div style="width: 520px; padding: 28px 30px; border-right: 2px dashed #b3a37f; display: flex; flex-direction: column; gap: 14px">
<div style="display: flex; gap: 20px">
<div style="position: relative">
<img src="{{ cur.img }}" alt="Portret: {{ cur.name }}" style="width: 168px; height: 210px; object-fit: cover; image-rendering: pixelated; background: #14111c; border: 6px solid #f4eedd; box-shadow: 0 3px 8px rgba(0,0,0,.4); transform: rotate(-2deg)">
<span aria-hidden="true" style="position: absolute; top: -10px; left: 60px; width: 50px; height: 20px; background: rgba(200,190,160,.8); transform: rotate(4deg)"></span>
</div>
<div style="display: flex; flex-direction: column; gap: 6px">
<span style="font-size: 13px; color: #5a4a3a; letter-spacing: 2px">AKTA OSOBOWE NR {{ cur.no }}</span>
<h1 class="typed" style="margin: 0; font-size: 32px; font-weight: 400">{{ cur.name }}</h1>
<span style="font-size: 16px">{{ cur.age }} lat · {{ cur.origin }}</span>
<span style="font-size: 16px">Klasa: <b>{{ cur.cls }}</b></span>
<span style="font-size: 16px">Stopień: <b>{{ cur.rank }}</b></span>
<span style="font-size: 16px">Druga kwalifikacja: {{ cur.second }}</span>
<span class="stamp" style="margin-top: 6px; font-size: 16px; align-self: flex-start">{{ cur.stamp }}</span>
</div>
</div>
<div>
<span style="font-size: 14px; color: #5a4a3a">Wyszkolenie taktyczne</span>
<div style="display: flex; gap: 6px; margin-top: 4px">
<sc-for list="{{ cur.tac }}" as="t" hint-placeholder-count="5"><span style="width: 42px; height: 14px; background: {{ t.c }}; border: 1px solid #2b231c"></span></sc-for>
<span class="num" style="margin-left: 8px; font-weight: 700">{{ cur.tacN }}/5</span>
</div>
</div>
<table class="num" style="border-collapse: collapse; font-size: 16px; width: 100%%">
<caption class="typed" style="text-align: left; font-size: 17px; padding-bottom: 4px">Statystyki</caption>
<tbody>
<sc-for list="{{ cur.stats }}" as="s" hint-placeholder-count="8">
<tr style="border-bottom: 1px dashed #b3a37f"><th scope="row" style="text-align: left; font-weight: 400; padding: 4px 0">{{ s.n }}</th><td style="width: 160px"><div style="height: 10px; background: #cbbd98"><div style="height: 10px; width: {{ s.w }}; background: #2b231c"></div></div></td><td style="text-align: right; font-weight: 700; width: 40px">{{ s.v }}</td></tr>
</sc-for>
</tbody></table>
<div>
<span class="typed" style="font-size: 17px">Cechy i mutacje</span>
<p style="margin: 4px 0 0; font-size: 15px; line-height: 1.5">{{ cur.traits }} <span style="color: #9b2c22; font-family: 'Special Elite', monospace">{{ cur.mut }}</span></p>
</div>
</div>
<div style="flex: 1; padding: 22px 30px; display: flex; flex-direction: column; gap: 14px; min-width: 0">
<div role="tablist" aria-label="Zakładki akt" style="display: flex; gap: 6px">
<sc-for list="{{ tabs }}" as="t" hint-placeholder-count="3">
<button role="tab" aria-selected="{{ t.sel }}" class="{{ t.cls }}" onClick="{{ t.pick }}">{{ t.name }}</button>
</sc-for>
</div>
<sc-if value="{{ tabSkills }}" hint-placeholder-val="{{ true }}">
<div style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px 28px">
<sc-for list="{{ cur.skills }}" as="k" hint-placeholder-count="10">
<div><div style="display: flex; justify-content: space-between; font-size: 15px"><span>{{ k.n }}</span><span class="num" style="font-weight: 700">{{ k.v }}/10</span></div>
<div style="display: flex; gap: 2px; margin-top: 3px"><sc-for list="{{ k.pips }}" as="pp" hint-placeholder-count="10"><span style="flex: 1; height: 10px; background: {{ pp.c }}"></span></sc-for></div></div>
</sc-for>
</div>
<div class="paper2" style="padding: 12px 16px; font-size: 15px; line-height: 1.5">
<b>Sprzęt klasy:</b> {{ cur.gear }}<br>
<b>W ręku teraz:</b> {{ cur.hand }} — <span style="color: {{ cur.fitCol }}; font-weight: 700">{{ cur.fit }}</span>
</div>
</sc-if>
<sc-if value="{{ tabRank }}" hint-placeholder-val="{{ false }}">
<p style="margin: 0; font-size: 15px">Następny awans: <b>{{ cur.next }}</b>. Warunki: {{ cur.req }}</p>
<div style="display: flex; flex-direction: column; gap: 10px">
<sc-for list="{{ paths }}" as="pa" hint-placeholder-count="3">
<button onClick="{{ pa.pick }}" style="text-align: left; padding: 12px 16px; border: 2px solid {{ pa.border }}; background: {{ pa.bg }}; cursor: pointer; border-radius: 3px; font-family: inherit; color: #2b231c; min-height: 44px">
<span class="typed" style="font-size: 18px">{{ pa.name }}</span><br>
<span style="font-size: 14px">{{ pa.desc }}</span>
</button>
</sc-for>
</div>
<p style="margin: 0; font-size: 14px; color: #5a4a3a">Wyboru ścieżki nie da się cofnąć.</p>
<a class="btn" href="Kompleks.dc.html" style="display: inline-flex; align-items: center; align-self: flex-start; text-decoration: none">Skieruj na kurs w kompleksie →</a>
</sc-if>
<sc-if value="{{ tabHist }}" hint-placeholder-val="{{ false }}">
<ol style="margin: 0; padding-left: 20px; display: flex; flex-direction: column; gap: 8px; font-size: 15px; line-height: 1.4">
<sc-for list="{{ cur.hist }}" as="h" hint-placeholder-count="5"><li><span class="num" style="color: #5a4a3a">{{ h.d }}</span> — {{ h.t }}</li></sc-for>
</ol>
</sc-if>
</div>
</article>
</div>""" % dict(B, nav=nav("Ludzie"))

teczka_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { who: 1, tab: 'skills', path: null }; }
  renderVals() {
    const s = this.state;
    const FAM = ['Łuki i kusze', 'Broń prochowa', 'Karabiny', 'Broń maszynowa', 'Broń krótka', 'Broń drzewcowa', 'Obuchowa i ciężka', 'Ostrza', 'Tarcza', 'Granaty i ładunki'];
    const P = [
      { name: 'Tadeusz Mróz', img: '%(mroz)s', no: '0031', age: 41, origin: 'dawny górnik z Huty', cls: 'Strzelec', rank: 'III Specjalista', second: 'brak', stamp: 'WETERAN',
        tac: 4, stats: [62, 7, 5, 6, 4, 6, 8, 6], skills: [3, 2, 8, 1, 4, 2, 3, 3, 2, 5], gear: 'karabin zwykły', hand: 'karabin zwykły', fit: '100%% — pełna skuteczność', fitCol: '#2f6b3a',
        traits: 'Zimna krew (przetrwał 40 s przyduszenia pod Hutą). Pewna ręka.', mut: '', next: 'IV Mistrz', req: 'karabin 9+, 15 walk (ma 11), skrzydło III, instruktor IV',
        paths: [['Strzelec wyborowy → Snajper', 'karabin wyborowy z lunetą, strzał w słaby punkt, wstrzymany oddech'], ['Weteran ognia', 'ogień tłumiący dłużej i celniej, uczy partnera krycia'], ['Kaemista', 'przejście do broni maszynowej, ogień zaporowy']],
        hist: [['Dzień 3', 'Obrona bramy przed Ogarami: 3 trafienia, bez ran'], ['Dzień 6', 'Wyprawa do Huty: zabił Krzykacza z 60 m'], ['Dzień 9', 'Przyduszony przez Dawnego Żołnierza, utrzymał pozycję'], ['Dzień 11', 'Kurs w Szkole strzeleckiej II'], ['Dzień 13', 'Zasadzka Szabrowników na trakcie: ranny w ramię (lekko)']], state: 'zdolny do walki' },
      { name: 'Halina Wrona', img: '%(wrona)s', no: '0044', age: 27, origin: 'urodzona w osadzie', cls: 'Zwiadowca', rank: 'II Klasa', second: 'brak', stamp: 'ZWIAD',
        tac: 3, stats: [48, 6, 4, 4, 8, 9, 6, 5], skills: [6, 0, 4, 0, 3, 1, 1, 5, 0, 2], gear: 'kusza, nóż, lekki ubiór', hand: 'karabin zwykły', fit: '50%% — broń obca, brak zdolności', fitCol: '#9b2c22',
        traits: 'Ma oko (wykryła sieć Pajęczarza).', mut: 'Oczy Mgły — widzi w Mgle, demaskuje Naśladowców. Odmienność 34.', next: 'III Specjalista', req: 'kusza lub skradanie 6+, 5 walk (ma 4), skrzydło II',
        paths: [['Tropiciel', 'zapowiada ewolucję Mgły, wykrywa Naśladowców i drgania Kopacza z daleka'], ['Cichy łowca', 'cichy strzał z kuszy, zabija Bezokich bez alarmu'], ['Przewodnik wypraw', 'krótsze trasy, mniej Odmienności dla oddziału w Mgle']],
        hist: [['Dzień 5', 'Zwiad do Lasu Granicznego, mapa ścieżek'], ['Dzień 8', 'Wykryła Pajęczarza w ruinach — oddział ominął sieć'], ['Dzień 12', 'Godzina w Mgle bez maski: +12 Odmienności']], state: 'na wyprawie' },
      { name: 'Bronek Sitko', img: '%(sitko)s', no: '0012', age: 35, origin: 'kowal z Przełęczy', cls: 'Tarczownik', rank: 'II Klasa', second: 'brak', stamp: 'RANNY',
        tac: 2, stats: [70, 3, 7, 8, 4, 4, 5, 8], skills: [0, 0, 1, 0, 2, 5, 4, 3, 6, 1], gear: 'tarcza + broń jednoręczna', hand: 'dzida i tarcza', fit: '80%% — sprzęt pokrewny', fitCol: '#b07a1e',
        traits: 'Twardziel. Drżące ręce (od Dnia 13).', mut: '', next: 'III Specjalista', req: 'tarcza 6+ (ma 6), 5 walk (ma 7), przeżyta rana — spełnione',
        paths: [['Mistrz tarczy', 'mur tarcz szerszy, zaparcie przeciw Rogaczom'], ['Dzidnik', 'jeż, pchnięcie z drugiego szeregu'], ['Łamacz', 'młot, rozbicie pancerza i chityny']],
        hist: [['Dzień 2', 'Zatrzymał szarżę Rogacza w bramie'], ['Dzień 7', 'Mur tarcz przeciw Szczurzej Fali, bez strat'], ['Dzień 13', 'Rana nogi w Aptece, niesiony przez Kruka']], state: 'w szpitalu (4 dni)' },
      { name: 'Ewa Kruk', img: '%(kruk)s', no: '0050', age: 31, origin: 'z karawany Gildii', cls: 'Sanitariuszka', rank: 'II Klasa', second: 'Strzelec (II)', stamp: 'SANITARNA',
        tac: 3, stats: [52, 5, 3, 4, 6, 6, 8, 6], skills: [1, 0, 4, 0, 5, 0, 0, 2, 0, 1], gear: 'apteczki, nosze', hand: 'pistolet', fit: '80%% — pokrewny (druga kwalifikacja)', fitCol: '#b07a1e',
        traits: 'Spokojna dłoń. Wyniosła rannego spod ognia (Dzień 13).', mut: '', next: 'III Felczer', req: 'medycyna polowa 6+ (ma 5), szpital przy szkole sanitarnej',
        paths: [['Felczer', 'amputacja polowa, zdjęcie Pijawca, ratowanie Kokonów'], ['Sanitariusz bojowy', 'stabilizacja pod ogniem, szybsze wynoszenie'], ['Lekarz osady', 'szybsze leczenie w szpitalu, mniej trwałych ran']],
        hist: [['Dzień 4', 'Dołączyła z karawany Gildii Solnej'], ['Dzień 10', 'Kurs w Szkole sanitarnej I'], ['Dzień 13', 'Wyniosła Sitkę spod ognia w Aptece']], state: 'zdolna do walki' }];
    const SN = ['Zdrowie', 'Celność', 'Walka wręcz', 'Siła', 'Zwinność', 'Percepcja', 'Opanowanie', 'Wytrzymałość'];
    const c = P[s.who];
    const pips = (v) => Array.from({ length: 10 }, (_, i) => ({ c: i < v ? '#2b231c' : '#cbbd98' }));
    const cur = Object.assign({}, c, {
      tacN: c.tac, tac: Array.from({ length: 5 }, (_, i) => ({ c: i < c.tac ? '#2e3b63' : 'transparent' })),
      stats: c.stats.map((v, i) => ({ n: SN[i], v: v, w: (i === 0 ? v : v * 10) + '%%' })),
      skills: c.skills.map((v, i) => ({ n: FAM[i], v: v, pips: pips(v) })),
      hist: c.hist.map(([d, t]) => ({ d, t })) });
    const people = P.map((p, i) => ({ name: p.name, img: p.img, cls: p.cls, state: p.state, ring: s.who === i ? '3px solid #e0a640' : 'none', dx: s.who === i ? '10px' : '0px',
      pick: () => this.setState({ who: i, path: null }) }));
    const T = [['skills', 'Umiejętności'], ['rank', 'Awans'], ['hist', 'Historia walk']];
    const tabs = T.map(([k, n]) => ({ name: n, sel: s.tab === k ? 'true' : 'false', cls: s.tab === k ? 'btn on' : 'btn', pick: () => this.setState({ tab: k }) }));
    const paths = c.paths.map(([n, d], i) => ({ name: n, desc: d, border: s.path === i ? '#9b2c22' : '#8a7a62', bg: s.path === i ? '#f2ead6' : 'transparent', pick: () => this.setState({ path: i }) }));
    return { people, cur, tabs, paths, tabSkills: s.tab === 'skills', tabRank: s.tab === 'rank', tabHist: s.tab === 'hist' };
  }
}
""" % B
write("Teczka.dc.html", page("Teczka wojownika", teczka_body, teczka_js))
print("teczka ok")

# =====================================================================================  KOMPLEKS
kompleks_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #2a2219; font-family: 'IBM Plex Sans Condensed', sans-serif">
<div aria-hidden="true" style="position: absolute; inset: 0; background: repeating-linear-gradient(90deg, #2e251b 0 3px, #2a2219 3px 9px)"></div>
%(nav)s
<section aria-label="Plan kompleksu" style="position: absolute; top: 70px; left: 24px; width: 900px; height: 806px; background: #2f3e63; border-radius: 2px; box-shadow: 0 6px 18px rgba(0,0,0,.55); transform: rotate(0.4deg); overflow: hidden">
<div aria-hidden="true" style="position: absolute; inset: 0; background-image: linear-gradient(rgba(220,230,255,.08) 1px, transparent 1px), linear-gradient(90deg, rgba(220,230,255,.08) 1px, transparent 1px); background-size: 30px 30px"></div>
<h2 class="typed" style="position: absolute; top: 18px; left: 24px; margin: 0; color: #e8eefc; font-size: 24px; font-weight: 400">Kompleks szkoleniowy — plan</h2>
<p style="position: absolute; top: 54px; left: 24px; margin: 0; color: #c9d4f0; font-size: 14px">Skrzydło działa najwyżej 2 kratki od Placu lub innego skrzydła · sąsiedzi +5%% do tempa kursów</p>
<sc-for list="{{ links }}" as="l" hint-placeholder-count="6">
<div aria-hidden="true" style="position: absolute; left: {{ l.x }}; top: {{ l.y }}; width: {{ l.w }}; height: {{ l.h }}; background: rgba(232,238,252,.45)"></div>
</sc-for>
<sc-for list="{{ wings }}" as="w" hint-placeholder-count="10">
<button onClick="{{ w.pick }}" style="position: absolute; left: {{ w.x }}; top: {{ w.y }}; width: {{ w.wd }}; height: {{ w.ht }}; border: {{ w.border }}; background: {{ w.bg }}; color: {{ w.fg }}; cursor: pointer; border-radius: 2px; padding: 8px; text-align: left; font-family: inherit">
<span class="typed" style="font-size: 16px; display: block">{{ w.name }}</span>
<span style="font-size: 13px">{{ w.sub }}</span>
</button>
</sc-for>
</section>
<section class="paper" aria-label="Wybrane skrzydło" style="position: absolute; top: 70px; left: 950px; width: 626px; height: 806px; padding: 24px 28px; display: flex; flex-direction: column; gap: 14px; transform: rotate(-0.5deg)">
<div style="display: flex; justify-content: space-between; align-items: baseline">
<h2 class="typed" style="margin: 0; font-size: 28px; font-weight: 400">{{ sel.name }}</h2>
<span class="num" style="font-size: 16px">poziom {{ sel.lvl }} · od epoki {{ sel.era }}</span>
</div>
<p style="margin: 0; font-size: 15px">Najwyższy stopień do zdobycia: <b>{{ sel.cap }}</b> · Instruktor: <b>{{ sel.instr }}</b></p>
<div>
<span class="typed" style="font-size: 18px">Kursy</span>
<div style="display: flex; flex-direction: column; gap: 8px; margin-top: 6px">
<sc-for list="{{ courses }}" as="c" hint-placeholder-count="4">
<button onClick="{{ c.pick }}" style="display: flex; justify-content: space-between; align-items: center; gap: 12px; min-height: 48px; padding: 6px 14px; border: 2px solid {{ c.border }}; background: {{ c.bg }}; cursor: pointer; border-radius: 3px; font-family: inherit; color: #2b231c; text-align: left">
<span><span class="typed" style="font-size: 16px">{{ c.name }}</span><br><span style="font-size: 13px; color: #5a4a3a">{{ c.req }}</span></span>
<span class="num" style="font-size: 14px; white-space: nowrap">{{ c.days }} dni · {{ c.cost }}</span>
</button>
</sc-for>
</div>
</div>
<div>
<span class="typed" style="font-size: 18px">Kursanci ({{ slotsUsed }}/{{ sel.slots }})</span>
<div style="display: flex; flex-direction: column; gap: 6px; margin-top: 6px">
<sc-for list="{{ cands }}" as="k" hint-placeholder-count="4">
<div style="display: flex; justify-content: space-between; align-items: center; padding: 4px 0; border-bottom: 1px dashed #b3a37f">
<span style="font-size: 15px">{{ k.name }} <span style="color: #5a4a3a">— {{ k.info }}</span></span>
<button class="{{ k.cls }}" onClick="{{ k.toggle }}" style="min-width: 128px">{{ k.label }}</button>
</div>
</sc-for>
</div>
</div>
<div class="paper2" style="margin-top: auto; padding: 12px 16px; font-size: 15px; line-height: 1.5">
Kursant znika ze służby na czas kursu. Wybrany kurs: <b>{{ courseName }}</b>, koniec: <b>dzień {{ endDay }}</b>.<br>
Prawo „Pobór” skraca kursy o 30%%, ale obniża ich jakość.
</div>
</section>
</div>""" % dict(B, nav=nav("Kompleks"))

kompleks_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { wing: 'strz', course: 0, enrolled: { 'Tadeusz Mróz': true } }; }
  renderVals() {
    const s = this.state;
    const W = {
      plac: { name: 'Plac rekrutacyjny', era: 'Złom', lvl: 'II', built: true, x: 350, y: 330, w: 200, h: 130, cap: 'I Rekrut · taktyka do 3', instr: 'sierż. Ostoja (IV)', slots: 6,
        courses: [['Podstawy rekruta', 'każdy nowy człowiek', 2, '10 strzał'], ['Wyszkolenie taktyczne 3', 'taktyka 2, jedna walka', 4, '20 strzał']] },
      wrecz: { name: 'Szkoła walki wręcz', era: 'Złom', lvl: 'II', built: true, x: 110, y: 330, w: 190, h: 130, cap: 'III Specjalista', instr: 'Bronek Sitko (II) — ranny', slots: 4,
        courses: [['Tarczownik', 'tarcza 3+, 1 walka', 3, '20 drewna'], ['Dzidnik', 'drzewcowa 3+', 3, '20 drewna'], ['Łamacz', 'obuchowa 6+, 5 walk', 6, '30 złomu']] },
      zwiad: { name: 'Szkoła zwiadu', era: 'Złom', lvl: 'I', built: true, x: 350, y: 140, w: 200, h: 130, cap: 'II Klasa', instr: 'brak', slots: 2,
        courses: [['Zwiadowca', 'percepcja 5+', 3, '10 strzał']] },
      strz: { name: 'Szkoła strzelecka', era: 'Kuźnia', lvl: 'II', built: true, x: 600, y: 330, w: 210, h: 130, cap: 'III Specjalista', instr: 'Tadeusz Mróz (III)', slots: 4,
        courses: [['Łucznik', 'łuki 3+, 1 walka', 3, '40 strzał'], ['Kusznik', 'łuki 3+', 3, '20 bełtów'], ['Strzelec wyborowy', 'łuki lub karabin 6+, 5 walk', 6, '60 strzał']] },
      san: { name: 'Szkoła sanitarna', era: 'Kuźnia', lvl: 'I', built: true, x: 350, y: 510, w: 200, h: 130, cap: 'II Klasa', instr: 'Ewa Kruk (II)', slots: 2,
        courses: [['Sanitariusz', 'medycyna 3+', 4, '5 leków'], ['Sanitariusz polowy (druga kwalif.)', 'stopień III', 8, '8 leków']] },
      choraz: { name: 'Szkoła chorążych', era: 'Kuźnia', lvl: '—', built: false, x: 110, y: 510, w: 190, h: 130, cap: 'do zbudowania', instr: '—', slots: 0, courses: [] },
      saper: { name: 'Szkoła saperska', era: 'Para', lvl: '—', built: false, x: 600, y: 510, w: 210, h: 130, cap: 'epoka Pary', instr: '—', slots: 0, courses: [] },
      szturm: { name: 'Szkoła szturmowa', era: 'Nabój', lvl: '—', built: false, x: 600, y: 140, w: 210, h: 130, cap: 'epoka Naboju', instr: '—', slots: 0, courses: [] },
      akad: { name: 'Akademia dowódców', era: 'Kuźnia', lvl: 'I', built: true, x: 110, y: 140, w: 190, h: 130, cap: 'dowódca 2', instr: 'brak', slots: 1,
        courses: [['Zasoby ludzkie 2', 'przywództwo 4+', 5, '—'], ['Orientacja w terenie 2', 'przywództwo 4+', 5, '—'], ['Taktyka i formacje 2', 'przywództwo 4+', 5, '—']] },
      latarnik: { name: 'Szkoła Latarników', era: 'Światło', lvl: '—', built: false, x: 350, y: 690, w: 200, h: 90, cap: 'epoka Światła', instr: '—', slots: 0, courses: [] } };
    const wings = Object.keys(W).map((k) => { const w = W[k]; const on = s.wing === k;
      return { name: w.name, sub: w.built ? 'poziom ' + w.lvl : 'od epoki ' + w.era, x: w.x + 'px', y: (w.y + 30) + 'px', wd: w.w + 'px', ht: w.h + 'px',
        border: on ? '3px solid #e0a640' : (w.built ? '2px solid #e8eefc' : '2px dashed #9fb0d8'), bg: w.built ? (k === 'plac' ? 'rgba(232,238,252,.30)' : 'rgba(232,238,252,.16)') : 'transparent',
        fg: w.built ? '#f4f6fc' : '#c9d4f0', pick: () => this.setState({ wing: k, course: 0 }) }; });
    const L = [[300, 395, 50, 4], [550, 395, 50, 4], [450, 300, 4, 60], [450, 490, 4, 50], [205, 300, 4, 60], [705, 300, 4, 60], [205, 490, 4, 50], [705, 490, 4, 50], [450, 670, 4, 50]];
    const links = L.map(([x, y, w, h]) => ({ x: x + 'px', y: (y + 30) + 'px', w: w + 'px', h: h + 'px' }));
    const w = W[s.wing];
    const courses = w.courses.map(([n, r, d, c], i) => ({ name: n, req: r, days: d, cost: c, border: s.course === i ? '#9b2c22' : '#8a7a62', bg: s.course === i ? '#f2ead6' : 'transparent', pick: () => this.setState({ course: i }) }));
    const C = [['Tadeusz Mróz', 'karabin 8, 11 walk'], ['Józef Lis', 'rekrut, łuki 3'], ['Marta Bąk', 'łuki 4, 2 walki'], ['Halina Wrona', 'na wyprawie — niedostępna']];
    const used = Object.values(s.enrolled).filter(Boolean).length;
    const cands = w.built ? C.map(([n, info]) => { const on = !!s.enrolled[n]; const away = info.indexOf('niedostępna') >= 0;
      return { name: n, info, cls: on ? 'btn on' : 'btn', label: away ? '—' : (on ? 'Zapisany ✓' : 'Zapisz'),
        toggle: () => { if (away) return; const e = Object.assign({}, s.enrolled); e[n] = !on; this.setState({ enrolled: e }); } }; }) : [];
    const cur = w.courses[s.course];
    return { wings, links, sel: { name: w.name, era: w.era, lvl: w.lvl, cap: w.cap, instr: w.instr, slots: w.slots },
      courses, cands, slotsUsed: w.built ? used : 0, courseName: cur ? cur[0] : 'skrzydło niezbudowane', endDay: cur ? 14 + cur[2] : '—' };
  }
}
"""
write("Kompleks.dc.html", page("Kompleks szkoleniowy", kompleks_body, kompleks_js))
print("kompleks ok")

# =====================================================================================  WALKA
walka_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #14111c; font-family: 'IBM Plex Sans Condensed', sans-serif">
<img src="%(bitwa)s" alt="Walka przy bramie: oddział przeciw mutantom" style="position: absolute; inset: 0; width: 1600px; height: 900px; object-fit: cover; image-rendering: pixelated">
<sc-if value="{{ flare }}" hint-placeholder-val="{{ false }}"><div aria-hidden="true" style="position: absolute; inset: 0; background: radial-gradient(circle at 1100px 260px, rgba(255,200,170,.35), rgba(255,120,80,.08) 420px, transparent 700px)"></div></sc-if>
%(nav)s
<section class="paper2" aria-label="Sterowanie walką" style="position: absolute; top: 20px; left: 20px; height: 64px; padding: 0 12px 0 18px; display: flex; align-items: center; gap: 12px">
<span class="typed" style="font-size: 20px">Brama · 01:12</span>
<sc-for list="{{ speeds }}" as="sp" hint-placeholder-count="4"><button class="{{ sp.cls }}" onClick="{{ sp.pick }}" aria-label="{{ sp.label }}" style="min-width: 48px">{{ sp.text }}</button></sc-for>
<button class="btn" onClick="{{ fire }}" style="border-color: #9b2c22; color: #9b2c22">Flara ({{ flares }})</button>
</section>
<section class="paper2" aria-label="Nakładki" style="position: absolute; top: 96px; left: 20px; padding: 8px 12px; display: flex; gap: 8px; align-items: center">
<span style="font-size: 14px">Nakładki:</span>
<sc-for list="{{ ovl }}" as="o" hint-placeholder-count="3"><button class="{{ o.cls }}" onClick="{{ o.pick }}">{{ o.name }}</button></sc-for>
</section>
<sc-if value="{{ showOrders }}" hint-placeholder-val="{{ true }}">
<sc-for list="{{ bubbles }}" as="b" hint-placeholder-count="4">
<div class="paper" style="position: absolute; left: {{ b.x }}; top: {{ b.y }}; padding: 6px 12px; font-size: 15px; border-radius: 10px; max-width: 220px">
<span class="typed">{{ b.who }}:</span> {{ b.t }}
<span aria-hidden="true" style="position: absolute; left: 18px; bottom: -10px; width: 0; height: 0; border-left: 8px solid transparent; border-right: 8px solid transparent; border-top: 10px solid #e6dcc3"></span>
</div>
</sc-for>
</sc-if>
<sc-if value="{{ showFire }}" hint-placeholder-val="{{ false }}">
<div aria-hidden="true" style="position: absolute; left: 640px; top: 300px; width: 420px; height: 220px; border: 2px dashed rgba(224,166,64,.9); background: rgba(224,166,64,.12); border-radius: 50%%; transform: rotate(-12deg)"></div>
<span class="typed" style="position: absolute; left: 760px; top: 270px; color: #f0c070; font-size: 16px; text-shadow: 0 1px 2px #000">sektor ognia strzelców</span>
<div aria-hidden="true" style="position: absolute; left: 980px; top: 180px; width: 260px; height: 160px; border: 2px dashed rgba(220,90,70,.9); background: rgba(220,90,70,.12); border-radius: 50%%"></div>
<span class="typed" style="position: absolute; left: 1010px; top: 150px; color: #f08070; font-size: 16px; text-shadow: 0 1px 2px #000">przyduszenie wroga</span>
</sc-if>
<aside class="paper" aria-label="Meldunki" style="position: absolute; top: 96px; right: 24px; width: 300px; padding: 12px 14px; display: flex; flex-direction: column; gap: 6px">
<h2 class="typed" style="margin: 0; font-size: 18px; font-weight: 400">Meldunki dowódcy</h2>
<sc-for list="{{ log }}" as="l" hint-placeholder-count="5"><p style="margin: 0; font-size: 14px; line-height: 1.35"><span class="num" style="color: #5a4a3a">{{ l.t }}</span> {{ l.m }}</p></sc-for>
</aside>
<section aria-label="Skład" style="position: absolute; left: 20px; right: 20px; bottom: 16px; display: flex; gap: 10px">
<sc-for list="{{ squad }}" as="u" hint-placeholder-count="6">
<button onClick="{{ u.pick }}" class="paper" style="flex: 1; display: flex; gap: 10px; padding: 8px; border: 0; cursor: pointer; text-align: left; outline: {{ u.ring }}; min-height: 92px">
<img src="{{ u.img }}" alt="" style="width: 52px; height: 66px; object-fit: cover; object-position: top; image-rendering: pixelated; background: #14111c">
<span style="flex: 1; display: flex; flex-direction: column; gap: 3px; min-width: 0">
<span class="typed" style="font-size: 15px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{{ u.name }}</span>
<span style="font-size: 12px; color: #5a4a3a">{{ u.act }}</span>
<span style="display: flex; align-items: center; gap: 4px; font-size: 11px">ZDR<span style="flex: 1; height: 7px; background: #cbbd98"><span style="display: block; height: 7px; width: {{ u.hp }}; background: #9b2c22"></span></span></span>
<span style="display: flex; align-items: center; gap: 4px; font-size: 11px">MOR<span style="flex: 1; height: 7px; background: #cbbd98"><span style="display: block; height: 7px; width: {{ u.mor }}; background: #2e3b63"></span></span></span>
</span>
</button>
</sc-for>
</section>
<sc-if value="{{ hasSel }}" hint-placeholder-val="{{ false }}">
<div class="paper" style="position: absolute; left: 20px; bottom: 124px; width: 360px; padding: 12px 16px; font-size: 14px; line-height: 1.45">
<span class="typed" style="font-size: 17px">{{ selName }}</span><br>{{ selInfo }}
</div>
</sc-if>
</div>""" % dict(B, nav=nav("Walka"))

walka_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { speed: 1, orders: true, fire: false, flare: false, flares: 2, sel: -1 }; }
  renderVals() {
    const s = this.state;
    const sp = [[0, 'II', 'Pauza'], [1, '▶', 'Tempo 1'], [2, '▶▶', 'Tempo 2'], [4, '▶▶▶▶', 'Tempo 4']];
    const speeds = sp.map(([v, t, l]) => ({ text: t, label: l, cls: s.speed === v ? 'btn on' : 'btn', pick: () => this.setState({ speed: v }) }));
    const ovl = [['orders', 'Rozkazy'], ['fire', 'Strefy ognia']].map(([k, n]) => ({ name: n, cls: s[k] ? 'btn on' : 'btn', pick: () => this.setState({ [k]: !s[k] }) }));
    const bubbles = [
      { who: 'Dowódca', t: 'Mur tarcz w bramie! Strzelcy za tarcze.', x: '520px', y: '380px' },
      { who: 'Mróz', t: 'Krzykacz z tyłu, biorę go.', x: '300px', y: '520px' },
      { who: 'Kruk', t: 'Ranny przy wozie, idę!', x: '760px', y: '560px' },
      { who: 'Zwiad', t: 'Ogary obchodzą od lewej!', x: '980px', y: '420px' }];
    const log = [['01:12', 'Szczurza Fala dobiła do muru tarcz, tarczownicy trzymają.'], ['01:05', 'Strzelcy zmienili cel na Krzykacza (Zasoby ludzkie 3).'],
      ['00:58', 'Ogary obchodzą lewą flankę — dowódca nie przesunął odwodu (Teren 2).'], ['00:41', 'Mróz: przyduszony 6 s, utrzymał pozycję.'], ['00:30', 'Rozkaz: formacja „jeż” przy bramie.']].map(([t, m]) => ({ t, m }));
    const U = [['Bronek Sitko', '%(sitko)s', 'trzyma bramę (tarcza)', 74, 66, 'Tarczownik II. Zaparcie aktywne: szarża go nie przewróci. Morale spada — Drżące ręce.'],
      ['Tadeusz Mróz', '%(mroz)s', 'celuje w Krzykacza', 92, 88, 'Strzelec III, taktyka 4. Ogień tłumiący gotowy za 3 s. Amunicja 14/30.'],
      ['Ewa Kruk', '%(kruk)s', 'biegnie do rannego', 100, 71, 'Sanitariuszka II. Stabilizacja pod ogniem. Apteczki 3.'],
      ['Józef Lis', '%(wrona)s', 'przyduszony', 40, 22, 'Łucznik II. PANIKA za 4 s, jeśli przyduszenie potrwa. Chorąży poza zasięgiem.'],
      ['Marta Bąk', '%(wrona)s', 'strzela salwą', 85, 64, 'Łuczniczka II. Salwa co 6 s.'],
      ['Dowódca Ostoja', '%(mroz)s', 'wydaje rozkazy', 96, 90, 'Dowódca 3: Zasoby ludzkie 3, Teren 2, Formacje 3.']];
    const squad = U.map(([n, img, act, hp, mor, info], i) => ({ name: n, img, act, hp: hp + '%%', mor: mor + '%%', ring: s.sel === i ? '3px solid #e0a640' : 'none', pick: () => this.setState({ sel: s.sel === i ? -1 : i }) }));
    return { speeds, ovl, showOrders: s.orders, showFire: s.fire, bubbles, log, squad, flare: s.flare, flares: s.flares,
      fire: () => { if (s.flares > 0) this.setState({ flare: true, flares: s.flares - 1 }); },
      hasSel: s.sel >= 0, selName: s.sel >= 0 ? U[s.sel][0] : '', selInfo: s.sel >= 0 ? U[s.sel][5] : '' };
  }
}
""" % B
write("Walka.dc.html", page("Walka — widok taktyczny", walka_body, walka_js))
print("walka ok")

# =====================================================================================  RAPORT
raport_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #2a2219; font-family: 'IBM Plex Sans Condensed', sans-serif">
<div aria-hidden="true" style="position: absolute; inset: 0; background: repeating-linear-gradient(90deg, #2e251b 0 3px, #2a2219 3px 9px)"></div>
%(nav)s
<article class="paper" aria-label="Meldunek" style="position: absolute; top: 70px; left: 40px; width: 980px; height: 806px; padding: 30px 40px; transform: rotate(-0.6deg); display: flex; flex-direction: column; gap: 14px">
<div style="display: flex; justify-content: space-between; align-items: flex-start">
<div class="typed" style="font-size: 16px; line-height: 1.5">MELDUNEK NR 14/3<br>Obrona bramy wschodniej · dzień 14, 21:30<br>Dowódca: Ostoja (3) · skład: 6 ludzi</div>
<span class="stamp" style="font-size: 30px">ODPARTO</span>
</div>
<div class="num" style="display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px">
<sc-for list="{{ sums }}" as="m" hint-placeholder-count="4"><div style="border: 2px solid #2b231c; padding: 8px 12px"><span style="font-size: 13px; color: #5a4a3a">{{ m.n }}</span><br><span style="font-size: 24px; font-weight: 700">{{ m.v }}</span></div></sc-for>
</div>
<h2 class="typed" style="margin: 4px 0 0; font-size: 20px; font-weight: 400">Przebieg (kliknij zdarzenie)</h2>
<div style="position: relative; height: 70px">
<div aria-hidden="true" style="position: absolute; left: 0; right: 0; top: 30px; height: 3px; background: #2b231c"></div>
<sc-for list="{{ events }}" as="e" hint-placeholder-count="7">
<button onClick="{{ e.pick }}" aria-label="{{ e.t }} {{ e.title }}" style="position: absolute; left: {{ e.x }}; top: 8px; width: 46px; height: 46px; border-radius: 50%%; border: 3px solid #2b231c; background: {{ e.bg }}; cursor: pointer; font-family: inherit; font-size: 12px; color: {{ e.fg }}">{{ e.t }}</button>
</sc-for>
</div>
<div style="display: flex; gap: 24px; flex: 1; min-height: 0">
<div style="flex: 1">
<p class="typed" style="margin: 0 0 6px; font-size: 18px">{{ ev.t }} — {{ ev.title }}</p>
<p style="margin: 0; font-size: 16px; line-height: 1.5">{{ ev.desc }}</p>
<p style="margin: 14px 0 0; font-family: 'Special Elite', monospace; font-size: 17px; color: #9b2c22; transform: rotate(-1deg); line-height: 1.4">{{ ev.note }}</p>
</div>
<div style="width: 300px; display: flex; flex-direction: column; gap: 10px">
<span class="typed" style="font-size: 18px">Ocena dowódcy</span>
<sc-for list="{{ grades }}" as="g" hint-placeholder-count="3">
<div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed #b3a37f; padding: 4px 0"><span style="font-size: 15px">{{ g.n }}</span><span class="stamp" style="font-size: 14px; color: {{ g.c }}; border-color: {{ g.c }}">{{ g.v }}</span></div>
</sc-for>
<a class="btn" href="Walka.dc.html" style="display: inline-flex; align-items: center; justify-content: center; text-decoration: none; margin-top: auto">Powtórka od {{ ev.t }} →</a>
</div>
</div>
</article>
<aside class="paper2" aria-label="Wkład klas" style="position: absolute; top: 90px; left: 1050px; width: 520px; padding: 22px 26px; transform: rotate(0.8deg); display: flex; flex-direction: column; gap: 10px">
<h2 class="typed" style="margin: 0; font-size: 22px; font-weight: 400">Wkład klas</h2>
<table class="num" style="border-collapse: collapse; font-size: 15px">
<thead><tr style="text-align: left; border-bottom: 2px solid #2b231c"><th scope="col" style="padding: 4px 0">Klasa</th><th scope="col">Skutecz.</th><th scope="col">Uwagi</th></tr></thead>
<tbody>
<sc-for list="{{ classes }}" as="c" hint-placeholder-count="5">
<tr style="border-bottom: 1px dashed #a39370; vertical-align: top"><td style="padding: 6px 8px 6px 0; font-weight: 600">{{ c.n }}</td><td style="padding: 6px 8px 6px 0; color: {{ c.col }}; font-weight: 700">{{ c.v }}</td><td style="padding: 6px 0">{{ c.u }}</td></tr>
</sc-for>
</tbody></table>
<div class="paper" style="padding: 12px 16px; font-size: 15px; line-height: 1.5; transform: rotate(-1.5deg)">
<span class="typed" style="font-size: 17px">Zalecenia</span><br>
1. Odwód na lewą flankę: kurs Orientacji w terenie 3 dla Ostoi.<br>
2. Chorąży w składzie: Lis wpadł w panikę poza zasięgiem morale. Zbuduj Szkołę chorążych.<br>
3. Mróz gotowy do awansu na Mistrza: brakuje instruktora IV.
</div>
<a class="btn" href="Teczka.dc.html" style="display: inline-flex; align-items: center; align-self: flex-start; text-decoration: none">Otwórz akta uczestników →</a>
</aside>
</div>""" % dict(B, nav=nav("Raport"))

raport_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { ev: 3 }; }
  renderVals() {
    const s = this.state;
    const E = [
      ['00:05', 'Kontakt', 'Zwiad zgłasza Szczurzą Falę i dwa Ogary od wschodu.', 'Dobrze — zwiad 40 s przed kontaktem.'],
      ['00:30', 'Jeż w bramie', 'Dowódca ustawia jeża z dzid w bramie, łucznicy za palisadą.', 'Formacja dobrana trafnie (Formacje 3).'],
      ['00:41', 'Przyduszenie', 'Dawny Żołnierz przyducha Mroza; Mróz trzyma pozycję.', 'Zimna krew zadziałała — warto go awansować.'],
      ['00:58', 'Flanka', 'Ogary obchodzą lewą stronę. Odwodu nie przesunięto.', 'BŁĄD: Teren 2 nie widzi obejścia. Kosztowało rannego Lisa.'],
      ['01:05', 'Zmiana celu', 'Strzelcy biorą Krzykacza przed Ogarami.', 'Dobra priorytetyzacja (Zasoby ludzkie 3).'],
      ['01:12', 'Panika Lisa', 'Lis ucieka spod przyduszenia, łuk porzucony.', 'BŁĄD: brak chorążego w zasięgu.'],
      ['01:40', 'Odparcie', 'Fala rozbita na murze tarcz, Ogary zabite.', 'Bez strat śmiertelnych.']];
    const events = E.map(([t, title], i) => ({ t, title, x: (i * 145) + 'px', bg: s.ev === i ? '#2b231c' : (E[i][3].indexOf('BŁĄD') === 0 ? '#e9b9ad' : '#e6dcc3'), fg: s.ev === i ? '#e6dcc3' : '#2b231c', pick: () => this.setState({ ev: i }) }));
    const e = E[s.ev];
    const sums = [['Polegli', '0'], ['Ranni', '1 (Lis)'], ['Zużyte strzały', '62'], ['Łup', 'chityna ×4']].map(([n, v]) => ({ n, v }));
    const grades = [['Zasoby ludzkie', 'DOBRZE', '#2f6b3a'], ['Orientacja w terenie', 'SŁABO', '#9b2c22'], ['Taktyka i formacje', 'DOBRZE', '#2f6b3a']].map(([n, v, c]) => ({ n, v, c }));
    const classes = [['Tarczownik', '92%%', '#2f6b3a', 'mur tarcz zatrzymał Falę'], ['Strzelec', '81%%', '#2f6b3a', 'Krzykacz zabity w 7 s'], ['Łucznik', '44%%', '#9b2c22', 'panika, porzucona broń'],
      ['Sanitariusz', '100%%', '#2f6b3a', 'ranny wyniesiony w 9 s'], ['Zwiadowca', '—', '#5a4a3a', 'na wyprawie, brak w składzie']].map(([n, v, col, u]) => ({ n, v, col, u }));
    return { events, ev: { t: e[0], title: e[1], desc: e[2], note: e[3] }, sums, grades, classes };
  }
}
"""
write("Raport.dc.html", page("Raport po walce", raport_body, raport_js.replace("%%", "%")))
print("raport ok")

# =====================================================================================  MAPA
NODES = json.load(open("/home/claude/latarnia3d/ui/mapa_nodes.json"))
mapa_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #2a2219; font-family: 'IBM Plex Sans Condensed', sans-serif">
<img src="%(mapa)s" alt="Papierowa mapa dorzecza z węzłami, drogami i strefami Mgły" style="position: absolute; inset: 0; width: 1600px; height: 900px">
<sc-for list="{{ segs }}" as="g" hint-placeholder-count="2">
<div aria-hidden="true" style="position: absolute; left: {{ g.x }}; top: {{ g.y }}; width: {{ g.len }}; height: 5px; background: #9b2c22; transform-origin: 0 50%%; transform: rotate({{ g.ang }}); opacity: .85"></div>
</sc-for>
<sc-for list="{{ pins }}" as="p" hint-placeholder-count="11">
<button onClick="{{ p.pick }}" aria-label="{{ p.name }}" style="position: absolute; left: {{ p.x }}; top: {{ p.y }}; width: 44px; height: 44px; border: 0; background: transparent; cursor: pointer; padding: 0">
<span aria-hidden="true" style="display: block; width: 18px; height: 18px; margin: 4px auto 0; border-radius: 50%%; background: {{ p.col }}; border: 2px solid #2b231c; box-shadow: 0 3px 4px rgba(0,0,0,.4)"></span>
<span aria-hidden="true" style="display: block; width: 3px; height: 14px; margin: 0 auto; background: #2b231c"></span>
</button>
</sc-for>
<span class="typed" style="position: absolute; left: {{ pawnX }}; top: {{ pawnY }}; padding: 2px 8px; background: #2e3b63; color: #e6dcc3; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,.5)">Skład Kruka</span>
%(nav)s
<sc-if value="{{ hasSel }}" hint-placeholder-val="{{ true }}">
<section class="paper" aria-label="Notatka zwiadu" style="position: absolute; left: {{ noteX }}; top: {{ noteY }}; width: 310px; padding: 14px 16px; transform: rotate(-1.5deg); display: flex; flex-direction: column; gap: 6px">
<span aria-hidden="true" style="position: absolute; top: -8px; left: 140px; width: 16px; height: 16px; border-radius: 50%%; background: #9b2c22; border: 2px solid #2b231c"></span>
<h2 class="typed" style="margin: 0; font-size: 20px; font-weight: 400">{{ n.name }}</h2>
<span style="font-size: 14px; color: #5a4a3a">{{ n.kind }} · {{ n.dist }}</span>
<p style="margin: 0; font-size: 15px; line-height: 1.4">{{ n.note }}</p>
<span style="font-size: 14px"><b>Zagrożenie:</b> {{ n.danger }}</span>
<span style="font-size: 14px"><b>Łup:</b> {{ n.loot }}</span>
<button class="{{ addCls }}" onClick="{{ add }}">{{ addLabel }}</button>
</section>
</sc-if>
<aside class="paper2" aria-label="Plan wyprawy" style="position: absolute; left: 24px; bottom: 24px; width: 380px; padding: 14px 18px; display: flex; flex-direction: column; gap: 6px; transform: rotate(0.6deg)">
<h2 class="typed" style="margin: 0; font-size: 20px; font-weight: 400">Plan wyprawy</h2>
<p style="margin: 0; font-size: 15px">Trasa: <b>{{ routeText }}</b></p>
<p class="num" style="margin: 0; font-size: 15px">Czas: <b>{{ days }} dni</b> · w Mgle: <b>{{ mistDays }} dni</b> · Odmienność ok. <b>+{{ odm }}</b></p>
<p class="num" style="margin: 0; font-size: 15px">Zapasy: <b>{{ food }}</b> racji, <b>{{ fuel }}</b> paliwa do lamp</p>
<div style="display: flex; gap: 8px; margin-top: 4px">
<button class="btn" onClick="{{ clear }}">Wyczyść</button>
<a class="btn" href="Walka.dc.html" style="display: inline-flex; align-items: center; text-decoration: none">Wyślij skład</a>
</div>
</aside>
</div>""" % dict(B, nav=nav("Mapa"))

mapa_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { sel: 'apteka', route: ['latarnia', 'apteka'] }; }
  renderVals() {
    const s = this.state; const N = __NODES__;
    const INFO = {
      latarnia: ['osada', '—', 'Twoja osada. Krąg światła sięga 2 kratek od wieży.', 'brak', '—', false],
      huta: ['ruiny', '1 dzień', 'Hale pełne złomu. Ślady Dawnych Żołnierzy przy suwnicy.', 'Dawni Żołnierze, Pajęczarz', 'złom, stal, plan pieca', false],
      sklad: ['węzeł kolejowy', '2 dni', 'Postój Ludzi Toru. Handlują paliwem, płacą za chitynę.', 'neutralni (Ludzie Toru)', 'handel: paliwo, amunicja', false],
      bunkier: ['bunkier', '3 dni', 'Bractwo Bunkra nie wpuszcza obcych. Patrol z karabinem maszynowym.', 'Bractwo Bunkra (wrogie)', 'broń z epoki Naboju', false],
      tama: ['tama', '3 dni', 'Republika Tamy ma prąd i reflektory. Szukają rywali dla swojej sieci światła.', 'Republika Tamy (nieufna)', 'kable, żarówki', false],
      las: ['las', '1 dzień', 'Dzieci Lasu obserwują z drzew. Zostawiły znak poroża na ścieżce.', 'Wataha, Dzieci Lasu', 'drewno, zioła', false],
      apteka: ['ruiny', '1 dzień', 'Piwnica z lekami. Ostatnio Kruk znalazł dwa plany techniczne.', 'Szabrownicy, Ogary', 'leki, plany', false],
      most: ['przeprawa', '2 dni', 'Jedyny most na Wiśle. Po stronie wschodniej Mgła sięga przyczółka.', 'Nici, Zwiewnik w nocy', '—', true],
      gniazdo: ['gniazdo', '3 dni', 'Matka Roju. Każda noc to nowa fala. Siewcy wokół.', 'Matka Roju, Siewcy, Bezokie', 'tkanka, gruczoły (Bestiariusz)', true],
      przelecz: ['przełęcz', '1 dzień', 'Droga na zachód. Karawany Gildii Solnej przechodzą raz na tydzień.', 'Łowcy Głów (zasadzki)', 'handel: sól', false],
      wies: ['wieś', '4 dni', 'Zarośnięta tkanką. Słychać śpiew Chóru Mgły.', 'Chór Mgły, Kokony', 'ocaleni (Kokony do uratowania)', true] };
    const pins = Object.keys(N).map((k) => ({ name: N[k][2], x: (N[k][0] - 22) + 'px', y: (N[k][1] - 40) + 'px',
      col: s.route.indexOf(k) >= 0 ? '#9b2c22' : (s.sel === k ? '#e0a640' : '#e6dcc3'), pick: () => this.setState({ sel: k }) }));
    const segs = [];
    for (let i = 1; i < s.route.length; i++) { const a = N[s.route[i - 1]], b = N[s.route[i]]; const dx = b[0] - a[0], dy = b[1] - a[1];
      segs.push({ x: a[0] + 'px', y: (a[1] - 2) + 'px', len: Math.hypot(dx, dy) + 'px', ang: (Math.atan2(dy, dx) * 180 / Math.PI) + 'deg' }); }
    const n = N[s.sel], I = INFO[s.sel];
    const inRoute = s.route.indexOf(s.sel) >= 0;
    const d = s.route.slice(1).reduce((t, k) => t + (parseInt(INFO[k][1]) || 0), 0);
    const md = s.route.filter((k) => INFO[k][5]).length * 2;
    const last = N[s.route[s.route.length - 1]];
    return { pins, segs, hasSel: true, n: { name: n[2], kind: I[0], dist: 'od osady: ' + I[1], note: I[2], danger: I[3], loot: I[4] },
      noteX: Math.min(n[0] + 30, 1250) + 'px', noteY: Math.min(Math.max(n[1] - 40, 70), 560) + 'px',
      addLabel: inRoute ? 'Usuń z trasy' : 'Dodaj do trasy', addCls: inRoute ? 'btn on' : 'btn',
      add: () => { if (s.sel === 'latarnia') return; this.setState({ route: inRoute ? s.route.filter((k) => k !== s.sel) : s.route.concat([s.sel]) }); },
      clear: () => this.setState({ route: ['latarnia'] }),
      routeText: s.route.map((k) => N[k][2]).join(' → '), days: d * 2, mistDays: md, odm: md * 6, food: d * 2 * 6, fuel: md * 3 + d,
      pawnX: (last[0] + 14) + 'px', pawnY: (last[1] + 14) + 'px' };
  }
}
""".replace("__NODES__", json.dumps(NODES, ensure_ascii=False))
write("Mapa.dc.html", page("Mapa świata", mapa_body, mapa_js))
print("mapa ok")

# =====================================================================================  RATUSZ
ratusz_body = """<div style="position: relative; width: 1600px; height: 900px; overflow: hidden; background: #2a2219; font-family: 'IBM Plex Sans Condensed', sans-serif">
<div aria-hidden="true" style="position: absolute; inset: 0; background: repeating-linear-gradient(90deg, #2e251b 0 3px, #2a2219 3px 9px)"></div>
%(nav)s
<section class="paper" aria-label="Kurs ustroju" style="position: absolute; top: 70px; left: 30px; width: 560px; height: 420px; padding: 22px 28px; transform: rotate(-0.8deg); display: flex; flex-direction: column; gap: 14px">
<div style="display: flex; justify-content: space-between; align-items: baseline">
<h2 class="typed" style="margin: 0; font-size: 24px; font-weight: 400">Kurs osady</h2>
<span class="stamp" style="font-size: 18px">{{ regime }}</span>
</div>
<sc-for list="{{ axes }}" as="x" hint-placeholder-count="3">
<div>
<div style="display: flex; justify-content: space-between; font-size: 15px"><span>{{ x.a }}</span><b class="typed" style="font-weight: 400">{{ x.n }}</b><span>{{ x.b }}</span></div>
<div style="position: relative; height: 26px; margin-top: 4px; background: repeating-linear-gradient(90deg, #cbbd98 0 2px, transparent 2px 10%%); border: 2px solid #2b231c">
<span aria-hidden="true" style="position: absolute; left: 50%%; top: 0; bottom: 0; width: 2px; background: #8a7a62"></span>
<span aria-hidden="true" style="position: absolute; left: {{ x.pv }}; top: 2px; width: 14px; height: 18px; margin-left: -7px; background: transparent; border: 2px dashed #9b2c22; display: {{ x.pvd }}"></span>
<span aria-hidden="true" style="position: absolute; left: {{ x.pos }}; top: 2px; width: 14px; height: 18px; margin-left: -7px; background: #2b231c"></span>
</div>
<span class="num" style="font-size: 13px; color: #5a4a3a">{{ x.val }} {{ x.delta }}</span>
</div>
</sc-for>
<div style="display: flex; align-items: center; gap: 12px; font-size: 15px">Legitymacja <span style="flex: 1; height: 12px; background: #cbbd98; border: 1px solid #2b231c"><span style="display: block; height: 10px; width: {{ legW }}; background: #2e3b63"></span></span><b class="num">{{ leg }}</b></div>
</section>
<section class="paper2" aria-label="Dekrety" style="position: absolute; top: 80px; left: 620px; width: 560px; height: 796px; padding: 20px 24px; transform: rotate(0.5deg); display: flex; flex-direction: column; gap: 10px">
<h2 class="typed" style="margin: 0; font-size: 24px; font-weight: 400">Dekrety</h2>
<div style="display: flex; gap: 6px; flex-wrap: wrap">
<sc-for list="{{ cats }}" as="c" hint-placeholder-count="5"><button class="{{ c.cls }}" onClick="{{ c.pick }}">{{ c.name }}</button></sc-for>
</div>
<div style="display: flex; flex-direction: column; gap: 8px">
<sc-for list="{{ laws }}" as="l" hint-placeholder-count="5">
<button onClick="{{ l.pick }}" style="display: flex; justify-content: space-between; gap: 12px; align-items: center; text-align: left; min-height: 56px; padding: 8px 14px; border: 2px solid {{ l.border }}; background: {{ l.bg }}; cursor: pointer; border-radius: 3px; font-family: inherit; color: #2b231c">
<span><span class="typed" style="font-size: 17px">{{ l.name }}</span><br><span style="font-size: 14px">{{ l.eff }}</span></span>
<span class="num" style="font-size: 14px; white-space: nowrap; font-weight: 700">{{ l.ax }}{{ l.on }}</span>
</button>
</sc-for>
</div>
<div class="paper" style="margin-top: auto; padding: 14px 18px; display: flex; justify-content: space-between; align-items: center; gap: 12px">
<span style="font-size: 15px">{{ pendingText }}</span>
<button class="btn" onClick="{{ sign }}" style="border-color: #9b2c22; color: #9b2c22; white-space: nowrap">{{ signLabel }}</button>
</div>
</section>
<aside aria-label="Listy od frakcji" style="position: absolute; top: 80px; left: 1210px; width: 370px; display: flex; flex-direction: column; gap: 14px">
<h2 class="typed" style="margin: 0; color: #e6dcc3; font-size: 20px; font-weight: 400">Listy i depesze</h2>
<sc-for list="{{ letters }}" as="m" hint-placeholder-count="3">
<div class="paper" style="padding: 12px 14px; transform: rotate({{ m.rot }})">
<button onClick="{{ m.toggle }}" style="all: unset; cursor: pointer; display: flex; gap: 12px; align-items: center; width: 100%%; min-height: 48px">
<img src="{{ m.emb }}" alt="" style="width: 48px; height: 48px; image-rendering: pixelated">
<span><span class="typed" style="font-size: 17px">{{ m.from }}</span><br><span style="font-size: 14px; color: #5a4a3a">{{ m.sub }}</span></span>
</button>
<sc-if value="{{ m.open }}" hint-placeholder-val="{{ false }}">
<p style="margin: 10px 0 8px; font-size: 15px; line-height: 1.45">{{ m.text }}</p>
<div style="display: flex; gap: 8px"><button class="btn">{{ m.yes }}</button><button class="btn">{{ m.no }}</button></div>
</sc-if>
</div>
</sc-for>
</aside>
</div>""" % dict(B, nav=nav("Ratusz"))

ratusz_js = r"""
class Component extends DCLogic {
  constructor(p) { super(p); this.state = { cat: 'Praca', sel: null, enacted: { 'Sądy': true, 'Równe racje': true, 'Sztandar osady': true }, ax: [-15, 20, -10], leg: 61, open: 0 }; }
  renderVals() {
    const s = this.state;
    const L = { 'Praca': [['Zmiany 12-godzinne', [5, 0, 0], 'produkcja +20%, morale −10, więcej wypadków'], ['Przymus pracy', [10, -5, 0], 'bezczynni i więźniowie pracują, morale −10'], ['Dzieci w szkołach', [-5, 0, 0], 'umiejętności dzieci +50%, mniej rąk teraz'], ['Spółdzielnie', [0, -10, 0], 'produkcja równa, morale +5'], ['Własność warsztatów', [0, 15, 0], 'produkcja +15%, nierówności rosną']],
      'Prawo i kara': [['Sądy', [-10, 0, 0], 'przestępczość −20%, kary łagodne'], ['Praca karna', [5, 0, 0], 'skazani pracują bez płacy'], ['Wygnanie w Mgłę', [10, 0, 0], 'przestępczość −30%, wygnani wracają jako Dezerterzy'], ['Egzekucje publiczne', [20, 0, 0], 'przestępczość −50%, morale −10 na stałe']],
      'Żywność': [['Równe racje', [0, -10, 0], 'morale +5, brak premii dla wojowników'], ['Racje za pracę', [0, 10, 0], 'produkcja +10%, słabsi głodują'], ['Podwójne racje dla wojowników', [5, 0, 0], 'morale wojowników +10, cywilów −5'], ['Prawo do łupu', [0, 15, 0], 'wojownicy zatrzymują 20% łupu']],
      'Mutanci': [['Rejestr zmutowanych', [0, 0, -10], 'Odmienność każdego widoczna'], ['Getto', [0, 0, -20], 'zmutowani osobno, ich morale −20'], ['Równouprawnienie', [0, 0, 15], 'morale zmutowanych +15, Czyści przeciw'], ['Badania na zmutowanych', [0, 0, -5], 'badania Mgły +30%, morale zmutowanych −15']],
      'Wiara': [['Sztandar osady', [5, 0, 0], 'sztandary, morale +5 w składach ze sztandarem'], ['Święto Światła', [-5, 0, 0], 'raz na porę roku morale +15, kosztuje paliwo'], ['Wolność słowa', [-10, 0, 0], 'Legitymacja +5, frakcje rosną szybciej'], ['Cenzura', [10, 0, 0], 'frakcje rosną wolniej'], ['Kult Latarni', [10, 0, -10], 'odporność na Echo i Krzykacza']] };
    const all = {}; Object.values(L).forEach((arr) => arr.forEach((l) => { all[l[0]] = l; }));
    const cats = Object.keys(L).map((c) => ({ name: c, cls: s.cat === c ? 'btn on' : 'btn', pick: () => this.setState({ cat: c, sel: null }) }));
    const fmt = (d) => ['W', 'Ł', 'M'].map((k, i) => d[i] ? k + ' ' + (d[i] > 0 ? '+' : '−') + Math.abs(d[i]) : '').filter(Boolean).join(', ');
    const laws = L[s.cat].map(([n, d, e]) => ({ name: n, eff: e, ax: fmt(d), on: s.enacted[n] ? ' · obowiązuje' : '', border: s.sel === n ? '#9b2c22' : '#8a7a62', bg: s.sel === n ? '#f2ead6' : (s.enacted[n] ? 'rgba(46,59,99,.12)' : 'transparent'), pick: () => this.setState({ sel: n }) }));
    const sel = s.sel ? all[s.sel] : null; const on = sel && s.enacted[sel[0]];
    const delta = sel ? sel[1].map((v) => on ? -v : v) : [0, 0, 0];
    const N = [['Władza', 'Wspólnota', 'Wódz'], ['Własność', 'Kolektyw', 'Prywatne'], ['Mgła', 'Czystość', 'Przemiana']];
    const pct = (v) => (50 + v / 2) + '%';
    const axes = N.map(([n, a, b], i) => ({ n, a, b, pos: pct(s.ax[i]), pv: pct(s.ax[i] + delta[i]), pvd: delta[i] ? 'block' : 'none', val: (s.ax[i] > 0 ? '+' : '') + s.ax[i], delta: delta[i] ? '→ ' + (s.ax[i] + delta[i]) : '' }));
    const [w, l, m] = s.ax;
    const regime = w < 0 ? (l < 0 ? 'KOMUNA' : 'RADA') : (m > 20 ? (l > 0 ? 'WOLNE MIASTO' : 'KOŚCIÓŁ MGŁY') : (m < -20 ? 'JUNTA' : (l < 0 ? 'REŻIM LATARNIKA' : 'RADA')));
    const LT = [['Zakon Latarników', 'Propozycja wymiany', '%(zakon)s', 'Zakon proponuje 40 paliwa za plany z Apteki. Mówią, że „światło należy do tych, którzy je rozumieją”.', 'Przyjmij', 'Odmów', '1deg'],
      ['Szabrownicy', 'Żądanie haraczu', '%(szab)s', 'Herszt żąda 100 racji do końca tygodnia. Inaczej „karawana nie dojdzie”.', 'Zapłać', 'Przygotuj obronę', '-1.2deg'],
      ['Ludzie Toru', 'Skład przyjedzie za 3 dni', '%(tor)s', 'Pociąg zatrzyma się na Składzie kolejowym. Kupią chitynę, sprzedadzą amunicję i najemników.', 'Wyślij karawanę', 'Zignoruj', '0.6deg']];
    const letters = LT.map(([f, sub, emb, t, y, n, rot], i) => ({ from: f, sub, emb, text: t, yes: y, no: n, rot, open: s.open === i, toggle: () => this.setState({ open: s.open === i ? -1 : i }) }));
    return { axes, regime, leg: s.leg, legW: s.leg + '%', cats, laws, letters,
      pendingText: sel ? (on ? 'Uchylenie: ' + sel[0] + ' · Legitymacja −3' : 'Nowy dekret: ' + sel[0] + ' · Legitymacja −2, wchodzi jutro') : 'Wybierz dekret, by zobaczyć przesunięcie kursu.',
      signLabel: sel ? (on ? 'Uchyl' : 'Podpisz i opieczętuj') : 'Podpisz',
      sign: () => { if (!sel) return; const e = Object.assign({}, s.enacted); e[sel[0]] = !on; this.setState({ enacted: e, ax: s.ax.map((v, i) => Math.max(-100, Math.min(100, v + delta[i]))), leg: s.leg - (on ? 3 : 2), sel: null }); } };
  }
}
""".replace("%(zakon)s", B["zakon"]).replace("%(szab)s", B["szab"]).replace("%(tor)s", B["tor"])
write("Ratusz.dc.html", page("Ratusz", ratusz_body, ratusz_js))
print("ratusz ok")
