import random, math, json
from PIL import Image, ImageDraw, ImageFilter, ImageFont
W, H = 1600, 900; R = random.Random(4)
im = Image.new("RGB", (W, H), (218, 204, 170))
px = im.load()
noise = Image.effect_noise((W // 4, H // 4), 40).resize((W, H), Image.BICUBIC)
im = Image.blend(im, Image.merge("RGB", [noise] * 3).point(lambda v: v * 0.9 + 20), 0.12)
d = ImageDraw.Draw(im, "RGBA")
INK = (58, 46, 36, 255); INK2 = (58, 46, 36, 150); RED = (150, 40, 32, 255)
# plamy i zagiecia
for _ in range(14):
    x, y, r = R.randint(0, W), R.randint(0, H), R.randint(30, 120)
    d.ellipse((x - r, y - r, x + r, y + r), fill=(150, 120, 80, 18))
d.line((W // 2, 0, W // 2, H), fill=(170, 150, 115, 90), width=3); d.line((0, H // 2, W, H // 2), fill=(170, 150, 115, 90), width=3)
NODES = {"latarnia": (520, 470, "Latarnia (osada)"), "huta": (760, 360, "Ruiny Huty"), "sklad": (990, 520, "Skład kolejowy"),
         "bunkier": (1180, 290, "Bunkier 7"), "tama": (1330, 610, "Tama"), "las": (310, 240, "Las Graniczny"), "apteka": (640, 660, "Stara Apteka"),
         "most": (870, 700, "Most na Wiśle"), "gniazdo": (1110, 790, "Gniazdo"), "przelecz": (240, 650, "Przełęcz"), "wies": (1420, 170, "Wieś Zarośnięta")}
EDGES = [("latarnia", "huta"), ("latarnia", "apteka"), ("latarnia", "las"), ("latarnia", "przelecz"), ("huta", "sklad"), ("huta", "bunkier"), ("sklad", "tama"),
         ("sklad", "most"), ("most", "apteka"), ("most", "gniazdo"), ("bunkier", "wies"), ("tama", "gniazdo")]
# Mgla: kreskowane plamy
mist = Image.new("L", (W, H), 0); md = ImageDraw.Draw(mist)
for cx, cy, rr in ((1250, 820, 330), (1450, 150, 230), (1050, 900, 260), (1600, 450, 200), (150, 880, 160)):
    md.ellipse((cx - rr, cy - rr * 0.8, cx + rr, cy + rr * 0.8), fill=255)
mist = mist.filter(ImageFilter.GaussianBlur(30)).point(lambda v: 255 if v > 120 else 0)
hatch = Image.new("RGBA", (W, H), (0, 0, 0, 0)); hd = ImageDraw.Draw(hatch)
for k in range(-H, W, 9): hd.line((k, 0, k + H, H), fill=(80, 84, 104, 120), width=1)
im.paste(hatch, (0, 0), Image.composite(hatch, Image.new("RGBA", (W, H)), mist).split()[3])
edge = mist.filter(ImageFilter.FIND_EDGES); im.paste((70, 72, 96), (0, 0), edge)
d = ImageDraw.Draw(im, "RGBA")
# rzeka
pts = [(700, 0), (760, 140), (830, 300), (850, 470), (880, 640), (870, 760), (920, 900)]
d.line(pts, fill=(70, 96, 120, 200), width=7, joint="curve"); d.line(pts, fill=(140, 170, 190, 160), width=3, joint="curve")
# las: znaczki drzew
for _ in range(220):
    x, y = R.gauss(300, 110), R.gauss(260, 90)
    if 0 < x < W and 0 < y < H:
        d.line((x, y, x, y + 7), fill=INK2, width=1); d.polygon([(x - 4, y + 3), (x + 4, y + 3), (x, y - 7)], outline=INK2)
# krag swiatla latarni
lx, ly = NODES["latarnia"][:2]
for r_, a in ((150, 70), (148, 70)): d.ellipse((lx - r_, ly - r_, lx + r_, ly + r_), outline=(200, 140, 40, a), width=2)
for k in range(0, 360, 6):
    a = math.radians(k); d.line((lx + 150 * math.cos(a), ly + 150 * math.sin(a), lx + 158 * math.cos(a), ly + 158 * math.sin(a)), fill=(200, 140, 40, 130), width=2)
# drogi: przerywane
for a, b in EDGES:
    (x0, y0, _), (x1, y1, _) = NODES[a], NODES[b]
    n = int(math.hypot(x1 - x0, y1 - y0) / 14)
    for i in range(n):
        if i % 2: continue
        t0, t1 = i / n, (i + 1) / n
        w = 4 * math.sin(i * 0.7)
        d.line((x0 + (x1 - x0) * t0, y0 + (y1 - y0) * t0 + w, x0 + (x1 - x0) * t1, y0 + (y1 - y0) * t1 + w), fill=INK, width=2)
# wezly
F = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf", 19)
FB = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSerif-BoldItalic.ttf", 34)
for k, (x, y, name) in NODES.items():
    d.ellipse((x - 9, y - 9, x + 9, y + 9), outline=INK, width=3, fill=(218, 204, 170, 255))
    d.text((x + 16, y - 26), name, font=F, fill=INK)
d.text((40, 30), "Dorzecze — szkic zwiadu", font=FB, fill=INK)
d.text((40, 74), "kreskowanie = Mgła (stan z 14 dnia)", font=F, fill=INK2)
# roza wiatrow
cx, cy = 1490, 760
for a, l in ((0, 50), (90, 30), (180, 30), (270, 30)):
    r = math.radians(a - 90); d.polygon([(cx, cy), (cx + l * math.cos(r) + 6 * math.sin(r), cy + l * math.sin(r) - 6 * math.cos(r)), (cx + l * math.cos(r), cy + l * math.sin(r))], fill=INK)
d.text((cx - 7, cy - 82), "N", font=F, fill=INK)
im = im.filter(ImageFilter.SMOOTH)
im.save("mapa.png")
json.dump({k: [x, y, n] for k, (x, y, n) in NODES.items()}, open("mapa_nodes.json", "w"), ensure_ascii=False)
