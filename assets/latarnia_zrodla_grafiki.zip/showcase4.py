"""Pokaz: bron reczna, sztandar i zycie osady. python3 showcase4.py -- F0 F1 SAMPLES [big]"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A, anim2 as A2, weapons as WP

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
F0, F1, SAMP = (int(args[0]), int(args[1]), int(args[2])) if args else (0, 24, 20)
reset(); setup_render(samples=SAMP)
world((34, 30, 52), 0.30)
ground = mat("ground", (58, 54, 62), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
    (0.0, (56, 53, 60)), (0.45, (60, 57, 64)), (0.66, (64, 60, 64)), (0.82, (58, 60, 56))]))
box("ground", (0, 0, -0.05), (50, 30, 0.1), ground, pass_index=1)
CAMYAW = -25; YAW = CAMYAW - 18
cy = math.radians(CAMYAW); yw = math.radians(YAW)
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0)); DIR = V((math.cos(yw), math.sin(yw), 0))
def cell(ci, ri, n=5): return RIGHT * ((ci - (n - 1) / 2) * (2.8 if n == 5 else 2.5)) + FWD * (1.9 if ri == 0 else -1.9)
cells, hooks = [], []
def handpos(rig, b): bb = rig.ob.data.bones[b]; return V(bb.tail_local)
def prop(rig, objs, bone, rot=(0, 0, 0), off=(0, 0, 0), key=None, scale=1.0):
    p = handpos(rig, bone) + V(off)
    WP.place(objs, p, rot, scale)
    for o in objs: rig.attach(o, bone)
    if key: rig.objs[key] = objs[0] if len(objs) == 1 else objs[0]
    return objs
def wpt(obj, rest): return obj.matrix_world @ V(rest)
FL = M("flashm", (255, 240, 190), emit=(255, 230, 170), strength=14)

# 1 rewolwer
r = human("rew", dict(jacket="leather", pants="darkgrey", hair="hair_l"), "idle"); r.objs = {}
pp = prop(r, WP.pistolet(), "hand.R", rot=(0, math.pi / 2, 0), off=(0.02, 0, 0.02))
hp = handpos(r, "hand.R") + V((0.02, 0, 0.02))
fl = ellipsoid("pflash", hp + V((0.035, 0, -0.30)), (0.05, 0.04, 0.04), FL); r.attach(fl, "hand.R"); fl.hide_render = True; r.objs["pflash"] = fl
cells.append((r, A2.clip_pistol().sample, cell(0, 0), YAW))
# 2 noz
r = human("noz", dict(jacket="grey", pants="brown", beard=True), "idle"); r.objs = {}
prop(r, WP.noz(), "hand.R", rot=(0, math.pi / 2, 0), off=(0.02, 0, 0.03))
cells.append((r, A2.clip_knife().sample, cell(1, 0), YAW))
# 3 luk z dynamiczna cieciwa
rb = human("luk", dict(jacket="olive", pants="brown", hair="hair_l"), "bow")
for k in ("_str1", "_str2", "_arrow"): bpy.data.objects["luk" + k].hide_render = True
STR = M("string", (200, 200, 190))
s1 = cyl("dstr1", (0, 0, 0), (0, 0, 1), 0.004, STR, seg=4); s2 = cyl("dstr2", (0, 0, 0), (0, 0, 1), 0.004, STR, seg=4)
ad = cyl("darrow", (0, 0, 0), (0, 0, 1), 0.006, WOOD(), seg=4); af = cyl("farrow", (0, 0, 0), (0, 0, 1), 0.006, WOOD(), seg=4)
rb.objs["arrow_d"] = ad
for o in (s1, s2, ad, af): o.pass_index = 3; char_collection().objects.link(o)
bowob = bpy.data.objects["luk_bow"]
TOP = V((0.50 - 0.10 * (1 - math.cos(1.25)), 0.03, 1.40 + 0.5 * math.sin(1.25))); BOT = V((TOP.x, 0.03, 1.40 - 0.5 * math.sin(1.25))); GRIP = V((0.49, 0.03, 1.40))
def seg_to(o, a, b):
    d = b - a; L = d.length
    o.location = a; o.rotation_euler = d.to_track_quat("Z", "Y").to_euler(); o.scale = (1, 1, max(L, 1e-3))
def bow_hook(f):
    bpy.context.view_layer.update()
    t, b, g = wpt(bowob, TOP), wpt(bowob, BOT), wpt(bowob, GRIP)
    hand = rb.ob.matrix_world @ rb.ob.pose.bones["hand.R"].head
    pull = (f % 24) >= 6 and (f % 24) <= 16
    mid = hand if pull else (t + b) / 2
    seg_to(s1, t, mid); seg_to(s2, mid, b)
    seg_to(ad, hand, hand + (g - hand).normalized() * 0.78)
    tf = (f % 24) - 16
    af.hide_render = not (1 <= tf <= 4)
    if 1 <= tf <= 4:
        d = (g - hand).normalized(); st = g + d * (0.9 * tf); seg_to(af, st, st + d * 0.78)
hooks.append(bow_hook)
cells.append((rb, A2.clip_bow().sample, cell(2, 0), YAW))
# 4 sztandar
rbn = human("szt", dict(jacket="blue", pants="blue", helmet="mil"), "banner")
cells.append((rbn, A2.banner_walk, cell(3, 0), YAW))
# 5 wartownik
rw = human("wart", dict(jacket="olive", pants="olive", helmet="mil", armor="vest"), "rifle")
cells.append((rw, lambda f: A.merge(A2.idle_look(f), A.low_ready()), cell(4, 0), YAW))
# rzad 2: zycie osady (6 kolumn)
# kowal
rk = human("kowal", dict(jacket="brown", pants="darkgrey", beard=True, strap=False), "idle"); rk.objs = {}
prop(rk, WP.mlot(), "hand.R", rot=(0, 0, math.pi), off=(0.0, 0, 0.0), scale=0.42)
prop(rk, [cyl("tongs", (0, 0, 0), (0.45, 0, 0), 0.012, METAL_D(), seg=4)], "hand.L", off=(0.0, 0, 0))
c0 = cell(0, 1, 6); ap = c0 + DIR * 0.62
cyl("anvil_s", (ap.x, ap.y, 0), (ap.x, ap.y, 0.5), 0.17, WOOD(), seg=8); box("anvil", (ap.x, ap.y, 0.6), (0.48, 0.18, 0.18), METAL_D(), rot=(0, 0, yw))
box("hot", (ap.x, ap.y, 0.71), (0.18, 0.05, 0.03), M("hotiron", (255, 150, 60), emit=(255, 120, 40), strength=8), rot=(0, 0, yw))
sp = ellipsoid("spark_s", (ap.x, ap.y, 0.78), (0.12, 0.12, 0.08), M("spark", (255, 210, 140), emit=(255, 190, 110), strength=10)); sp.hide_render = True; rk.objs["spark"] = sp
point_light("forge", (ap.x - 0.6, ap.y + 0.4, 0.9), (1.0, 0.5, 0.2), 25, radius=0.1)
cells.append((rk, A2.clip_smith().sample, tuple(c0), YAW))
# noszenie skrzyni
rc = human("nos", dict(jacket="grey", pants="brown", strap=False), "idle"); rc.objs = {}
crate = box("crate_c", (0.40, 0, 1.0), (0.42, 0.5, 0.36), WOOD()); rc.attach(crate, "chest")
cells.append((rc, A2.carry, tuple(cell(1, 1, 6)), YAW))
# kopanie
rd = human("kop", dict(jacket="olive", pants="brown", strap=False), "idle"); rd.objs = {}
shv = [cyl("shaft", (0, 0, 0), (0, 0, -1.05), 0.018, WOOD(), seg=6), box("blade", (0, 0, -1.15), (0.04, 0.22, 0.26), METAL_D())]
prop(rd, shv, "hand.R", off=(0.02, 0, 0.0))
c2 = cell(2, 1, 6); dp = c2 + DIR * 0.9
ellipsoid("dirtpile", (dp.x + 0.3, dp.y + 0.3, 0.0), (0.4, 0.35, 0.2), M("soil", (70, 56, 44)))
dl = ellipsoid("dirtclod", (dp.x - 0.1, dp.y - 0.4, 0.9), (0.1, 0.1, 0.07), M("soil", (70, 56, 44))); dl.hide_render = True; rd.objs["dirt"] = dl
cells.append((rd, A2.clip_dig().sample, tuple(c2), YAW))
# gotowanie
rs = human("kuch", dict(jacket="teal", pants="brown", strap=False, hair="hair_l"), "idle"); rs.objs = {}
prop(rs, [cyl("ladle", (0, 0, 0), (0, 0, -0.75), 0.012, WOOD(), seg=4)], "hand.R", off=(0.02, 0, 0))
c3 = cell(3, 1, 6); kp = c3 + DIR * 0.75
cyl("pot", (kp.x, kp.y, 0.25), (kp.x, kp.y, 0.65), 0.28, METAL_D(), seg=12); cyl("soup", (kp.x, kp.y, 0.63), (kp.x, kp.y, 0.65), 0.25, M("soup", (150, 110, 60)), seg=12)
for k in range(3): cyl("potleg%d" % k, (kp.x + 0.3 * math.cos(k * 2.1), kp.y + 0.3 * math.sin(k * 2.1), 0), (kp.x, kp.y, 1.0), 0.02, WOOD(), seg=4)
ellipsoid("potfire", (kp.x, kp.y, 0.1), (0.2, 0.2, 0.12), M("fire", (255, 150, 50), emit=(255, 120, 30), strength=4))
point_light("potf", (kp.x, kp.y, 0.3), (1.0, 0.55, 0.25), 30, radius=0.1)
cells.append((rs, A2.stir, tuple(c3), YAW))
# klotnia
c4 = cell(4, 1, 6)
ra = human("klA", dict(jacket="brown", pants="darkgrey", beard=True, strap=False), "idle")
rb2 = human("klB", dict(jacket="blue", pants="brown", strap=False), "idle")
cells.append((ra, A2.argue_a, tuple(c4 - DIR * 0.45), YAW)); cells.append((rb2, A2.argue_b, tuple(c4 + DIR * 0.45), YAW + 180))
# ognisko
c5 = cell(5, 1, 6)
rf = human("ogn", dict(jacket="leather", pants="brown", strap=False), "idle")
lg = c5 - DIR * 0.05
cyl("log", (lg.x - 0.4 * DIR.y, lg.y + 0.4 * DIR.x, 0.2), (lg.x + 0.4 * DIR.y, lg.y - 0.4 * DIR.x, 0.2), 0.17, WOOD(), seg=8)
fp = c5 + DIR * 0.85
for k in range(6): cyl("fst%d" % k, (fp.x + 0.25 * math.cos(k), fp.y + 0.25 * math.sin(k), 0.03), (fp.x + 0.25 * math.cos(k), fp.y + 0.25 * math.sin(k), 0.1), 0.07, M("stones", (90, 88, 92)), seg=6)
fire = ellipsoid("campfire", (fp.x, fp.y, 0.14), (0.11, 0.11, 0.16), M("fire", (255, 150, 50), emit=(255, 120, 30), strength=4))
fl2 = point_light("campf", (fp.x, fp.y, 0.45), (1.0, 0.55, 0.25), 50, radius=0.1)
def fire_hook(f):
    k = 1 + 0.18 * math.sin(f * 2.3) + 0.1 * math.sin(f * 5.1)
    fire.scale = (1, 1, k); fl2.data.energy = 50 * k
hooks.append(fire_hook)
cells.append((rf, A2.sit_fire, tuple(c5), YAW))

for i, cc in enumerate((-4.2, 0.0, 4.2)):
    p = RIGHT * cc
    point_light("lamp%d" % i, (p.x, p.y, 3.4), (1.0, 0.72, 0.42), 160, radius=0.1)
sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.84, 0.64), 2.6)
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.70, 0.76, 1.0), 1.2)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
RES = (1280, 640) if len(args) > 3 else (640, 320)
camera((0, 0, 0.7), 50, 17.0, RES, yaw_deg=CAMYAW)
FR = [int(x) for x in os.environ['FRAMES'].split(',')] if 'FRAMES' in os.environ else range(F0, F1)
for f in FR:
    for rig, fn, loc, yaw in cells: A.apply(rig, fn(f), loc, yaw)
    for h in hooks: h(f)
    render("/home/claude/latarnia3d/out/%s_%02d.exr" % ("life" if len(args) < 4 else "ldbg", f))
