import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import human
import anim as A
P = {"mroz": dict(jacket="olive", pants="olive", helmet="mil", armor="vest", beard=True),
     "wrona": dict(jacket="f_oliveb" if False else "brown", pants="darkgrey", hair="hair_l"),
     "sitko": dict(jacket="leather", pants="brown", helmet="pot", armor="plate"),
     "kruk": dict(jacket="teal", pants="darkgrey", mask="gas")}
key = sys.argv[sys.argv.index("--") + 1]
reset(); setup_render(samples=24)
world((70, 62, 60), 0.6)
r = human("p", P[key], "rifle" if key != "sitko" else "spear")
A.apply(r, A.merge(A.stance(), A.low_ready() if key != "sitko" else A.P(), A.P(rot={"head": (0, 4, 6)})), (0, 0, 0), -28)
sun("key", (math.radians(50), 0, math.radians(-30)), (1.0, 0.86, 0.68), 3.2)
fill = sun("fill", (math.radians(60), 0, math.radians(160)), (0.7, 0.78, 1.0), 1.2)
rim = sun("rim", (math.radians(-70), 0, math.radians(20)), (0.6, 0.8, 1.0), 3.0)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
camera(V((0.0, 0.0, 1.42)), 80, 1.15, (152, 190), yaw_deg=50)
render("/home/claude/latarnia3d/out/portrait_%s.exr" % key)
