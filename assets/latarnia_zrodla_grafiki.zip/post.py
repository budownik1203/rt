"""Obrobka renderu 3D na pixel art: pasma swiatla, przesuniecie barwy cieni, obrys z glebi, Mgla, paleta."""
import numpy as np, OpenEXR
from PIL import Image

PAL = {
    "k0": "#0d0b13", "k1": "#17141f", "k2": "#24202f", "k3": "#363246", "k4": "#524e66", "k5": "#827f98", "k6": "#bdbacb",
    "f1": "#223236", "f2": "#3a5452", "f3": "#68857c", "f4": "#9fb3a3",
    "v0": "#1f1628", "v1": "#33243f", "v2": "#54406a", "v3": "#7c6390",
    "w0": "#2a1b14", "w1": "#46301f", "w2": "#6a4a2c", "w3": "#97693a", "w4": "#c69448", "w5": "#e6c068", "w6": "#f5e4a6",
    "r0": "#4a2026", "r1": "#7b3320", "r2": "#ac532a", "r3": "#d3814a", "c1": "#8d1a22", "c2": "#ce392f",
    "g0": "#20271f", "g1": "#323e28", "g2": "#54613a", "g3": "#868b4f",
    "o0": "#262a22", "o1": "#3b4229", "o2": "#5a633f", "o3": "#838b5a", "o4": "#aab079",
    "s0": "#5c3a3c", "s1": "#94664e", "s2": "#c99473", "s3": "#ecc49d",
    "b0": "#1d2232", "b1": "#343d55", "b2": "#4f5c7a", "b3": "#7a88a8",
    "x1": "#2c2a33", "x2": "#45424f", "x3": "#605b66", "x4": "#3e3228", "x5": "#5a4a3a",
}
def hx(h): return tuple(int(h.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4))
PAL_ARR = np.array([hx(v) for v in PAL.values()], np.float32)
BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], np.float32) / 16 - 0.5

def read_exr(path):
    f = OpenEXR.File(path)
    out = {}
    for part in f.parts:
        for cname, ch in part.channels.items():
            key = cname.replace("ViewLayer.", "")
            out[key] = np.array(ch.pixels, np.float32)
    return out

def quantize(rgb, dither_mask=None, amount=10.0):
    img = rgb.astype(np.float32).copy()
    if dither_mask is not None:
        h, w = img.shape[:2]
        t = np.tile(BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w]
        img += (t * amount * dither_mask)[..., None]
    flat = img.reshape(-1, 3)
    # dopasowanie w przestrzeni z waga percepcyjna
    wgt = np.array([0.30, 0.59, 0.11], np.float32) * 3
    d = (((flat[:, None, :] - PAL_ARR[None]) ** 2) * wgt).sum(-1)
    return PAL_ARR[d.argmin(1)].reshape(img.shape).astype(np.uint8)

def value_noise(w, h, scale, seed, ox=0.0, oy=0.0):
    r = np.random.default_rng(seed); g = r.random((h // scale + 6, w // scale + 6))
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32); yy = (yy + oy) / scale; xx = (xx + ox) / scale
    x0, y0 = xx.astype(int), yy.astype(int); fx, fy = xx - x0, yy - y0
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy)
    x0 %= g.shape[1] - 1; y0 %= g.shape[0] - 1
    return (g[y0, x0] * (1 - fx) + g[y0, x0 + 1] * fx) * (1 - fy) + (g[y0 + 1, x0] * (1 - fx) + g[y0 + 1, x0 + 1] * fx) * fy

def stylize(path, fog=None, t=0):
    P = read_exr(path)
    comb = P["Combined"][..., :3]; diff = P["Diffuse Color"][..., :3]; emit = P["Emission"][..., :3]
    depth = P["Depth.Z"]; idx = P["Object Index.X"]
    if depth.ndim == 3: depth = depth[..., 0]
    if idx.ndim == 3: idx = idx[..., 0]
    H, W = depth.shape
    lum = lambda c: 0.2126 * c[..., 0] + 0.7152 * c[..., 1] + 0.0722 * c[..., 2]
    light = (comb - emit) / np.maximum(diff, 0.02)
    L = lum(light)
    # pasma swiatla (cel shading)
    th = np.array([0.04, 0.12, 0.30, 0.62])
    vals = np.array([0.06, 0.16, 0.36, 0.66, 1.0])
    band = vals[np.digitize(L, th)]
    chroma = np.clip(light / np.maximum(L, 1e-4)[..., None], 0, 2.5)
    tint = 0.5 + 0.5 * chroma
    lin = diff * band[..., None] * tint
    # cienie w chlodny fiolet, swiatla lekko cieplejsze
    cool = np.array([0.020, 0.014, 0.040], np.float32)
    s = np.clip(1 - band / 0.66, 0, 1)[..., None]
    lin = lin * (1 - 0.35 * s) + cool * s * 1.2
    srgb = np.clip(lin, 0, 1) ** (1 / 2.2) * 255
    # emisja
    E = lum(emit)
    em = E > 0.25
    srgb[em] = np.clip(emit[em], 0, 1) ** (1 / 2.2) * 255
    # obrys z glebi: piksel obiektu, ktorego sasiad jest wyraznie dalej
    D = np.where(depth > 1e4, 1e4, depth)
    Pd = np.pad(D, 1, mode="edge")
    neigh = [Pd[:-2, 1:-1], Pd[2:, 1:-1], Pd[1:-1, :-2], Pd[1:-1, 2:]]   # gora, dol, lewo, prawo
    thr = np.where(idx >= 3, 0.07, 0.22)
    edge_any = np.zeros((H, W), bool); edge_lit = np.zeros((H, W), bool)
    for k, nd in enumerate(neigh):
        e = (nd - D) > thr
        edge_any |= e
        if k in (0, 2): edge_lit |= e
    edge = edge_any & (idx >= 2) & ~em
    dark = np.clip(lin * 0.30 + cool * 0.6, 0, 1) ** (1 / 2.2) * 255
    litc = np.clip(lin * 0.62 + cool * 0.3, 0, 1) ** (1 / 2.2) * 255
    srgb[edge] = dark[edge]
    sel = edge & edge_lit & ~(edge_any & ~edge_lit) & (band >= 0.36)
    srgb[sel] = litc[sel]
    dmask = np.zeros((H, W), np.float32)
    if fog is not None:
        yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
        ox, oy = t * 2.5, t * 0.6
        fn = 0.55 * value_noise(W, H, 40, 11, ox, oy) + 0.3 * value_noise(W, H, 16, 12, ox * 1.6, oy) + 0.15 * value_noise(W, H, 7, 13, ox * 2.2, oy)
        # pozycja w swiecie z kamery ortograficznej (cel, pochylenie, obrot, skala, odleglosc)
        tgt, tilt, yaw, ortho, dist, x0, x1 = fog[:7]
        tt, yw = np.radians(tilt), np.radians(yaw)
        fwd = np.array([-np.sin(yw) * np.sin(tt), np.cos(yw) * np.sin(tt), -np.cos(tt)])
        right = np.array([np.cos(yw), np.sin(yw), 0.0]); up = np.cross(right, fwd)
        cam = np.array(tgt) - fwd * dist
        px = (xx + 0.5 - W / 2) / W * ortho; py = -(yy + 0.5 - H / 2) / W * ortho
        Dd = np.where(depth > 1e4, 60.0, depth)
        wx = cam[0] + right[0] * px + up[0] * py + fwd[0] * Dd
        if len(fog) > 7:      # mgla promieniowa: zaczyna sie za krawedzia swiatla latarni
            wy = cam[1] + right[1] * px + up[1] * py + fwd[1] * Dd
            rr = np.hypot(wx - fog[7][0], wy - fog[7][1])
            grad = np.clip((rr - x0) / (x1 - x0), 0, 1) ** 0.8
        else:
            grad = np.clip((wx - x0) / (x1 - x0), 0, 1) ** 0.8
        dens = np.clip(grad * (0.15 + 0.75 * fn), 0, 0.75) * np.clip(1 - L * 1.6, 0, 1)
        fc = np.array(hx(PAL["f1"]), np.float32) * (1 - fn[..., None]) + np.array(hx(PAL["f2"]), np.float32) * fn[..., None]
        fc = fc * 0.85 + np.array(hx(PAL["v1"]), np.float32) * 0.15
        keep = em
        mix = srgb * (1 - dens[..., None] * 0.85) + fc * dens[..., None] * 0.95
        srgb = np.where(keep[..., None], srgb, mix)
        dmask = (dens > 0.08).astype(np.float32) * (idx < 3)
    q = quantize(srgb, dmask, 9.0)
    return Image.fromarray(q, "RGB")
