"""Pokaz przejsc i reakcji: 5 torow, kazdy z sekwencja akcji zmieszanych plynnie. python3 showcase2.py -- F0 F1 SAMPLES"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A
from fx import FX, watch_events

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
F0, F1, SAMP = (int(args[0]), int(args[1]), int(args[2])) if args else (0, 48, 20)
N = 48
reset(); setup_render(samples=SAMP)
world((40, 36, 58), 0.45)
ground = mat("ground", (58, 54, 62), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
    (0.0, (56, 53, 60)), (0.45, (60, 57, 64)), (0.66, (64, 60, 64)), (0.82, (58, 60, 56))]))
box("ground", (0, 0, -0.05), (50, 30, 0.1), ground, pass_index=1)

CAMYAW = -25; YAW = CAMYAW - 10
_cy = math.radians(CAMYAW)
RIGHT = V((math.cos(_cy), math.sin(_cy), 0)); FWD = V((-math.sin(_cy), math.cos(_cy), 0))
yw = math.radians(YAW); HEAD = V((math.cos(yw), math.sin(yw), 0))
WALK, RUN, PATROL = 0.137, 0.30, 0.12
S = A.stance

def shoot_loop(f):
    """Seria: zlozenie i strzal co 6 klatek."""
    k = f % 6
    return A.merge(A.wide(), A.recoil() if k == 2 else (A.lerp_pose(A.recoil(), A.aim(), A.ease(min((k - 2) / 3, 1), "out")) if k > 2 else A.aim()))
def kneel_shoot(f):
    k = f % 7
    return A.merge(A.kneel(), A.recoil() if k == 3 else (A.lerp_pose(A.recoil(), A.aim(), A.ease(min((k - 3) / 3, 1), "out")) if k > 3 else A.aim()))
def prone_shoot(f):
    k = f % 8
    p = A.prone()
    if k == 3: p = A.merge(p, A.P(rot={"weapon": (0, -6, 0), "head": (0, -4, 0)}, loc={"weapon": (-0.05, 0, -0.06)}, vis={"flash": 1}))
    return p
def dive(f):
    if f < 5: return A.lerp_pose(A.run_rifle(0), A.dive_mid(), A.ease(f / 5, "out"))
    return A.lerp_pose(A.dive_mid(), A.prone(), A.ease(min((f - 5) / 3, 1), "in"))
def stand_up(f):
    return A.lerp_pose(A.kneel(), A.merge(S(), A.low_ready()), A.ease(min(f / 5, 1), "io"))

LANES = [
    ("Chód → bieg → stop i seria", dict(jacket="olive", pants="olive", helmet="mil"), A.Seq([
        (0, lambda f: A.merge(A.walk(f, 12, 24, arms=False), A.low_ready()), PATROL, 0),
        (12, lambda f: A.run_rifle(f, 8), RUN, 4),
        (28, lambda f: A.merge(A.wide(), A.aim()), 0.0, 4),
        (33, shoot_loop, 0.0, 1)])),
    ("Pod ostrzałem: skulenie, pad, czołganie, strzał z ziemi", dict(jacket="teal", pants="darkgrey", helmet="mil"), A.Seq([
        (0, lambda f: A.merge(A.walk(f, 12, 24, arms=False), A.low_ready()), PATROL, 0),
        (9, lambda f: A.flinch(), 0.02, 3),
        (13, lambda f: A.run_rifle(f, 8), RUN, 3),
        (18, dive, 0.22, 2),
        (26, lambda f: A.crawl(f, 16), 0.035, 3),
        (38, prone_shoot, 0.0, 3)])),
    ("Strzał, przyklęk, ogień z kolana, powstanie", dict(jacket="olive", pants="brown", helmet="pot"), A.Seq([
        (0, lambda f: A.merge(S(), A.low_ready()), 0.0, 0),
        (3, shoot_loop, 0.0, 3),
        (14, lambda f: A.merge(A.kneel(), A.aim()), 0.0, 4),
        (18, kneel_shoot, 0.0, 1),
        (38, stand_up, 0.0, 2),
        (44, lambda f: A.merge(S(), A.low_ready()), 0.0, 2)])),
    ("Trafiony: zachwianie i powrót do walki", dict(jacket="grey", pants="darkgrey", helmet="mil", armor="vest"), A.Seq([
        (0, lambda f: A.merge(A.wide(), A.aim()), 0.0, 0),
        (4, shoot_loop, 0.0, 1),
        (14, lambda f: A.merge(S(), A.low_ready(), A.stagger(f)), 0.0, 1),
        (28, lambda f: A.merge(A.wide(), A.aim(), A.P(root=(-0.18, 0, 0, 0))), 0.0, 4),
        (32, lambda f: A.merge(shoot_loop(f), A.P(root=(-0.18, 0, 0, 0))), 0.0, 1)])),
    ("Skok do osłony i wychylenie", dict(jacket="blue", pants="darkgrey", mask="gas"), A.Seq([
        (0, lambda f: A.run_rifle(f, 8), RUN, 0),
        (14, lambda f: A.merge(A.crouch(1.0), A.low_ready()), 0.0, 3),
        (20, lambda f: A.clip_cover().sample(f + 2), 0.0, 3)])),
]
NL = len(LANES); SP = 2.15
rigs = []
for i, (title, o, seq) in enumerate(LANES):
    r = human("tor%d" % i, o, "rifle")
    base = RIGHT * (-6.6 if i in (0, 1, 4) else -4.0) + FWD * ((NL - 1) / 2 - i) * SP
    rigs.append((r, seq, tuple(base)))

# oslona: worki na koncu biegu ostatniego toru
SAND = M("sand", (104, 96, 74)); SAND2 = M("sand2", (92, 86, 66))
d_end = sum(LANES[4][2]._at(k)[1] for k in range(20))
cpos = V(rigs[4][2]) + HEAD * (d_end + 0.72)
for k in range(4):
    for j in range(-2, 3):
        jj = j + (0.5 if k % 2 else 0)
        if k % 2 and j == 2: continue
        p = cpos + V((-HEAD.y, HEAD.x, 0)) * jj * 0.36
        b = box("sb%d%d" % (k, j), (p.x, p.y, 0.08 + 0.15 * k), (0.30, 0.38, 0.15), SAND if (j + k) % 2 else SAND2, rot=(0, 0, yw), smooth=False)
        b.modifiers.new("bv", "BEVEL").width = 0.05
# gruz i trawa jako punkty odniesienia ruchu
import random
rnd = random.Random(3)
STONE = mat("stone", (82, 78, 86), pass_index=1); GRASS = mat("grass", (70, 84, 56), pass_index=1)
for k in range(120):
    p = RIGHT * rnd.uniform(-8, 8) + FWD * rnd.uniform(-6, 6)
    if k % 3: box("st%d" % k, (p.x, p.y, 0.02), (rnd.uniform(0.06, 0.16), rnd.uniform(0.05, 0.12), 0.05), STONE, rot=(0, 0, rnd.uniform(0, 3)), pass_index=1)
    else: cyl("gr%d" % k, (p.x, p.y, 0), (p.x + 0.03, p.y, 0.16), 0.03, GRASS, r1=0.005, seg=4, pass_index=1)

sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.84, 0.64), 2.6)
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.70, 0.76, 1.0), 1.2)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
camera(RIGHT * -2.4 + FWD * -0.5 + V((0, 0, 0.6)), 50, 11.5, (640, 480), yaw_deg=CAMYAW)

fxs = FX(); st = {}
FR = [int(x) for x in os.environ['FRAMES'].split(',')] if 'FRAMES' in os.environ else range(F0, F1)
for f in range(0, max(FR) + 1):
    for r, seq, base in rigs: A.apply(r, seq.sample(f), base, YAW)
    bpy.context.view_layer.update()
    for r, *_ in rigs: watch_events(fxs, r, st.setdefault(r.ob.name, {}))
    fxs.step()
    if f in FR: render("/home/claude/latarnia3d/out/seq_%02d.exr" % f)
