"""Katalog budynkow: arkusz nr S (8 budynkow, 4x2). python3 catalog.py -- S"""
import sys, math, json
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import buildings as BD
S = int(sys.argv[sys.argv.index("--") + 1])
items = BD.CATALOG[S * 6:(S + 1) * 6]
reset(); setup_render(samples=20)
world((48, 44, 64), 0.7)
ground = mat("ground", (64, 60, 62), pass_index=1)
box("ground", (0, 0, -0.05), (80, 60, 0.1), ground, pass_index=1)
CAMYAW = -32; cy = math.radians(CAMYAW)
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
pos = []
for i, (name, fn) in enumerate(items):
    c, r = i % 3, i // 3
    p = RIGHT * ((c - 1) * 9.6) + FWD * ((0.5 - r) * 12.5 + 0.2)
    fn(p.x, p.y, CAMYAW + 38)
    pos.append((name, (c - 1) * 9.6, (0.5 - r) * 12.5 + 0.2))
sun("key", (math.radians(52), 0, math.radians(CAMYAW + 25)), (1.0, 0.82, 0.62), 3.2)
sun("fill", (math.radians(60), 0, math.radians(CAMYAW + 140)), (0.55, 0.62, 0.95), 0.6)
camera((0, 0, 2.0), 52, 31, (960, 620), yaw_deg=CAMYAW)
json.dump(pos, open("/home/claude/latarnia3d/out/cat_%d.json" % S, "w"))
render("/home/claude/latarnia3d/out/cat_%d.exr" % S)
