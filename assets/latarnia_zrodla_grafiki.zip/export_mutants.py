"""Mutanty do symulatora bitew: Ogar (pies Mgly), Krzykacz, Nosiciel i szczur Mgly, kazdy z pelnym zestawem klipow."""
import math, sys
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import lat3d, chars
from chars import *
import anim_mut as AM, mutanim as MA
from anim import P, merge, Clip, ease
from anim_combat import C, M as Mg, bscl
import export_combat as E

# ================================================================== OGAR
def og_stand(k=0.0):
    s = math.sin(2 * math.pi * k)
    return P(rot={"jaw": (0, 16 + 8 * s, 0), "neck": (0, 4, 0), "head": (0, 2 * s, 0), "chest": (0, -1.5 * s, 0), "tail1": (0, -6, 6 * s), "tail2": (0, -4, 0),
                  "flo.L": (0, -4, 0), "flo.R": (0, -4, 0), "hlo.L": (0, 6, 0), "hlo.R": (0, 6, 0)}, root=(0, 0, 0.004 * s, 0, 0))

def og_idle():   # dyszy, rozglada sie
    return C(24, [(0, og_stand(0.0), "io"), (6, Mg(og_stand(0.25), P(rot={"neck": (0, 0, 10)})), "io"), (12, og_stand(0.5), "io"),
                  (18, Mg(og_stand(0.75), P(rot={"neck": (0, 0, -10)})), "io")], loop=True)

def og_stalk(f, n=16):
    """Skradanie: nisko, glowa na wysokosci grzbietu, sekwencja boczna lap (L tyl, L przod, P tyl, P przod)."""
    p = (f % n) / n
    pose = P()
    for leg, side, ph in (("h", "L", 0.0), ("f", "L", 0.25), ("h", "R", 0.5), ("f", "R", 0.75)):
        q = (p + ph) % 1.0; c = math.cos(2 * math.pi * q); s = math.sin(2 * math.pi * q)
        lift = max(0.0, s)
        if leg == "f":
            pose["rot"]["fup." + side] = (0, -20 * c - 18, 0); pose["rot"]["flo." + side] = (0, -40 * lift - 30, 0); pose["rot"]["fpaw." + side] = (0, 30 * lift + 22, 0)
        else:
            pose["rot"]["hup." + side] = (0, -22 * c - 26, 0); pose["rot"]["hlo." + side] = (0, 30 * lift + 34, 0); pose["rot"]["hpaw." + side] = (0, -20 * lift - 14, 0)
    pose["rot"]["neck"] = (0, 22, 0); pose["rot"]["head"] = (0, -18, 0); pose["rot"]["jaw"] = (0, 6, 0)
    pose["rot"]["tail1"] = (0, -18, 4 * math.sin(2 * math.pi * p)); pose["rot"]["tail2"] = (0, -6, 0)
    pose["rot"]["spine"] = (0, 3 * math.sin(4 * math.pi * p), 0)
    pose["root"] = (0, 0, -0.13, 4, 2 * math.sin(2 * math.pi * p))
    return pose

def og_bite():
    """Ugryzienie w miejscu (12 kl): przyczajenie, wypad z otwarta paszcza, szarpniecie glowa, odskok."""
    st = og_stand(0)
    crouch = AM._ogar_crouch(0.7)
    lunge = P(rot={"fup.L": (0, -46, 0), "fup.R": (0, -40, 0), "flo.L": (0, -20, 0), "flo.R": (0, -20, 0), "hup.L": (0, 20, 0), "hup.R": (0, 24, 0),
                   "hlo.L": (0, 0, 0), "hlo.R": (0, 0, 0), "neck": (0, -14, 0), "head": (0, 10, 0), "jaw": (0, 40, 0), "tail1": (0, 16, 0)}, root=(0.30, 0, 0.04, -8, 0))
    snap = Mg(lunge, P(rot={"jaw": (0, -38, 0), "neck": (0, 8, 14), "head": (0, 6, 10)}))
    shake = Mg(snap, P(rot={"neck": (0, 0, -26), "head": (0, 0, -16)}))
    back = Mg(st, P(root=(-0.10, 0, 0, 0, 0)))
    return C(12, [(0, st, "io"), (2, crouch, "hold"), (3, crouch, "snap"), (5, lunge, "out"), (6, snap, "io"), (8, shake, "io"), (11, back, "hold")], loop=False)

def og_hit():
    st = og_stand(0)
    yelp = Mg(st, P(rot={"neck": (0, -20, 18), "head": (0, -14, 0), "jaw": (0, 30, 0), "spine": (0, -8, 6), "tail1": (0, 24, 0), "hup.L": (0, 14, 0)}, root=(-0.10, 0, 0.03, -6, 8)))
    return C(8, [(0, st, "snap"), (2, yelp, "io"), (7, st, "hold")], loop=False)

def export_ogar(out):
    E.fresh(); import mutants2
    r = mutants2.quadruped("ogar", "pies")
    E.bake(r, {"idle": (24, og_idle().sample), "walk": (16, og_stalk), "run": (8, lambda f: AM.ogar_gallop(f, 8)), "attack": (12, og_bite().sample),
               "hit": (8, og_hit().sample), "death": (24, AM.clip_ogar_death().sample), "dead": (1, lambda f: AM.clip_ogar_death().sample(23))})
    E.save(out + "/ogar.glb"); print("EXPORTED ogar")

# ================================================================== KRZYKACZ i NOSICIEL (kosc "belly" i "mouth" do skalowania)
EXTRA_M = []
_hb = chars.human_bones
def _hb_m(arm=1.0, leg=1.0, torso=1.0, pose="idle"):
    return _hb(arm, leg, torso, pose) + EXTRA_M

def krz_hit():
    h = MA.krz_hunch()
    j = Mg(h, P(rot={"spine": (0, -18, 8), "chest": (0, -12, 10), "head": (0, -24, 10), "upperarm.L": (30, -20, 0), "upperarm.R": (-30, -20, 0)}, loc={"hips": (-0.06, 0, 0)}))
    return C(8, [(0, h, "snap"), (2, j, "io"), (7, h, "hold")], loop=False)

def krz_idle():
    h = MA.krz_hunch()
    a = Mg(h, P(rot={"head": (0, 6, 14), "chest": (0, 3, 6), "upperarm.L": (18, 6, 0)})); b = Mg(h, P(rot={"head": (0, -4, -12), "chest": (0, -2, -6), "upperarm.R": (-18, 6, 0)}))
    return C(24, [(0, h, "io"), (7, a, "io"), (14, h, "io"), (19, b, "io")], loop=True)

def krz_scream():
    c = MA.clip_krz_scream()
    def fn(f):
        p = c.sample(f); s = p.get("scl", {})
        out = Mg(p, bscl(mouth=s.get("mouth", 1.0)))
        return out
    return fn

def export_krzykacz(out):
    global EXTRA_M
    E.fresh()
    EXTRA_M = [("mouth", (0.10, 0, 1.67), (0.16, 0, 1.67), "head")]
    chars.human_bones = _hb_m
    try: r = krzykacz("krzykacz")
    finally: chars.human_bones = _hb; EXTRA_M = []
    for k in ("_mouth", "_throat"):
        o = bpy.data.objects.get("krzykacz" + k)
        if o: r.attach(o, "mouth")
    dc = MA.clip_krz_death()
    E.bake(r, {"idle": (24, krz_idle().sample), "walk": (14, MA.krz_walk), "run": (8, AM.krzykacz_lope), "scream": (24, krz_scream()),
               "attack": (24, MA.clip_krz_slash().sample), "hit": (8, krz_hit().sample), "death": (24, dc.sample), "dead": (1, lambda f: dc.sample(23))})
    E.save(out + "/krzykacz.glb"); print("EXPORTED krzykacz")

def export_nosiciel(out):
    global EXTRA_M
    E.fresh()
    EXTRA_M = [("belly", (0.05, 0, 0.98), (0.05, 0, 1.10), "spine")]
    chars.human_bones = _hb_m
    try: r = nosiciel("nosiciel")
    finally: chars.human_bones = _hb; EXTRA_M = []
    for o in list(bpy.data.objects):
        if o.name.startswith("nosiciel_belly") or o.name.startswith("nosiciel_pust"): r.attach(o, "belly")
    def scl2b(fn):
        def g(f):
            p = fn(f); s = p.get("scl", {}).get("belly", 1.0)
            if p.get("vis", {}).get("belly") == 0: s = 0.001
            return Mg(p, bscl(belly=s))
        return g
    def idle(f):
        p = MA.nos_walk(0); s = math.sin(2 * math.pi * f / 24)
        p = merge(p, P(rot={"head": (0, 4 * s, 6 * s), "spine": (0, 2 * s, 0)})); p["root"] = (0, 0, 0, 0, 3 * s)
        return Mg(p, bscl(belly=1.0 + 0.04 * s))
    def hit(f):
        k = min(f / 3, 1.0) if f < 3 else max(0.0, 1 - (f - 3) / 5)
        p = merge(MA.nos_walk(0), P(rot={"spine": (0, -14 * k, 0), "head": (0, -20 * k, 0)}, loc={"hips": (-0.05 * k, 0, 0)}))
        return Mg(p, bscl(belly=1.0 + 0.10 * k))
    bc = MA.clip_nos_burst()
    E.bake(r, {"idle": (24, idle), "walk": (16, scl2b(MA.nos_walk)), "hit": (8, hit), "death": (24, scl2b(bc.sample)), "dead": (1, lambda f: scl2b(bc.sample)(23))})
    E.save(out + "/nosiciel.glb"); print("EXPORTED nosiciel")

# ================================================================== SZCZUR MGLY (nowy model z kosciami)
def rat_model(name):
    S = 1.25   # zmutowany: wiekszy niz zwykly szczur (ok. 45 cm z ogonem 30 cm)
    B = [("body", (-0.10 * S, 0, 0.075 * S), (0.05 * S, 0, 0.08 * S), None),
         ("head", (0.05 * S, 0, 0.08 * S), (0.14 * S, 0, 0.065 * S), "body"),
         ("jaw", (0.08 * S, 0, 0.06 * S), (0.14 * S, 0, 0.05 * S), "head"),
         ("tail1", (-0.10 * S, 0, 0.07 * S), (-0.22 * S, 0, 0.05 * S), "body"), ("tail2", (-0.22 * S, 0, 0.05 * S), (-0.38 * S, 0, 0.02 * S), "tail1")]
    for s, n in ((1, "L"), (-1, "R")):
        B += [("fleg." + n, (0.03 * S, s * 0.03 * S, 0.06 * S), (0.045 * S, s * 0.035 * S, 0.0), "body"),
              ("hleg." + n, (-0.07 * S, s * 0.035 * S, 0.06 * S), (-0.05 * S, s * 0.04 * S, 0.0), "body")]
    r = Rig(name, B); A = r.attach
    fur = M("ratfur", (104, 94, 100)); fur2 = M("ratfur2", (84, 74, 82)); skin = SKIN_PALE(); sore = M("sore", (140, 40, 44))
    A(loft(name + "_b", [((-0.12 * S, 0, 0.065 * S), 0.03 * S, 0.035 * S), ((-0.07 * S, 0, 0.075 * S), 0.048 * S, 0.055 * S), ((0.0, 0, 0.08 * S), 0.05 * S, 0.055 * S),
                         ((0.05 * S, 0, 0.08 * S), 0.036 * S, 0.04 * S)], fur, seg=8), "body")
    A(ellipsoid(name + "_bald", (-0.04 * S, 0.035 * S, 0.095 * S), (0.025 * S, 0.012 * S, 0.018 * S), skin), "body")
    A(ellipsoid(name + "_sore", (-0.08 * S, -0.035 * S, 0.09 * S), (0.012 * S, 0.01 * S, 0.01 * S), sore), "body")
    for k in range(3):
        A(loft(name + "_spine%d" % k, [((-0.06 * S + 0.03 * k * S, 0, 0.125 * S), 0.004, 0.004), ((-0.065 * S + 0.03 * k * S, 0, 0.145 * S), 0.001, 0.001)], fur2, seg=4), "body")
    A(loft(name + "_h", [((0.04 * S, 0, 0.08 * S), 0.03 * S, 0.034 * S), ((0.10 * S, 0, 0.072 * S), 0.02 * S, 0.022 * S), ((0.15 * S, 0, 0.062 * S), 0.006, 0.006)], fur, seg=8), "head")
    A(ellipsoid(name + "_jawm", (0.11 * S, 0, 0.052 * S), (0.03 * S, 0.014 * S, 0.008 * S), fur2), "jaw")
    A(ellipsoid(name + "_teeth", (0.145 * S, 0, 0.058 * S), (0.006, 0.006, 0.01), TOOTH()), "head")
    for s in (1, -1):
        A(ellipsoid(name + "_ear%d" % s, (0.06 * S, s * 0.025 * S, 0.105 * S), (0.008 * S, 0.016 * S, 0.016 * S), skin), "head")
        A(ellipsoid(name + "_eye%d" % s, (0.11 * S, s * 0.017 * S, 0.08 * S), (0.007, 0.007, 0.007), GLOW_RED()), "head")
        A(cyl(name + "_fl%d" % s, (0.03 * S, s * 0.03 * S, 0.06 * S), (0.045 * S, s * 0.035 * S, 0.005), 0.008, skin, r1=0.005, seg=5), "fleg." + ("L" if s > 0 else "R"))
        A(cyl(name + "_hl%d" % s, (-0.07 * S, s * 0.035 * S, 0.06 * S), (-0.05 * S, s * 0.04 * S, 0.005), 0.011, fur, r1=0.006, seg=5), "hleg." + ("L" if s > 0 else "R"))
    A(cyl(name + "_t1", (-0.11 * S, 0, 0.065 * S), (-0.22 * S, 0, 0.05 * S), 0.008, skin, r1=0.006, seg=5), "tail1")
    A(cyl(name + "_t2", (-0.22 * S, 0, 0.05 * S), (-0.38 * S, 0, 0.02 * S), 0.006, skin, r1=0.002, seg=5), "tail2")
    return r

def rat_run(f, n=4):
    """Bieg szczura: skoki (przednie i tylne lapy parami), grzbiet sie wygina, ogon faluje."""
    p = (f % n) / n; c = math.cos(2 * math.pi * p); s = math.sin(2 * math.pi * p)
    return P(rot={"fleg.L": (0, -40 * c, 0), "fleg.R": (0, -40 * c + 6, 0), "hleg.L": (0, 46 * c, 0), "hleg.R": (0, 46 * c - 6, 0),
                  "head": (0, 6 * s, 0), "tail1": (0, 8 * s, 14 * c), "tail2": (0, 6, 18 * math.cos(2 * math.pi * p - 1))},
             root=(0, 0, 0.012 * max(0, s), 8 * c, 0))

def rat_idle(f):
    k = f / 24; s = math.sin(2 * math.pi * k)
    sniff = math.sin(2 * math.pi * k * 6) * (1 if 0.3 < k < 0.6 else 0)
    return P(rot={"head": (0, -6 + 4 * sniff, 10 * s), "tail1": (0, 4, 10 * s), "tail2": (0, 0, 16 * s), "jaw": (0, 2 + 2 * sniff, 0)})

def rat_bite():
    st = P()
    back = P(rot={"head": (0, 16, 0), "fleg.L": (0, 20, 0), "fleg.R": (0, 20, 0)}, root=(-0.03, 0, 0, -8, 0))
    lunge = P(rot={"head": (0, -18, 0), "jaw": (0, 40, 0), "fleg.L": (0, -50, 0), "fleg.R": (0, -44, 0), "hleg.L": (0, 30, 0), "hleg.R": (0, 30, 0)}, root=(0.08, 0, 0.03, -14, 0))
    snap = merge(lunge, P(rot={"jaw": (0, -40, 0), "head": (0, 0, 16)}))
    return C(8, [(0, st, "io"), (2, back, "snap"), (3, lunge, "out"), (4, snap, "io"), (5, merge(snap, P(rot={"head": (0, 0, -30)})), "io"), (7, st, "hold")], loop=False)

def rat_death():
    st = P()
    flip = P(rot={"fleg.L": (0, -60, 0), "fleg.R": (0, -30, 0), "hleg.L": (0, 50, 0), "hleg.R": (0, 20, 0), "head": (0, -20, 20), "jaw": (0, 30, 0), "tail1": (0, -10, 30)}, root=(0, 0, 0.05, 0, 100))
    lie = merge(flip, P(root=(0, 0, -0.05, 0, 75)))
    tw = merge(lie, P(rot={"hleg.L": (0, -30, 0), "fleg.R": (0, -20, 0)}))
    return C(16, [(0, st, "snap"), (2, flip, "out"), (4, lie, "io"), (7, tw, "snap"), (8, lie, "io"), (15, lie, "hold")], loop=False)

def export_rat(out):
    E.fresh(); r = rat_model("szczur")
    d = rat_death()
    E.bake(r, {"idle": (24, rat_idle), "run": (4, rat_run), "walk": (8, lambda f: rat_run(f, 8)), "attack": (8, rat_bite().sample),
               "hit": (6, lambda f: merge(P(), P(rot={"head": (0, 20 * math.sin(math.pi * f / 6), 0)}, root=(-0.04 * math.sin(math.pi * f / 6), 0, 0, 0, 0)))),
               "death": (16, d.sample), "dead": (1, lambda f: d.sample(15))})
    E.save(out + "/szczur.glb"); print("EXPORTED szczur")

def run(out, only=None):
    for nm, fn in (("ogar", export_ogar), ("krzykacz", export_krzykacz), ("nosiciel", export_nosiciel), ("szczur", export_rat)):
        if only and nm not in only: continue
        fn(out)
