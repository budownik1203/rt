"""Eksport postaci z pelnym zestawem animacji (kazda akcja to osobny klip NLA) dla Godota."""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
import lat3d
from chars import *
import anim as A
OUT = "/home/claude/latarnia3d/export/animacje"
import os; os.makedirs(OUT, exist_ok=True)
def kneel_shoot(f):
    k = f % 7
    return A.merge(A.kneel(), A.recoil() if k == 3 else (A.lerp_pose(A.recoil(), A.aim(), A.ease(min((k - 3) / 3, 1), "out")) if k > 3 else A.aim()))
def dive(f):
    if f < 5: return A.lerp_pose(A.run_rifle(0), A.dive_mid(), A.ease(f / 5, "out"))
    return A.lerp_pose(A.dive_mid(), A.prone(), A.ease(min((f - 5) / 3, 1), "in"))
SETS = {
  "zolnierz_karabin": ("rifle", dict(jacket="olive", pants="olive", helmet="mil", armor="vest"), {
      "idle": (24, lambda f: A.merge(A.stance(), A.low_ready(), A.breathe(f, 24))),
      "walk": (12, lambda f: A.merge(A.walk(f, 12, stride=24, arms=False), A.low_ready())),
      "run": (8, lambda f: A.run_rifle(f, 8)), "shoot": (24, A.clip_shoot().sample), "reload": (24, A.clip_reload().sample),
      "kneel_shoot": (7, kneel_shoot), "dive_to_prone": (8, dive), "prone_crawl": (16, lambda f: A.crawl(f, 16)),
      "flinch": (6, lambda f: A.lerp_pose(A.merge(A.stance(), A.low_ready()), A.flinch(), A.ease(min(f / 5, 1), "out"))),
      "stagger": (14, A.stagger), "cover_peek_shoot": (24, A.clip_cover().sample), "death": (24, A.clip_death().sample)}),
  "wojownik_dzida": ("spear", dict(jacket="leather", pants="brown", armor="plate", helmet="pot"), {
      "idle": (24, lambda f: A.merge(A.stance(), A.breathe(f, 24))), "thrust": (24, A.clip_spear().sample),
      "walk": (12, lambda f: A.walk(f, 12, stride=24, arms=False)), "death": (24, A.clip_death().sample)}),
  "wojownik_mlot": ("hammer", dict(jacket="brown", pants="darkgrey", armor="vest", beard=True), {
      "idle": (24, lambda f: A.merge(A.stance(), A.breathe(f, 24))), "smash": (24, A.clip_hammer().sample),
      "walk": (12, lambda f: A.walk(f, 12, stride=24, arms=False)), "death": (24, A.clip_death().sample)}),
  "wojownik_maczeta": ("machete", dict(jacket="leather", pants="brown"), {
      "guard": (1, lambda f: A.merge(A.wide(), A.guard1())), "slash": (16, A.clip_slash().sample), "death": (24, A.clip_death().sample)}),
  "granatnik": ("grenade", dict(jacket="grey", pants="darkgrey", helmet="mil"), {"throw": (24, A.clip_grenade().sample)}),
  "cywil": ("idle", dict(jacket="brown", pants="darkgrey", beard=True), {
      "walk": (12, lambda f: A.walk(f, 12)), "run": (8, lambda f: A.run(f, 8)), "sit_talk": (16, A.talk), "death": (24, A.clip_death().sample)}),
  "drwal": ("axe", dict(jacket="brown", pants="brown", strap=False), {"chop": (20, A.clip_chop().sample)}),
  "kopacz": ("shovel", dict(jacket="grey", pants="brown", strap=False), {"dig": (24, A.clip_dig().sample)}),
  "tragarz": ("carry", dict(jacket="olive", pants="brown"), {"carry_walk": (14, lambda f: A.carry_walk(f, 14))}),
  "kowal": ("smith", dict(jacket="leather", pants="darkgrey", beard=True, armor="vest"), {"hammer_anvil": (8, A.clip_smith().sample)}),
}
for nm, (pose, outfit, clips) in SETS.items():
    reset(); lat3d.MATS.clear(); lat3d.CHAR_COL = None
    bpy.context.scene.render.fps = 12
    r = human(nm, outfit, pose)
    ob = r.ob; ob.animation_data_create(); bones = list(ob.pose.bones)
    for cname, (n, fn) in clips.items():
        act = bpy.data.actions.new(cname); ob.animation_data.action = act
        for f in range(n + 1):
            A.apply(r, fn(f), (0, 0, 0), 0); bpy.context.view_layer.update()
            mats = {pb.name: pb.matrix.copy() for pb in bones}
            for pb in bones:
                for c in pb.constraints: c.mute = True
            for pb in bones:
                pb.matrix = mats[pb.name]; bpy.context.view_layer.update()
                pb.keyframe_insert("rotation_quaternion", frame=f); pb.keyframe_insert("location", frame=f)
            for pb in bones:
                for c in pb.constraints: c.mute = False
            ob.keyframe_insert("location", frame=f); ob.keyframe_insert("rotation_euler", frame=f)
        act.use_fake_user = True
        tr = ob.animation_data.nla_tracks.new(); tr.name = cname; tr.strips.new(cname, 0, act)
        ob.animation_data.action = None
    for pb in bones:
        for c in list(pb.constraints): pb.constraints.remove(c)
    for o in list(bpy.data.objects):
        if o.type in ("LIGHT", "CAMERA"): bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.export_scene.gltf(filepath=OUT + "/%s.glb" % nm, export_format="GLB", export_animations=True,
                              export_animation_mode="NLA_TRACKS", export_force_sampling=True, export_apply=False)
    print("EXPORTED", nm)
