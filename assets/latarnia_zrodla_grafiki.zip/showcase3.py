"""Pokaz mutantow: galop Ogarow, skok i zagryzienie, smierc Ogara od strzalu, krzyk Krzykacza, Nosiciel puchnie i peka."""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A, anim_mut as AM
from fx import FX, watch_events, burst, ring

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
F0, F1, SAMP = (int(args[0]), int(args[1]), int(args[2])) if args else (0, 48, 16)
reset(); setup_render(samples=SAMP)
world((34, 30, 52), 0.30)
ground = mat("ground", (58, 54, 62), pass_index=1, noise=dict(scale=2.2, detail=4.0, stops=[
    (0.0, (56, 53, 60)), (0.45, (60, 57, 64)), (0.66, (64, 60, 64)), (0.82, (58, 60, 56))]))
box("ground", (0, 0, -0.05), (50, 30, 0.1), ground, pass_index=1)
CAMYAW = -25; YAW = CAMYAW - 18
cy = math.radians(CAMYAW)
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
def at(c, r): return RIGHT * c + FWD * r
def hd(yaw): return V((math.cos(math.radians(yaw)), math.sin(math.radians(yaw)), 0))
actors = []   # (rig, fn(f)->pose, base, yaw)

# 1. dwa Ogary w galopie przez caly kadr (zawijanie na krawedzi)
for k in range(2):
    og = ogar("galop%d" % k)
    def fn(f, k=k):
        p = AM.ogar_gallop(f + 3 * k, 8)
        x = ((0.42 * f + 7 * k) % 16.0) - 8.0
        r = list(p["root"]); r[0] += x; p["root"] = tuple(r); return p
    actors.append((og, fn, tuple(at(0, 3.2 - 0.7 * k)), CAMYAW))

# 2. skok i zagryzienie: Ogar skacze na strzelca, ktory pada
POUNCE = A.clip_death()
dog = ogar("skok"); dbase = at(-6.0, 0.2); dyaw = CAMYAW - 8
pc = AM.clip_ogar_pounce()
actors.append((dog, lambda f: pc.sample(min(f, 21)) if f < 22 else A.merge(pc.sample(14 + (f - 22) % 8 / 2 * 1.0)), tuple(dbase), dyaw))
vic = human("ofiara", dict(jacket="olive", pants="olive", helmet="mil"), "rifle")
vbase = dbase + hd(dyaw) * 2.35
dc = A.clip_death()
def vfn(f):
    if f < 10: return A.merge(A.wide(), A.aim() if f < 5 else A.lerp_pose(A.aim(), A.recoil(), 0.0 if f != 6 else 1.0))
    p = dc.sample(min(f - 10 + 2, 23))
    return p
actors.append((vic, vfn, tuple(vbase), dyaw + 180))

# 3. Ogar szarzuje na strzelca i ginie od strzalu
dog2 = ogar("smierc"); d2base = at(-1.2, 0.2); D2Y = CAMYAW - 8
dth = AM.clip_ogar_death()
seq = A.Seq([(0, lambda f: AM.ogar_gallop(f, 8), 0.34, 0), (10, lambda f: dth.sample(f), 0.16, 1), (16, lambda f: dth.sample(f + 6), 0.0, 2)])
actors.append((dog2, seq.sample, tuple(d2base), D2Y))
sh = human("strzelec", dict(jacket="teal", pants="darkgrey", helmet="mil", armor="vest"), "rifle")
shbase = d2base + hd(D2Y) * 6.0
def shfn(f):
    k = f % 5
    if f > 14: return A.merge(A.wide(), A.low_ready() if f > 20 else A.aim())
    return A.merge(A.wide(), A.recoil() if k == 1 else A.aim())
actors.append((sh, shfn, tuple(shbase), D2Y + 180))

# 4. Krzykacz: krzyk z fala uderzeniowa, pobliski czlowiek sie kuli
kz = krzykacz("krzyk"); kzbase = at(-5.0, -2.3)
ks = AM.clip_krzykacz_scream()
actors.append((kz, lambda f: A.merge(AM.krzykacz_base(), P()) if f < 12 else ks.sample(min(f - 12, 23)), tuple(kzbase), YAW))
nb = human("ogluszony", dict(jacket="brown", pants="darkgrey", beard=True), "rifle")
nbbase = kzbase + hd(YAW) * 2.2
def nbfn(f):
    if f < 21: return A.merge(A.stance(), A.low_ready())
    return A.lerp_pose(A.merge(A.stance(), A.low_ready()), A.merge(A.flinch(), A.P(rot={"head": (0, 10, 0)})), A.ease(min((f - 21) / 3, 1), "out"))
actors.append((nb, nbfn, tuple(nbbase), YAW + 180))
P = A.P

# 5. Nosiciel: ciezki chod, puchniecie, pekniecie
ns = nosiciel("nosiciel"); nsbase = at(0.6, -2.3)
BURST = 36
nseq = A.Seq([(0, lambda f: AM.nosiciel_walk(f, 16), 0.05, 0), (22, AM.nosiciel_swell, 0.0, 4)])
actors.append((ns, nseq.sample, tuple(nsbase), YAW))
belly = bpy.data.objects["nosiciel_belly"]; BC = V((0.05, 0, 0.98))

# 6. Krzykacz w pokracznym biegu
kz2 = krzykacz("bieg_krz")
def k2(f):
    p = AM.krzykacz_lope(f, 8); x = ((0.30 * f + 5) % 14.0) - 7.0
    r = list(p["root"]); r[0] += x; p["root"] = tuple(r); return p
actors.append((kz2, k2, tuple(at(0, 1.8)), CAMYAW))

sun("key", (math.radians(46), 0, math.radians(CAMYAW - 55)), (1.0, 0.84, 0.64), 2.8)
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.70, 0.76, 1.0), 1.2)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 4.0)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
camera((0, 0, 0.5), 50, 13.0, (640, 400), yaw_deg=CAMYAW)

fxs = FX(); st = {}
FR = [int(x) for x in os.environ['FRAMES'].split(',')] if 'FRAMES' in os.environ else range(F0, F1)
for f in range(0, max(FR) + 1):
    for r, fn, base, yaw in actors: A.apply(r, fn(f), base, yaw)
    # puchnacy brzuch
    k = 0 if f < 22 else min((f - 22) / 14, 1.0)
    s = 1 + 0.45 * k * k + (0.04 * math.sin(f * 2.1) * k)
    belly.matrix_basis = Matrix.Translation(BC) @ Matrix.Diagonal((s, s, s, 1)) @ Matrix.Translation(-BC)
    for o in ns.parts: o.hide_render = f >= BURST
    bpy.context.view_layer.update()
    for r, *_ in actors: watch_events(fxs, r, st.setdefault(r.ob.name, {}))
    if f == BURST: burst(fxs, belly.matrix_world @ BC)
    if f in (21, 23, 25): ring(fxs, kz.ob.matrix_world @ V((0.1, 0, 1.6)), life=6)
    fxs.step()
    if f in FR: render("/home/claude/latarnia3d/out/mut_%02d.exr" % f)
