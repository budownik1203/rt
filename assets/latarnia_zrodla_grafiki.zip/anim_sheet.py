"""Arkusz kontrolny animacji: kazda akcja w rzedzie, kolumny = wybrane klatki. python3 anim_sheet.py -- a1,a2,... OUT"""
import sys, math
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A

args = sys.argv[sys.argv.index("--") + 1:]
acts = args[0].split(","); OUT = args[1]
FR = [int(x) for x in (args[2] if len(args) > 2 else "0,3,6,8,9,11,14,18").split(",")]
reset(); setup_render(samples=6)
world((60, 56, 70), 0.6)
box("ground", (0, 0, -0.05), (60, 60, 0.1), mat("ground", (70, 66, 72), pass_index=1), pass_index=1)
sun("key", (math.radians(46), 0, math.radians(-80)), (1.0, 0.9, 0.8), 3.0)
sun("fill", (math.radians(55), 0, math.radians(125)), (0.7, 0.76, 1.0), 1.2)
CAMYAW = -25; YAW = CAMYAW - 18
cy = math.radians(CAMYAW)
RIGHT = V((math.cos(cy), math.sin(cy), 0)); FWD = V((-math.sin(cy), math.cos(cy), 0))
SPEC = {
    "walk": ("idle", dict(jacket="brown", pants="darkgrey"), lambda f: A.walk(f, 12)),
    "run": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.run_rifle(f, 8)),
    "shoot": ("rifle", dict(jacket="teal", pants="darkgrey", helmet="mil"), A.clip_shoot().sample),
    "reload": ("rifle", dict(jacket="olive", pants="brown", helmet="pot"), A.clip_reload().sample),
    "cover": ("rifle", dict(jacket="blue", pants="darkgrey", mask="gas"), A.clip_cover().sample),
    "spear": ("spear", dict(jacket="leather", pants="brown", armor="plate", helmet="pot"), A.clip_spear().sample),
    "hammer": ("hammer", dict(jacket="brown", pants="darkgrey", armor="vest"), A.clip_hammer().sample),
    "grenade": ("grenade", dict(jacket="grey", pants="darkgrey", helmet="mil"), A.clip_grenade().sample),
    "death": ("idle", dict(jacket="teal", pants="brown"), A.clip_death().sample),
    "kneel": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), A.clip_shoot(A.kneel()).sample),
    "prone": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.prone()),
    "crawl": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.crawl(f * 2, 16)),
    "flinch": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.flinch()),
    "stagger": ("rifle", dict(jacket="teal", pants="brown", helmet="pot"), lambda f: A.stagger(f)),
    "dive": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.dive_mid()),
    "patrol": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.merge(A.walk(f, 12, stride=24, arms=False), A.low_ready())),
    "kneel": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.merge(A.kneel(), A.aim() if f % 6 else A.recoil())),
    "flinch": ("rifle", dict(jacket="teal", pants="darkgrey", helmet="mil"), lambda f: A.lerp_pose(A.stance(), A.flinch(), A.ease(min(f / 5, 1), "out"))),
    "prone": ("rifle", dict(jacket="olive", pants="brown", helmet="pot"), lambda f: A.merge(A.prone(), A.P(vis={"flash": f % 6 == 3}))),
    "crawl": ("rifle", dict(jacket="blue", pants="darkgrey", mask="gas"), lambda f: A.crawl(f)),
    "stagger": ("rifle", dict(jacket="grey", pants="darkgrey", helmet="mil"), lambda f: A.merge(A.stance(), A.low_ready(), A.stagger(f))),
    "dive": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.lerp_pose(A.run_rifle(0), A.dive_mid(), f / 6) if f < 6 else A.lerp_pose(A.dive_mid(), A.prone(), min((f - 6) / 4, 1))),
    "turn": ("rifle", dict(jacket="olive", pants="olive", helmet="mil"), lambda f: A.run_turn(f, 1.0)),
    "climb": ("idle", dict(jacket="brown", pants="darkgrey"), lambda f: A.merge(A.climb(f), A.P(root=(0, 0, -0.6 * f / 12, 0, 0)))),
    "slash": ("machete", dict(jacket="leather", pants="brown"), A.clip_slash().sample),
    "chop": ("axe", dict(jacket="brown", pants="brown"), A.clip_chop().sample),
    "dig": ("shovel", dict(jacket="grey", pants="brown"), A.clip_dig().sample),
}
NC = len(FR); NR = len(acts); SX = 1.7; SY = 2.6
for r, a in enumerate(acts):
    pose, o, fn = SPEC[a]
    for c, f in enumerate(FR):
        rig = human("%s%d" % (a, c), o, pose)
        loc = RIGHT * ((c - (NC - 1) / 2) * SX) + FWD * (((NR - 1) / 2 - r) * SY)
        A.apply(rig, fn(f), tuple(loc), YAW)
W = NC * SX + 0.6
camera((0, 0, 0.8), 50, W, (int(W * 70), int((NR * SY * 0.78 + 0.8) * 70)), yaw_deg=CAMYAW)
render(OUT)
