import sys, glob
sys.path.insert(0, '/home/claude/latarnia3d')
from post import stylize
from PIL import Image, ImageDraw, ImageFont
FOG = ((-0.2, 2.4, 1.4), 52, -32, 24, 30, 3.4, 9.0)
what = sys.argv[1]
if what == "scene":
    fr = [stylize('out/scene_%02d.exr' % t, fog=FOG, t=t) for t in range(len(glob.glob('out/scene_*.exr')))]
    big = [f.resize((f.width * 2, f.height * 2), Image.NEAREST) for f in fr]
    big[0].save('out/latarnia3d_animacja.gif', save_all=True, append_images=big[1:], duration=110, loop=0)
    fr[0].resize((fr[0].width * 2, fr[0].height * 2), Image.NEAREST).save('out/latarnia3d_scena.png')
    fr[2].crop((250, 120, 490, 280)).resize((240 * 4, 160 * 4), Image.NEAREST).save('out/latarnia3d_zblizenie.png')
if what == "dirs":
    fr = [stylize('out/dirs_%02d.exr' % t) for t in range(8)]
    big = [f.resize((f.width * 3, f.height * 3), Image.NEAREST) for f in fr]
    big[0].save('out/latarnia3d_8kierunkow.gif', save_all=True, append_images=big[1:], duration=110, loop=0)
