"""Osada noca: latarnia w srodku, budynki w kregu swiatla, ludzie przy pracy, patrol, Mgla za krawedzia swiatla.
python3 osada.py -- F0 F1 SAMPLES"""
import sys, math, os
sys.path.insert(0, "/home/claude/latarnia3d")
from lat3d import *
from chars import *
import anim as A
import buildings as BD
from fx import FX, watch_events
args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
F0, F1, SAMP = (int(args[0]), int(args[1]), int(args[2])) if args else (0, 48, 16)
reset(); setup_render(samples=SAMP)
world((30, 28, 46), 0.22)
ground = mat("ground", (60, 56, 62), pass_index=1, noise=dict(scale=1.6, detail=5.0, stops=[
    (0.0, (52, 50, 56)), (0.42, (60, 56, 62)), (0.62, (66, 60, 58)), (0.78, (58, 62, 52)), (0.9, (64, 66, 56))]))
box("ground", (0, 0, -0.05), (90, 90, 0.1), ground, pass_index=1)
path = mat("path", (66, 61, 60), pass_index=1)
# ---------------------------------------------------------------- latarnia
stone = mat("stone", (110, 106, 116), pass_index=2, brick=dict(scale=3.2, c1=(108, 104, 114), c2=(92, 88, 100), mortar=(60, 56, 66), mortar_size=0.015))
dmetal = mat("dmetal", (52, 50, 60), pass_index=2)
lglass = mat("lglass", (255, 230, 160), pass_index=2, emit=(255, 214, 140), strength=9)
TX, TY = 0.0, 0.0
loft("tower", [((TX, TY, 0), 1.15, 1.15), ((TX, TY, 4.0), 1.02, 1.02), ((TX, TY, 7.9), 0.92, 0.92)], stone, seg=8, smooth=False)
loft("plinth", [((TX, TY, 0), 1.35, 1.35), ((TX, TY, 0.45), 1.3, 1.3)], stone, seg=8, smooth=False)
loft("gallery", [((TX, TY, 7.9), 1.35, 1.35), ((TX, TY, 8.08), 1.35, 1.35)], dmetal, seg=12, smooth=False)
for k in range(12):
    a = 2 * math.pi * k / 12
    cyl("rail%d" % k, (TX + 1.28 * math.cos(a), TY + 1.28 * math.sin(a), 8.08), (TX + 1.28 * math.cos(a), TY + 1.28 * math.sin(a), 8.6), 0.025, dmetal, seg=4)
loft("railtop", [((TX, TY, 8.58), 1.3, 1.3), ((TX, TY, 8.62), 1.3, 1.3)], dmetal, seg=12, cap=False)
loft("lantern_glass", [((TX, TY, 8.08), 0.68, 0.68), ((TX, TY, 9.0), 0.68, 0.68)], lglass, seg=8, smooth=False)
for k in range(8):
    a = 2 * math.pi * k / 8 + math.pi / 8
    cyl("mull%d" % k, (TX + 0.7 * math.cos(a), TY + 0.7 * math.sin(a), 8.08), (TX + 0.7 * math.cos(a), TY + 0.7 * math.sin(a), 9.0), 0.035, dmetal, seg=4)
loft("roof", [((TX, TY, 9.0), 0.86, 0.86), ((TX, TY, 9.55), 0.12, 0.12), ((TX, TY, 9.75), 0.03, 0.03)], dmetal, seg=8, smooth=False)
box("tdoor", (TX, TY - 1.12, 1.05), (0.85, 0.12, 2.1), mat("doorwood", (70, 48, 32), pass_index=2))
box("doorlamp", (TX, TY - 1.2, 2.35), (0.16, 0.12, 0.16), mat("doorlampm", (255, 210, 140), pass_index=2, emit=(255, 200, 120), strength=6))
point_light("doorlampL", (TX, TY - 1.5, 2.3), (1.0, 0.75, 0.45), 70, 0.08)
lantern = point_light("lantern", (TX, TY, 8.55), (1.0, 0.72, 0.42), 16000, 0.12)
for nm in ["tower", "lantern_glass", "gallery", "railtop", "roof"] + ["mull%d" % k for k in range(8)] + ["rail%d" % k for k in range(12)]:
    bpy.data.objects[nm].visible_shadow = False
# ---------------------------------------------------------------- budynki w kregu swiatla (x, y, obrot)
PLAN = [(BD.b_barak, -9.0, 5.5, 20), (BD.b_dom, -2.5, 9.0, 0), (BD.b_kuchnia, 5.0, 8.0, -15), (BD.b_kuznia, 9.5, 2.0, -70),
        (BD.b_studnia, -4.5, -3.0, 0), (BD.b_szalas, -11.0, -1.0, 60), (BD.b_sklad_paliwa, 8.5, -5.5, -110), (BD.b_pole, -8.0, -7.5, 10),
        (BD.b_wieza, -12.0, 10.5, 0), (BD.b_brama, 4.0, 13.8, 180)]
for fn, x, y, r in PLAN: fn(x, y, r)
for k in range(-6, 7):                 # palisada po luku na poludniu
    if abs(k) <= 1: continue
    a = math.radians(73 + k * 7.5); R = 13.8
    BD.b_palisada(R * math.cos(a), R * math.sin(a), math.degrees(a) + 90, n=1) if "n" in BD.b_palisada.__code__.co_varnames else None
import random as _r
_rr = _r.Random(11)
for k in range(70):                    # wydeptana ziemia: wiele drobnych, nakladajacych sie plackow
    a = _rr.uniform(0, 2 * math.pi); d = 1.6 + 7.0 * _rr.random() ** 1.4
    e = ellipsoid("dirt%d" % k, (d * math.cos(a), d * math.sin(a), -0.025), (_rr.uniform(0.3, 1.0), _rr.uniform(0.25, 0.7), 0.03), path, u=8, v=4, pass_index=1)
    e.rotation_euler = (0, 0, _rr.uniform(0, 3.14))
# ---------------------------------------------------------------- ludzie
CAMYAW = -25
def look_yaw(frm, to): d = V(to) - V(frm); return math.degrees(math.atan2(d.y, d.x))
cast = []
def add(rig, fn, loc, yaw): cast.append((rig, fn, tuple(loc), yaw))
kz = V((7.25, 1.45, 0)); ANVIL = V((7.47, 0.84, 0.82))
add(human("kowal", dict(jacket="leather", pants="darkgrey", beard=True, armor="vest"), "smith"), A.clip_smith().sample, kz, -70)
add(human("drwal", dict(jacket="brown", pants="brown", strap=False), "axe"), A.clip_chop().sample, (-6.5, 1.5, 0), 10)
box("pniak", (-5.8, 1.62, 0.2), (0.5, 0.5, 0.4), WOOD(), pass_index=2)
add(human("kopacz", dict(jacket="grey", pants="brown", strap=False), "shovel"), lambda f: A.clip_dig().sample(f % 24), (-6.6, -4.4, 0), 200)
# tragarze: noszenie skrzyn po sciezce miedzy skladem a kuchnia (tam i z powrotem)
def porter(ph):
    def fn(f):
        p = A.carry_walk(f + ph, 14)
        return p
    return fn
for k in range(2):
    a0 = V((6.8, -3.6 + 0.6 * k, 0)); a1 = V((4.2, 5.6 + 0.6 * k, 0))
    r = human("tragarz%d" % k, dict(jacket=("olive", "brown")[k], pants="brown"), "carry")
    def fn(f, a0=a0, a1=a1, ph=7 * k, r=r):
        t = ((f + 12 * k) % 48) / 48.0
        p = A.carry_walk(f + ph, 14)
        pos = a0.lerp(a1, t)
        d = (pos - V(r.base0)) if False else None
        return p, pos
    cast.append((r, ("porter", a0, a1, 12 * k), tuple(a0), look_yaw(a0, a1)))
# przy ognisku: dwie osoby siedza i rozmawiaja
fire_c = V((-1.8, 4.2, 0))
for k, (ang, jk) in enumerate(((200, "teal"), (330, "blue"))):
    p = fire_c + V((math.cos(math.radians(ang)), math.sin(math.radians(ang)), 0)) * 1.05
    add(human("ognisko%d" % k, dict(jacket=jk, pants="darkgrey"), "idle"), (lambda f, k=k: A.talk(f + 8 * k)), p, look_yaw(p, fire_c))
    box("siedzisko%d" % k, (p.x, p.y, 0.2), (0.4, 0.4, 0.4), WOOD(), pass_index=2)
logs = mat("logs", (70, 50, 34), pass_index=2)
for k in range(4):
    a = k * math.pi / 4
    cyl("fire_log%d" % k, fire_c + V((0.35 * math.cos(a), 0.35 * math.sin(a), 0.05)), fire_c - V((0.35 * math.cos(a), 0.35 * math.sin(a), -0.05)), 0.05, logs, seg=5)
FL_O = mat("flame_o", (255, 130, 50), pass_index=2, emit=(255, 110, 40), strength=8)
FL_Y = mat("flame_y", (255, 220, 120), pass_index=2, emit=(255, 210, 110), strength=10)
flames = []
for k, (dx, dy, h, r, m) in enumerate(((0, 0, 0.55, 0.16, FL_O), (0.09, 0.05, 0.40, 0.10, FL_Y), (-0.08, -0.04, 0.36, 0.09, FL_Y), (0.02, -0.1, 0.30, 0.08, FL_O))):
    c = fire_c + V((dx, dy, 0.08))
    fo = loft("flame%d" % k, [(c, r, r), (c + V((0, 0, h * 0.45)), r * 0.8, r * 0.8), (c + V((0, 0, h)), 0.01, 0.01)], m, seg=6, pass_index=2)
    fo.visible_shadow = False; flames.append((fo, c, h))
EMB = mat("ember", (255, 120, 40), pass_index=2, emit=(255, 90, 30), strength=6)
for k in range(6):
    a = k * 1.05
    box("ember%d" % k, fire_c + V((0.28 * math.cos(a), 0.28 * math.sin(a), 0.03)), (0.06, 0.05, 0.03), EMB, pass_index=2)
flame = flames[0][0]
firelight = point_light("firelight", fire_c + V((0, 0, 0.6)), (1.0, 0.6, 0.3), 260, 0.2)
# warta: wartownik na wiezy i patrol z karabinami po okregu
add(human("wartownik", dict(jacket="olive", pants="olive", helmet="mil"), "rifle"), lambda f: A.merge(A.stance(), A.low_ready(), A.P(rot={"head": (0, 0, 40 * math.sin(2 * math.pi * f / 48)), "chest": (0, 0, 10 * math.sin(2 * math.pi * f / 48))})), (-12.0, 10.5, 5.0), 300)
PR = 7.0
for k in range(2):
    r = human("patrol%d" % k, dict(jacket="olive", pants="olive", helmet=("mil", "pot")[k], armor=(None, "vest")[k]), "rifle")
    cast.append((r, ("patrol", -0.55 - 0.13 * k), (0, 0, 0), 0))
# ---------------------------------------------------------------- swiatlo i kamera
fill = sun("fill", (math.radians(55), 0, math.radians(CAMYAW + 150)), (0.62, 0.70, 1.0), 0.5)
rim = sun("rim", (math.radians(-60), 0, math.radians(CAMYAW)), (0.62, 0.80, 1.0), 2.4)
for L in (fill, rim): L.light_linking.receiver_collection = char_collection()
sun("moon", (math.radians(40), 0, math.radians(120)), (0.45, 0.52, 0.85), 0.35)
camera((0.5, 1.0, 0.8), 52, 28.0, (960, 540), yaw_deg=CAMYAW)
FOG = ((0.5, 1.0, 0.8), 52, CAMYAW, 28.0, 30, 12.5, 19.0, (0.0, 0.0))
fxs = FX(); st = {}
FR = [int(x) for x in os.environ['FRAMES'].split(',')] if 'FRAMES' in os.environ else range(F0, F1)
import random
rnd = random.Random(5)
for f in range(0, max(FR) + 1):
    for r, fn, base, yaw in cast:
        if isinstance(fn, tuple) and fn[0] == "porter":
            _, a0, a1, off = fn
            t = ((f + off) % 48) / 48.0
            go = t < 0.5; u = t * 2 if go else (t - 0.5) * 2
            pos = a0.lerp(a1, u) if go else a1.lerp(a0, u)
            pose = A.carry_walk(f + off, 14) if go else A.merge(A.walk(f + off, 12), A.P(ik={"forearm.L": 0.0, "forearm.R": 0.0}))
            if go: pose["ik"] = {"forearm.L": 1.0, "forearm.R": 1.0}
            yy = look_yaw(a0, a1) if go else look_yaw(a1, a0)
            A.apply(r, pose, tuple(pos), yy)
            for o in r.parts:
                if "crate" in o.name or "slat" in o.name: o.hide_render = not go
            continue
        if isinstance(fn, tuple) and fn[0] == "patrol":
            ang0 = fn[1]; w = 0.12 / PR          # predkosc katowa dopasowana do chodu
            ang = ang0 + w * f
            pos = V((PR * math.cos(ang), PR * math.sin(ang), 0))
            A.apply(r, A.merge(A.walk(f + 6 * (ang0 < -0.6), 12, stride=24, arms=False), A.low_ready()), tuple(pos), math.degrees(ang) + 90)
            continue
        A.apply(r, fn(f), base, yaw)
    s = 1 + 0.18 * math.sin(f * 1.7) + 0.1 * math.sin(f * 3.1)
    for k, (fo, c, h) in enumerate(flames):
        sk = 1 + 0.22 * math.sin(f * (1.7 + 0.4 * k) + k) + 0.1 * math.sin(f * 3.1 + 2 * k)
        fo.matrix_world = Matrix.Translation(c) @ Matrix.Diagonal((1, 1, sk, 1)) @ Matrix.Translation(-c)
    firelight.data.energy = 260 * (0.85 + 0.25 * math.sin(f * 2.3))
    bpy.context.view_layer.update()
    for r, *_ in cast: watch_events(fxs, r, st.setdefault(r.ob.name, {}))
    if f % 8 == 5: fxs.impact(ANVIL, 5, wood=False)
    if f % 20 == 10: fxs.spawn("chip", (-5.8, 1.62, 0.45), (rnd.uniform(-1, 1), rnd.uniform(-1, 1), 2.0), life=14, spin=1.5)
    fxs.step()
    if f in FR: render("/home/claude/latarnia3d/out/osada_%02d.exr" % f)
