# Latarnia: modele i animacje do Godota 4

Wszystkie pliki to glTF binarny (`.glb`). Godot importuje je bezpośrednio.

Konwencje:
- jednostka to 1 metr, oś Z w górę (Godot przy imporcie przerobi ją na Y);
- postać patrzy w +X, a lewa strona to +Y;
- tempo animacji to 12 kl/s.

## Katalogi

| Katalog | Zawartość |
|---|---|
| `animacje/` | Postacie ze szkieletem i klipami. Każda akcja to osobny klip, a IK jest już wypieczone do FK. |
| `postacie/` | 18 jednostek 6 frakcji (bez klipów). Używają tych samych nazw kości co `animacje/`, więc klipy pasują po nazwach. |
| `mutanty/` | 15 mutantów. Ogar, Krzykacz i Nosiciel mają pełne klipy, reszta pozę `idle`. |
| `budynki/` | 39 budynków osady z wczesnych epok (Złom, Kuźnia), bez animacji. |
| `frakcje/` | 11 frakcji po 6–8 jednostek w docelowych barwach, ze znakami (sztandar, tarcza, naszywka, tunika). Znaki są teksturami 48×48 z filtrowaniem Nearest. |
| `wrogowie/` | Nowy Ogar (pies), Wataha, Ryjec i Rogacz z klipami gallop, pounce i death; 6 Stworzeń Mgły; 4 ludzi zmienionych przez Mgłę. |
| `bron/` | 13 sztuk broni. Uchwyt jest w punkcie 0, więc broń pasuje do dłoni, stojaka i ekwipunku. |

## Klipy w `animacje/`

| Plik | Klipy |
|---|---|
| `zolnierz_karabin.glb` | idle, walk, run, shoot, reload, kneel_shoot, dive_to_prone, prone_crawl, flinch, stagger, cover_peek_shoot, death |
| `wojownik_dzida.glb` | idle, thrust, walk, death |
| `wojownik_mlot.glb` | idle, smash, walk, death |
| `wojownik_maczeta.glb` | guard, slash, death |
| `granatnik.glb` | throw |
| `cywil.glb` | walk, run, sit_talk, death |
| `drwal.glb`, `kopacz.glb`, `tragarz.glb`, `kowal.glb` | chop, dig, carry_walk, hammer_anvil |

## Co musi zrobić silnik

- **Widoczność obiektów:** błysk z lufy (`*_flash`), magazynek w dłoni (`*_maghand`) i granat w dłoni (`*_gren`) są osobnymi obiektami. Silnik włącza je zdarzeniami w klatkach:
  - strzał: błysk przez 1 klatkę w klatce odrzutu;
  - przeładowanie: magazynek w dłoni w klatkach 7–8 i 13–16;
  - rzut: granat znika w klatce 9.
- **Przesuw postaci:** przesuw bazy z klipów (wypad, krok w tył, upadek) jest zapisany na obiekcie szkieletu. Przy chodzie i biegu silnik przesuwa postać sam, z prędkością:
  - chód: 1,64 m/s;
  - patrol: 1,45 m/s;
  - bieg: 3,6 m/s.
  Przy tych prędkościach stopy się nie ślizgają.
- **Przejścia:** płynne przejścia między klipami robi się mieszaniem w AnimationTree. W pokazie użyto 3–4 klatek, czyli około 0,3 s.
- **Efekty:** łuski, dym, iskry i wybuchy to w pokazach proste obiekty. W grze proponuję cząsteczki Godota (GPUParticles3D) w tym samym stylu: mało cząstek, twarde krawędzie, kolory z palety.
